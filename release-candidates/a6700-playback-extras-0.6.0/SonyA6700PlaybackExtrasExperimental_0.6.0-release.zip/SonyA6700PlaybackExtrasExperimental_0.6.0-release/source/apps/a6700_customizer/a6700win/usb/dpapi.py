"""Account-scoped Windows DPAPI, without UI or machine-wide protection.

This module never enumerates or opens USB devices. Python byte objects cannot
be reliably erased; native input/output buffers are cleared before release.
"""
import ctypes as c
import sys


class ProtectionError(RuntimeError):
    pass


class _Blob(c.Structure):
    _fields_ = [('size', c.c_uint32), ('data', c.c_void_p)]


class AccountProtection:
    MAX_BYTES = 16384
    _PURPOSE = b'SonyA6700InspectionAssistant/auth-material/v1'

    def __init__(self):
        if sys.platform != 'win32':
            raise ProtectionError('Account protection requires Windows')
        self._crypt = c.WinDLL('crypt32.dll', winmode=0x00000800, use_last_error=True)
        self._kernel = c.WinDLL('kernel32.dll', winmode=0x00000800, use_last_error=True)
        args = [c.POINTER(_Blob), c.c_void_p, c.POINTER(_Blob), c.c_void_p,
                c.c_void_p, c.c_uint32, c.POINTER(_Blob)]
        for name in ('CryptProtectData', 'CryptUnprotectData'):
            func = getattr(self._crypt, name)
            func.argtypes, func.restype = args, c.c_int32
        self._kernel.LocalFree.argtypes = [c.c_void_p]
        self._kernel.LocalFree.restype = c.c_void_p

    def _transform(self, raw, *, decrypt):
        if type(raw) is not bytes or not 1 <= len(raw) <= self.MAX_BYTES:
            raise ProtectionError('Invalid account-protection input')
        source = c.create_string_buffer(raw)
        purpose = c.create_string_buffer(self._PURPOSE)
        inp = _Blob(len(raw), c.addressof(source))
        entropy = _Blob(len(self._PURPOSE), c.addressof(purpose))
        out = _Blob()
        func = self._crypt.CryptUnprotectData if decrypt else self._crypt.CryptProtectData
        try:
            # NULL description/prompt/reserved; UI_FORBIDDEN only. In particular,
            # LOCAL_MACHINE is absent, keeping protection scoped to this user.
            if not func(c.byref(inp), None, c.byref(entropy), None, None, 1, c.byref(out)):
                raise ProtectionError('Windows account protection failed; no fallback or retry')
            if not out.data or not 1 <= out.size <= self.MAX_BYTES:
                raise ProtectionError('Windows returned an invalid protected-data buffer')
            return c.string_at(out.data, out.size)
        finally:
            c.memset(c.addressof(source), 0, c.sizeof(source))
            if out.data:
                if out.size <= self.MAX_BYTES:
                    c.memset(out.data, 0, out.size)
                if self._kernel.LocalFree(out.data):
                    raise ProtectionError('Windows protected-data buffer release failed')

    def protect(self, raw):
        return self._transform(raw, decrypt=False)

    def unprotect(self, raw):
        return self._transform(raw, decrypt=True)
