"""Minimal native WPD property reader. No vendor commands or mutation interface.

ABI/constants audited against Microsoft win32metadata 043261f38d94d53b2438b0ffadb836f194c34a73.
Run in the dedicated time-limited worker, not in a GUI thread or service session.
"""
import ctypes as c
import sys
import uuid
from contextlib import contextmanager

from ...ftp_wpd_identity import WpdIdentityError

U32, HR, PTR = c.c_uint32, c.c_int32, c.c_void_p


class GUID(c.Structure):
    _fields_ = [('bytes', c.c_ubyte * 16)]

    def __init__(self, value):
        super().__init__()
        self.bytes[:] = uuid.UUID(value).bytes_le


class KEY(c.Structure):
    _fields_ = [('fmtid', GUID), ('pid', U32)]


CLIENT = '204d9f0c-2292-4080-9f42-40664e70f859'
DEVICE = '26d4979a-e643-4626-9e2b-736dc0c92fdc'
PROPERTIES = {'manufacturer': KEY(GUID(DEVICE), 7), 'model': KEY(GUID(DEVICE), 8),
              'firmware': KEY(GUID(DEVICE), 3), 'serial': KEY(GUID(DEVICE), 9)}
CLASSES = {
    'manager': ('0af10cec-2ecd-4b92-9581-34f6ae0637f3', 'a1567595-4c2f-4574-a6fa-ecef917b9a40'),
    'device': ('728a21c5-3d9e-48d7-9810-864848f0f404', '625e2df8-6392-4cf0-9ad1-3cfa5f17775c'),
    'values': ('0c15d503-d017-47ce-9016-7b3f978721cc', '6848f6f2-3155-4f86-b6f5-263eeeab3143'),
    'keys': ('de2d022d-2480-43be-97f0-d1fa2cf98f4f', 'dada2357-e0ad-492e-98db-dd61c53ba353'),
}


@contextmanager
def normal_observation_lock():
    """Only one identity worker from this tool per Windows session."""
    if sys.platform != 'win32':
        raise WpdIdentityError('Windows native WPD is available only on Windows')
    kernel = c.WinDLL('kernel32.dll', winmode=0x00000800, use_last_error=True)
    kernel.CreateMutexW.argtypes = [PTR, c.c_int32, c.c_wchar_p]; kernel.CreateMutexW.restype = PTR
    kernel.ReleaseMutex.argtypes = [PTR]; kernel.ReleaseMutex.restype = c.c_int32
    kernel.CloseHandle.argtypes = [PTR]; kernel.CloseHandle.restype = c.c_int32
    c.set_last_error(0)
    handle = kernel.CreateMutexW(None, True, 'Local\\SonyA6700InspectionAssistantNormalIdentity')
    error = c.get_last_error()
    if not handle:
        raise WpdIdentityError('Windows could not establish exclusive tool ownership; no camera opened')
    if error == 183:
        kernel.CloseHandle(handle)
        raise WpdIdentityError('Another identity check owns this tool session; no camera opened')
    try:
        yield
    finally:
        kernel.ReleaseMutex(handle)
        kernel.CloseHandle(handle)


def _ok(hr, stage, partial=False):
    if hr not in ((0, 1) if partial else (0,)):
        raise WpdIdentityError(f'Windows WPD {stage} stopped (HRESULT 0x{hr & 0xffffffff:08x}); no automatic retry')


def _call(ptr, index, types, *args):
    method = c.cast(ptr, c.POINTER(c.POINTER(PTR))).contents[index]
    return c.WINFUNCTYPE(HR, PTR, *types)(method)(ptr, *args)


class WpdReader:
    def __init__(self):
        self.refs, self.open_device, self.started = [], None, False
        self.read_attempted = False

    def __enter__(self):
        if sys.platform != 'win32':
            raise WpdIdentityError('Windows native WPD is available only on Windows')
        self.ole = c.WinDLL('ole32.dll', winmode=0x00000800)
        self.ole.CoInitializeEx.argtypes = [PTR, U32]; self.ole.CoInitializeEx.restype = HR
        self.ole.CoCreateInstance.argtypes = [c.POINTER(GUID), PTR, U32, c.POINTER(GUID), c.POINTER(PTR)]
        self.ole.CoCreateInstance.restype = HR
        self.ole.CoTaskMemFree.argtypes = [PTR]; self.ole.CoTaskMemFree.restype = None
        self.ole.CoUninitialize.argtypes = []; self.ole.CoUninitialize.restype = None
        _ok(self.ole.CoInitializeEx(None, 0), 'COM initialization', partial=True)
        self.started = True
        return self

    def __exit__(self, kind, value, traceback):
        close_error = None
        try:
            if self.open_device:
                try: _ok(_call(self.open_device, 8, []), 'normal connection close')
                except Exception as exc: close_error = exc
                self.open_device = None
        finally:
            for ptr in reversed(self.refs):
                _call(ptr, 2, [])  # IUnknown::Release
            self.refs.clear()
            if self.started:
                self.ole.CoUninitialize(); self.started = False
        if close_error:
            raise close_error

    def _create(self, name):
        clsid, iid = map(GUID, CLASSES[name]); ptr = PTR()
        hr = self.ole.CoCreateInstance(c.byref(clsid), None, 1, c.byref(iid), c.byref(ptr))
        if ptr: self.refs.append(ptr)
        _ok(hr, 'interface creation')
        if not ptr: raise WpdIdentityError('Windows WPD returned a missing interface')
        return ptr

    def _interface(self, owner, index, types=(), *args, partial=False):
        ptr = PTR()
        hr = _call(owner, index, [*types, c.POINTER(PTR)], *args, c.byref(ptr))
        if ptr: self.refs.append(ptr)
        if hr != 1 or not partial:
            _ok(hr, 'property interface')
        if not ptr: raise WpdIdentityError('Windows WPD returned a missing property interface')
        return ptr

    def device_ids(self):
        manager = self._create('manager')
        _ok(_call(manager, 4, []), 'device-list refresh')
        count = U32()
        _ok(_call(manager, 3, [c.POINTER(PTR), c.POINTER(U32)], None, c.byref(count)), 'device count')
        if count.value > 128:
            raise WpdIdentityError('Windows WPD device count exceeded 128; no device selected')
        if not count.value: return []
        capacity = count.value
        ids = (PTR * capacity)()
        try:
            _ok(_call(manager, 3, [c.POINTER(PTR), c.POINTER(U32)], ids, c.byref(count)), 'device enumeration')
            if count.value != capacity or any(not ptr for ptr in ids):
                raise WpdIdentityError('Windows WPD device list changed or was incomplete')
            result = [c.wstring_at(ptr) for ptr in ids]
            if any(len(item) > 2048 for item in result):
                raise WpdIdentityError('Windows WPD identifier exceeded its bound')
            return result
        finally:
            for ptr in ids:
                if ptr: self.ole.CoTaskMemFree(ptr)

    def identity(self, ident):
        if self.read_attempted:
            raise WpdIdentityError('Windows WPD identity read already attempted; no retry')
        self.read_attempted = True
        client, device, keys = self._create('values'), self._create('device'), self._create('keys')
        # These Set methods affect the host-side client-information collection,
        # never device properties. Failure must stop before Open.
        _ok(_call(client, 9, [c.POINTER(KEY), U32], c.byref(KEY(GUID(CLIENT), 9)), 0x80000000), 'read-only access request')
        _ok(_call(client, 7, [c.POINTER(KEY), c.c_wchar_p], c.byref(KEY(GUID(CLIENT), 2)), 'Sony A6700 identity inspection'), 'client name')
        _ok(_call(client, 9, [c.POINTER(KEY), U32], c.byref(KEY(GUID(CLIENT), 8)), 0x00010000), 'identification-only security request')
        for key in PROPERTIES.values():
            _ok(_call(keys, 5, [c.POINTER(KEY)], c.byref(key)), 'property selection')
        _ok(_call(device, 3, [c.c_wchar_p, PTR], ident, client), 'read-only normal connection')
        self.open_device = device
        content = self._interface(device, 5)
        properties = self._interface(content, 4)
        values = self._interface(properties, 5, (c.c_wchar_p, PTR), 'DEVICE', keys, partial=True)
        result = {}
        for name, key in PROPERTIES.items():
            text = PTR()
            try:
                hr = _call(values, 8, [c.POINTER(KEY), c.POINTER(PTR)], c.byref(key), c.byref(text))
                # Missing/unsupported individual properties stay explicit. Other
                # transport/driver failures terminate the whole read.
                if hr & 0xffffffff in (0x80070490, 0x80070032):
                    result[name] = None
                else:
                    _ok(hr, 'identity property read')
                    if not text: raise WpdIdentityError('Windows WPD returned a missing property value')
                    result[name] = c.wstring_at(text)
                    if len(result[name]) > 512: raise WpdIdentityError('Windows WPD property exceeded its bound')
            finally:
                if text: self.ole.CoTaskMemFree(text)
        return result


def host_self_test():
    """Exercise real COM ABI using host-only collections. No device enumeration."""
    if c.sizeof(GUID) != 16 or c.sizeof(KEY) != 20:
        raise WpdIdentityError('Windows WPD ABI layout mismatch')
    with WpdReader() as reader:
        values, keys = reader._create('values'), reader._create('keys')
        key = KEY(GUID(CLIENT), 2)
        _ok(_call(values, 7, [c.POINTER(KEY), c.c_wchar_p], c.byref(key), 'host-only ABI check'), 'host test set')
        _ok(_call(keys, 5, [c.POINTER(KEY)], c.byref(key)), 'host test key')
        count = U32()
        _ok(_call(keys, 3, [c.POINTER(U32)], c.byref(count)), 'host test count')
        text = PTR()
        try:
            _ok(_call(values, 8, [c.POINTER(KEY), c.POINTER(PTR)], c.byref(key), c.byref(text)), 'host test get')
            if not text or c.wstring_at(text) != 'host-only ABI check' or count.value != 1:
                raise WpdIdentityError('Windows WPD host-only ABI check failed')
        finally:
            if text: reader.ole.CoTaskMemFree(text)
    return {'wpd_host_abi': 'PASS', 'camera_accessed': False}
