#include "playback_filter_snapshot.h"

namespace a6700_playback {
namespace {
template<class T> T function(std::uintptr_t bias, std::uintptr_t va) noexcept {
    return reinterpret_cast<T>(bias + va);
}
bool word(const void* (*getter)(), std::uint32_t& value) noexcept {
    if (!getter) return false;
    const void* pointer = getter();
    if (!pointer) return false;
    value = *static_cast<const std::uint32_t*>(pointer);
    return true;
}
bool flag(const void* (*getter)(), unsigned char& value) noexcept {
    if (!getter) return false;
    const void* pointer = getter();
    if (!pointer) return false;
    value = *static_cast<const unsigned char*>(pointer);
    return value <= 1;
}
}

SonyModelApi sony_model_api(std::uintptr_t bias) noexcept {
    SonyModelApi api = {};
    api.enter = function<decltype(api.enter)>(bias, 0x3137990);
    api.leave = function<decltype(api.leave)>(bias, 0x313759c);
    api.active = function<decltype(api.active)>(bias, 0x2f964c8);
    for (unsigned i = 0; i != 11; ++i)
        api.criterion[i] = function<decltype(api.active)>(bias, 0x2f967e8 + i * 0x28);
    api.ftp_selection = function<decltype(api.active)>(bias, 0x2f782c4);
    api.still_target = function<decltype(api.active)>(bias, 0x2e7dee0);
    api.movie_target = function<decltype(api.active)>(bias, 0x2e7e06c);
    api.media_info = function<decltype(api.active)>(bias, 0x2d19dac);
    api.view = function<decltype(api.active)>(bias, 0x2f78224);
    api.group = function<decltype(api.active)>(bias, 0x2f78774);
    api.expand = function<decltype(api.active)>(bias, 0x2f71904);
    api.edit = function<decltype(api.active)>(bias, 0x2f71ddc);
    api.last_screen = function<decltype(api.active)>(bias, 0x2f80600);
    return api;
}

bool sony_capture_locked(const SonyModelApi& api, std::uint32_t context, SonySnapshot& output) noexcept {
    if (context > 2 || !api.media_info) return false;
    SonySnapshot next = {};
    next.context = context;
    const void* media = api.media_info();
    if (!media) return false;
    next.media = *reinterpret_cast<const std::uint32_t*>(
        static_cast<const unsigned char*>(media) + context * 0x70);
    if (!flag(api.active, next.active)) return false;
    for (unsigned i = 0; i != 11; ++i)
        if (!flag(api.criterion[i], next.criterion[i])) return false;
    if (!word(api.ftp_selection, next.ftp_selection) ||
        !word(api.still_target, next.still_target) || !word(api.movie_target, next.movie_target) ||
        !word(api.view, next.view) || !word(api.group, next.group) ||
        !word(api.expand, next.expand) || !word(api.edit, next.edit) ||
        !word(api.last_screen, next.last_screen)) return false;
    output = next;
    return true;
}

bool sony_capture(const SonyModelApi& api, std::uint32_t context, SonySnapshot& output) noexcept {
    if (!api.enter || !api.leave || context > 2) return false;
    // Existing target constructors reserve eight bytes for this same guard.
    alignas(8) unsigned char guard[8] = {};
    api.enter(guard);
    const bool ok = sony_capture_locked(api, context, output);
    api.leave(guard);
    return ok;
}

bool sony_same_snapshot(const SonySnapshot& a, const SonySnapshot& b) noexcept {
    if (a.context != b.context || a.media != b.media || a.view != b.view ||
        a.group != b.group || a.expand != b.expand || a.edit != b.edit ||
        a.last_screen != b.last_screen || a.ftp_selection != b.ftp_selection ||
        a.still_target != b.still_target || a.movie_target != b.movie_target || a.active != b.active)
        return false;
    for (unsigned i = 0; i != 11; ++i)
        if (a.criterion[i] != b.criterion[i]) return false;
    return true;
}

SonyCriteria sony_ftp_criteria(const SonySnapshot& value) noexcept {
    SonyCriteria result = {};
    result.query.ftp_enabled = value.criterion[8] != 0;
    result.query.ftp_selection = value.ftp_selection;
    result.query.still_mode = value.still_target <= 1 ? value.still_target : 2;
    result.query.movie_mode = value.movie_target == 0 ? 2 : value.movie_target == 1 ? 1 : 0;
    result.query.collapse_groups = value.group == 0 && value.expand == 1;
    for (unsigned i = 0; i != 11; ++i)
        if (i != 8 && value.criterion[i]) result.unsupported_enabled = true;
    return result;
}
} // namespace a6700_playback
