#include "playback_filter_registry.h"
#include <stddef.h>

_Static_assert(sizeof(void *) == 8, "64-bit native registry required");
_Static_assert(sizeof(A6700FilterEntry) == 32, "assembly entry stride");
_Static_assert(offsetof(A6700FilterRegistry, entries) == 16, "assembly entries offset");

A6700FilterRegistry a6700_filter_registry;

int a6700_filter_register(A6700FilterRegistry *registry, void *native_set, uint32_t count,
                         uint32_t media, uint64_t generation, uint32_t *selector) {
    if (!registry || !native_set || !selector) return 1;
    uint32_t index = __atomic_load_n(&registry->used, __ATOMIC_RELAXED);
    do {
        if (index >= A6700_FILTER_REGISTRY_CAPACITY) return 2;
    } while (!__atomic_compare_exchange_n(&registry->used, &index, index + 1, 0,
                                          __ATOMIC_RELAXED, __ATOMIC_RELAXED));
    A6700FilterEntry *entry = &registry->entries[index];
    entry->count = count;
    entry->media = media;
    entry->generation = generation;
    __atomic_store_n(&entry->native_set, native_set, __ATOMIC_RELEASE);
    *selector = A6700_FILTER_SELECTOR_BASE + index;
    return 0;
}

const A6700FilterEntry *a6700_filter_lookup(const A6700FilterRegistry *registry, uint32_t selector) {
    uint32_t index = selector - A6700_FILTER_SELECTOR_BASE;
    if (!registry || index >= A6700_FILTER_REGISTRY_CAPACITY) return 0;
    const A6700FilterEntry *entry = &registry->entries[index];
    return __atomic_load_n(&entry->native_set, __ATOMIC_ACQUIRE) ? entry : 0;
}
