#include "playback_filter_active.h"
#include <new>

namespace a6700_playback {
struct ActiveContext {
    SonyApi native;
    void (*release)(void*);
    SonySet source;
    SonySet* output;
    std::uint32_t* scratch;
    void* database_lock;
    bool source_constructed, output_constructed, registered;
};

namespace {
std::uint32_t& word(void* object, std::size_t offset) noexcept {
    return *reinterpret_cast<std::uint32_t*>(static_cast<unsigned char*>(object) + offset);
}
bool context_matches(void* active, const SonySnapshot& snapshot) noexcept {
    return word(active, 0x1bc) == snapshot.media && word(active, 0x1c0) == snapshot.context &&
           word(active, 0x1c8) == snapshot.view && word(active, 0x1dc) == snapshot.group &&
           word(active, 0x1e0) == snapshot.expand && word(active, 0x1d8) == snapshot.edit &&
           word(active, 0x1e4) == snapshot.last_screen;
}
template<class T> T function(std::uintptr_t bias, std::uintptr_t va) noexcept {
    return reinterpret_cast<T>(bias + va);
}
void copy_pod(void* destination, const void* source, std::size_t count) noexcept {
    // Volatile byte accesses keep this small POD bridge independent of a
    // compiler-emitted memcpy import or a separately linked C runtime.
    auto* output = static_cast<volatile unsigned char*>(destination);
    const auto* input = static_cast<const volatile unsigned char*>(source);
    while (count--) *output++ = *input++;
}
}

bool sony_active_cleanup(ActiveContext*& context) noexcept {
    if (!context) return true;
    ActiveContext* owned = context;
    context = nullptr;
    if (owned->source_constructed) owned->native.destroy(&owned->source);
    if (owned->output && !owned->registered) {
        if (owned->output_constructed) owned->native.destroy(owned->output);
        owned->release(owned->output);
    }
    if (owned->scratch) owned->release(owned->scratch);
    bool unlocked = true;
    if (owned->database_lock)
        unlocked = sony_database_leave(owned->native, owned->database_lock);
    void (*release)(void*) = owned->release;
    owned->~ActiveContext();
    release(owned);
    return unlocked;
}

int sony_active_prepare(const ActiveBindings& bindings, A6700FilterRegistry& registry,
                        void* active, std::uint32_t& selector,
                        ActiveContext*& context) noexcept {
    if (!active || context) return -1;
    if (!word(active, 0x1f0)) return 0;
    if (!bindings.model.active) return -1;
    const void* active_pointer = bindings.model.active();
    if (!active_pointer) return -1;
    const unsigned char active_value = *static_cast<const unsigned char*>(active_pointer);
    if (!active_value) return 0;
    if (active_value != 1) return -1;
    if (!bindings.allocate || !bindings.release ||
        !bindings.app_sidb_mutex || !bindings.app_lock || !bindings.app_unlock ||
        !bindings.model_set || !bindings.model_notify || !bindings.native.construct ||
        !bindings.native.destroy || !bindings.native.root || !bindings.native.size ||
        !bindings.native.search) return -1;
    SonySnapshot snapshot;
    if (!sony_capture_locked(bindings.model, word(active, 0x1c0), snapshot) ||
        !context_matches(active, snapshot)) return -1;
    if (!snapshot.active) return 0;
    const SonyCriteria captured = sony_ftp_criteria(snapshot);
    if (captured.unsupported_enabled || !captured.query.ftp_enabled || snapshot.ftp_selection > 2 ||
        snapshot.group > 1 || snapshot.expand > 1) return -1;

    void* memory = bindings.allocate(sizeof(ActiveContext));
    if (!memory) return -1;
    context = new (memory) ActiveContext;
    copy_pod(&context->native, &bindings.native, sizeof(context->native));
    context->release = bindings.release;
    context->output = nullptr;
    context->scratch = nullptr;
    context->database_lock = nullptr;
    context->source_constructed = context->output_constructed = context->registered = false;
    void* app_guard = bindings.app_sidb_mutex;
    bindings.app_lock(app_guard);
    int result = -1;
    std::uint32_t published_selector = selector, published_count = 0, unfiltered_total = 0;
    do {
        std::uint32_t database_slot;
        if (!sony_database_enter(bindings.native, snapshot.media, database_slot, context->database_lock)) break;
        context->native.construct(&context->source); context->source_constructed = true;
        context->output = static_cast<SonySet*>(bindings.allocate(sizeof(SonySet)));
        if (!context->output) break;
        context->native.construct(context->output); context->output_constructed = true;
        const std::uint32_t root_type = snapshot.edit == 1 ? 5 : snapshot.view == 1 ? 6 : snapshot.view == 5 ? 5 : 1;
        if (bindings.native.root(snapshot.media, root_type, false, true, &context->source) != 0) break;
        const std::uint32_t length = bindings.native.size(&context->source);
        if (length > 0x20000u) break;
        SonyCriteria criteria = captured;
        criteria.exclude_col62 = snapshot.last_screen == 0;
        criteria.current_group_enabled = snapshot.group == 0 && snapshot.expand == 0;
        if (criteria.current_group_enabled) {
            const std::uint32_t current = word(active, 0x1d4);
            if (current == 0xffffffffu || !bindings.native.get_u32 ||
                bindings.native.get_u32(database_slot, 2, current & 0x1ffffu, &criteria.current_group_key) != 0) break;
        }
        if (criteria.query.collapse_groups && length) {
            context->scratch = static_cast<std::uint32_t*>(bindings.allocate(std::size_t(length) * sizeof(std::uint32_t)));
            if (!context->scratch) break;
        }
        std::uint32_t count = 0;
        if (sony_filter_set(bindings.native, database_slot, context->source, *context->output,
                criteria, context->scratch, length, count) != SonyQueryStatus::ok) break;
        std::uint32_t next_selector = selector;
        if (a6700_filter_register(&registry, context->output, count, snapshot.media,
                std::uint64_t(__atomic_load_n(&registry.used, __ATOMIC_RELAXED)) + 1,
                &next_selector) != 0) break;
        context->registered = true;
        const bool member = bindings.native.search(context->output, word(active, 0x1d4)) != 0xffffffffu;
        unfiltered_total = word(active, 0x1d0);
        published_selector = next_selector;
        published_count = count;
        result = member ? 3 : 2;
    } while (false);
    bindings.app_unlock(&app_guard);
    if (result < 0) sony_active_cleanup(context);
    else {
        selector = published_selector;
        word(active, 0x1d0) = published_count;
        bindings.model_set(0x1abf, published_count); bindings.model_notify(0x1abf);
        bindings.model_set(0x1ac0, unfiltered_total); bindings.model_notify(0x1ac0);
    }
    return result;
}

bool sony_active_bind(std::uintptr_t bias, ActiveBindings& output) noexcept {
    ActiveBindings next;
    if (!sony_resolve_api(function<SonyDlsym>(bias, 0x176b3d0), next.native)) return false;
    const SonyModelApi model = sony_model_api(bias);
    copy_pod(&next.model, &model, sizeof(model));
    next.allocate = function<decltype(next.allocate)>(bias, 0x176a2d0);
    next.release = function<decltype(next.release)>(bias, 0x176c360);
    next.app_sidb_mutex = reinterpret_cast<void*>(bias + 0x1416b7e0);
    next.app_lock = function<decltype(next.app_lock)>(bias, 0x1907dec);
    next.app_unlock = function<decltype(next.app_unlock)>(bias, 0x1907e18);
    next.model_set = function<decltype(next.model_set)>(bias, 0x2fac33c);
    next.model_notify = function<decltype(next.model_notify)>(bias, 0x2d0d52c);
    if (!next.app_sidb_mutex) return false;
    copy_pod(&output, &next, sizeof(next));
    return true;
}
} // namespace a6700_playback

extern "C" int a6700_filter_active_prepare(void* active, void* frame,
                                           std::uintptr_t bias) noexcept {
    using namespace a6700_playback;
    if (!frame) return -1;
    auto& context = *reinterpret_cast<ActiveContext**>(static_cast<unsigned char*>(frame) + 0x325b0);
    context = nullptr;
    if (!active) return -1;
    if (!*reinterpret_cast<const std::uint32_t*>(static_cast<unsigned char*>(active) + 0x1f0)) return 0;
    const SonyModelApi model = sony_model_api(bias);
    const void* active_pointer = model.active();
    if (!active_pointer) return -1;
    const unsigned char active_value = *static_cast<const unsigned char*>(active_pointer);
    if (!active_value) return 0;
    if (active_value != 1) return -1;
    ActiveBindings bindings;
    if (!sony_active_bind(bias, bindings)) return -1;
    auto& selector = *reinterpret_cast<std::uint32_t*>(static_cast<unsigned char*>(frame) + 0x44);
    return sony_active_prepare(bindings, a6700_filter_registry, active, selector, context);
}

extern "C" int a6700_filter_active_cleanup(void* frame, std::uintptr_t) noexcept {
    if (!frame) return -1;
    auto& context = *reinterpret_cast<a6700_playback::ActiveContext**>(static_cast<unsigned char*>(frame) + 0x325b0);
    return a6700_playback::sony_active_cleanup(context) ? 0 : -1;
}
