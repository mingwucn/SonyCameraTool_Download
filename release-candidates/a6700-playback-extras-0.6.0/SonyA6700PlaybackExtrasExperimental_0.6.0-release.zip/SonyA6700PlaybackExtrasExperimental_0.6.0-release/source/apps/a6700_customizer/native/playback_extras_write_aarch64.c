/* Fixed, separately selected playback FTP shortcut, general FTP Transfer,
 * or title transaction.
 * Derived from the audited playback_menu_write_aarch64 adapter. This helper
 * does not repair filtering. Shortcut mode never opens a WBI descriptor.
 * No retry, rollback, deletion, restart or WBI invalidation is performed.
 * Software windows and logical changes do not establish physical geometry.
 * Monotonic deadlines are checked between syscalls; blocked calls are not
 * cancelled. Native readback and service STOP are separate evidence. */
#include "ftp_wbi_experimental_core.h"
#include "ftp_app_guard.h"
#include "playback_extras_profile.h"
#include "playback_extras_guard_policy.h"

#define SYS_MOUNT 40L
#define SYS_FTRUNCATE 46L
#define SYS_OPENAT 56L
#define SYS_CLOSE 57L
#define SYS_LSEEK 62L
#define SYS_WRITE 64L
#define SYS_PREAD64 67L
#define SYS_PWRITE64 68L
#define SYS_FSTAT 80L
#define SYS_FSYNC 82L
#define SYS_CLOCK_GETTIME 113L
#define AT_FDCWD (-100L)
#define FLAGS (2L|0x20000L|0x80000L)
#define MOUNT_FLAGS (32L|16L|1024L|2048L)
#define MS_RDONLY 1L
#define ENGLISH_OFFSET 0x023080f8ULL

#if EXTRAS_ACTION == 1u
#define FIXED_TARGET_COUNT 1u
#define FIXED_CHANGE_COUNT 2u
static const uint64_t fixed_offsets[]={0x03788e00ULL};
static const uint16_t fixed_positions[]={0x52,0x53};
static const uint8_t fixed_before[]={0,0}, fixed_after[]={1,1};
static const uint8_t fixed_digest[32]={
    0xc0,0x53,0xe3,0x1a,0x3a,0xf8,0x74,0xb1,0x7e,0x7f,0x9f,0x3a,0x39,0x8d,0x38,0xe9,
    0x89,0x2c,0xf0,0xf6,0x83,0x4e,0x91,0x00,0x0f,0xaf,0x78,0x29,0x30,0xc0,0xba,0xfc};
#elif EXTRAS_ACTION == 2u
#define FIXED_TARGET_COUNT 2u
#define FIXED_CHANGE_COUNT 4u
static const uint64_t fixed_offsets[]={0x025c1c00ULL,0x04c36a00ULL};
static const uint16_t fixed_positions[]={0x18c,0x18d,0x18c,0x18d};
static const uint8_t fixed_before[]={0xce,0x80,0xce,0x80};
static const uint8_t fixed_after[]={0x77,0x60,0x77,0x60};
static const uint8_t fixed_digest[32]={
    0xd1,0xb0,0x4b,0x18,0x5f,0x95,0x08,0xbd,0x6d,0x27,0x8b,0xce,0x68,0x8c,0xfa,0xed,
    0x24,0x41,0xfd,0x8e,0x45,0xa4,0x70,0x4a,0x9e,0x66,0x58,0x41,0x5f,0x3e,0x73,0x58};
#elif EXTRAS_ACTION == 3u
#define FIXED_TARGET_COUNT 1u
#define FIXED_CHANGE_COUNT 1u
static const uint64_t fixed_offsets[]={0x03788c00ULL};
static const uint16_t fixed_positions[]={0x1c3};
static const uint8_t fixed_before[]={0}, fixed_after[]={1};
static const uint8_t fixed_digest[32]={
    0x1c,0x1e,0x55,0xdf,0xde,0xdc,0xd1,0x9c,0x39,0xe0,0x1d,0x89,0xd0,0x8b,0xf9,0x56,
    0x1a,0xad,0xb1,0x2e,0x70,0xf0,0x09,0xe1,0xe4,0x4a,0x4f,0xdb,0xe5,0xc5,0x38,0x1a};
#else
#error "Only fixed shortcut (1), title (2), and general FTP Transfer (3) profiles are supported"
#endif
#define REQUEST_BYTES (56u+FIXED_TARGET_COUNT*1024u)

static const char stage[]="/tmp/jiritsu/tmmc.jit";
static const char app_path[]="/usr/lib/appFw.so";
#if EXTRAS_ACTION == 2u
static const char wbi_path[]="/dev/nflasha5";
#endif
static const char usr_path[]="/usr";
static uint8_t input[REQUEST_BYTES], response[44], english[4], english_after[4];

#ifdef PLAYBACK_EXTRAS_WRITER_TEST
extern intptr_t playback_extras_writer_test_call6(intptr_t,intptr_t,intptr_t,intptr_t,intptr_t,intptr_t,intptr_t);
static intptr_t call6(intptr_t n,intptr_t a,intptr_t b,intptr_t c,intptr_t d,intptr_t e,intptr_t f) {
    return playback_extras_writer_test_call6(n,a,b,c,d,e,f);
}
#else
static intptr_t call6(intptr_t n,intptr_t a,intptr_t b,intptr_t c,intptr_t d,intptr_t e,intptr_t f) {
    register long x8 __asm__("x8")=n, x0 __asm__("x0")=a;
    register long x1 __asm__("x1")=b, x2 __asm__("x2")=c, x3 __asm__("x3")=d;
    register long x4 __asm__("x4")=e, x5 __asm__("x5")=f;
    __asm__ volatile("svc #0" : "+r"(x0) : "r"(x8),"r"(x1),"r"(x2),"r"(x3),"r"(x4),"r"(x5) : "memory","cc");
    return x0;
}
#endif
static intptr_t call4(intptr_t n,intptr_t a,intptr_t b,intptr_t c,intptr_t d) {
    return call6(n,a,b,c,d,0,0);
}
static int same(const uint8_t *a,const uint8_t *b,size_t n) {
    unsigned v=0; for(size_t i=0;i<n;i++) v|=a[i]^b[i]; return v==0;
}
static int profile_fixed(void) {
    if(EXTRAS_TARGET_COUNT!=FIXED_TARGET_COUNT || EXTRAS_CHANGE_COUNT!=FIXED_CHANGE_COUNT ||
       EXTRAS_REQUEST_BYTES!=REQUEST_BYTES || FTP_PROFILE.target_count!=FIXED_TARGET_COUNT ||
       FTP_PROFILE.change_count!=FIXED_CHANGE_COUNT ||
       sizeof(TARGETS)/sizeof(TARGETS[0])!=FIXED_TARGET_COUNT ||
       sizeof(CHANGES)/sizeof(CHANGES[0])!=FIXED_CHANGE_COUNT ||
       !same(FTP_PROFILE.digest,fixed_digest,32)) return 0;
    for(unsigned i=0;i<FIXED_TARGET_COUNT;i++) {
        const struct ftp_wbi_target *t=FTP_PROFILE.targets+i;
        unsigned first=EXTRAS_ACTION==3u ? 0u : 2u*i;
        unsigned count=EXTRAS_ACTION==3u ? 1u : 2u;
        if(t->offset!=fixed_offsets[i] || t->profile_index!=i ||
           t->first_change!=first || t->change_count!=count) return 0;
    }
    for(unsigned i=0;i<FIXED_CHANGE_COUNT;i++) {
        const struct ftp_wbi_change *c=FTP_PROFILE.changes+i;
        if(c->position!=fixed_positions[i] || c->before!=fixed_before[i] || c->after!=fixed_after[i]) return 0;
    }
    return 1;
}
static int policy_fixed(void) {
    static const uint8_t canonical[32]={
        0xe6,0x5f,0xd5,0x95,0x05,0x2b,0xe5,0xd0,0xe9,0x8c,0xe8,0x00,0x0d,0xfc,0xb9,0x4f,
        0x90,0xa2,0xf8,0x30,0x9d,0xe7,0x0e,0xf1,0x40,0x37,0x50,0x52,0x00,0x9b,0x0e,0xf3};
    static const uint8_t old_title[4]={0xce,0x80,0,2}, new_title[4]={0x77,0x60,0,2};
    const size_t count=sizeof(ftp_guard_fields)/sizeof(ftp_guard_fields[0]);
    unsigned shortcut=0,title=0,general=0;
    unsigned expected_count=EXTRAS_ACTION==3u ? 100u : 99u;
    if(FTP_GUARD_APP_SIZE!=89027992ULL || count!=expected_count || !same(ftp_guard_expected,canonical,32)) return 0;
    for(size_t i=0;i<count;i++) {
        const struct ftp_guard_field *f=ftp_guard_fields+i;
        if(f->offset==0x03788e52ULL) {
            if(f->width!=2 || f->reference[0] || f->reference[1] ||
               f->variant[0]!=1 || f->variant[1]!=1) return 0;
            shortcut++;
        }
        if(f->offset==0x04c36b8cULL) {
            if(f->width!=4 || !same(f->reference,old_title,4) || !same(f->variant,new_title,4)) return 0;
            title++;
        }
        if(f->offset==0x03788dc3ULL) {
            if(f->width!=1 || f->reference[0]!=0 || f->variant[0]!=1) return 0;
            general++;
        }
    }
    return shortcut==1 && title==1 && general==(EXTRAS_ACTION==3u ? 1u : 0u);
}
static int known_preimages(void) {
#if EXTRAS_ACTION == 1u
    const uint8_t *before=input+56,*after=before+512;
    static const uint8_t key[4]={0xc7,4,0,0};
    return same(before+0x18,key,4) && same(after+0x18,key,4) &&
           before[0x52]==0 && before[0x53]==0 && after[0x52]==1 && after[0x53]==1;
#elif EXTRAS_ACTION == 3u
    const uint8_t *before=input+56,*after=before+512;
    static const uint8_t key[4]={0xa8,4,0,0};
    return same(before+0x188,key,4) && same(after+0x188,key,4) &&
           before[0x1c2]==after[0x1c2] && before[0x1c3]==0 && after[0x1c3]==1;
#else
    static const uint8_t old_title[4]={0xce,0x80,0,2}, new_title[4]={0x77,0x60,0,2};
    static const uint16_t permissions[]={0x6a,0x10a,0x1aa};
    for(unsigned i=0;i<2;i++) {
        const uint8_t *before=input+56+i*1024,*after=before+512;
        if(!same(before+0x18c,old_title,4) || !same(after+0x18c,new_title,4)) return 0;
        for(unsigned j=0;j<3;j++) {
            unsigned p=permissions[j];
            if(before[p]!=1 || before[p+1] || after[p]!=1 || after[p+1]) return 0;
        }
    }
    return 1;
#endif
}
static int safe_regular(long fd,uint64_t size,unsigned links,uint64_t st[16]) {
    if(call4(SYS_FSTAT,fd,(intptr_t)st,0,0)<0) return 0;
    return ((uint32_t)st[2]&0170000u)==0100000u && st[6]==size &&
           (!links || (uint32_t)(st[2]>>32)==1u);
}
struct device { long wbi,app,last; int remounted,open_reason,deadline,writes; uint64_t started; };
struct mono_time { int64_t seconds,nanoseconds; };
static int monotonic_ns(uint64_t *out) {
    struct mono_time t={0,0};
    if(call4(SYS_CLOCK_GETTIME,1,(intptr_t)&t,0,0)!=0 || t.seconds<0 ||
       t.nanoseconds<0 || t.nanoseconds>=1000000000LL ||
       (uint64_t)t.seconds>(UINT64_MAX-(uint64_t)t.nanoseconds)/1000000000ULL) return -1;
    *out=(uint64_t)t.seconds*1000000000ULL+(uint64_t)t.nanoseconds;
    return 0;
}
static int within_budget(struct device *d) {
    uint64_t now=0, limit=d->writes ? 120000000000ULL : 60000000000ULL;
    if(d->deadline || monotonic_ns(&now) || now<d->started || now-d->started>limit) {
        d->deadline=1; return 0;
    }
    return 1;
}
static int app_reader_fn(uint64_t off,uint32_t len,uint8_t *out,void *ctx) {
    struct device *d=ctx;
    if(!within_budget(d)) return -1;
    return call4(SYS_PREAD64,d->app,(intptr_t)out,len,(long)off)==(long)len ? 0 : -1;
}
static int guard(struct device *d) {
    uint64_t before[16]={0},after[16]={0};
    static const unsigned stable[]={0,1,2,3,4,6,11,12,13,14};
    if(!within_budget(d) || !safe_regular(d->app,FTP_GUARD_APP_SIZE,0,before) ||
       ftp_app_guard(app_reader_fn,d,FTP_GUARD_APP_SIZE,ftp_guard_fields,
                     sizeof(ftp_guard_fields)/sizeof(ftp_guard_fields[0]),
                     ftp_guard_expected,0,0,0) ||
       !within_budget(d) || !safe_regular(d->app,FTP_GUARD_APP_SIZE,0,after)) return -1;
    for(unsigned i=0;i<sizeof(stable)/sizeof(stable[0]);i++)
        if(before[stable[i]]!=after[stable[i]]) return -1;
    return 0;
}
static int open_targets(void *opaque) {
    struct device *d=opaque;
    if(!within_budget(d)) return -1;
#if EXTRAS_ACTION == 2u
    d->wbi=call4(SYS_OPENAT,AT_FDCWD,(intptr_t)wbi_path,FLAGS,0);
    if(d->wbi<0) return -1;
#endif
    d->app=call4(SYS_OPENAT,AT_FDCWD,(intptr_t)app_path,FLAGS,0);
    if(d->app==-30L) {
        if(call6(SYS_MOUNT,0,(intptr_t)usr_path,0,MOUNT_FLAGS,0,0)!=0) return -1;
        d->remounted=1;
        d->app=call4(SYS_OPENAT,AT_FDCWD,(intptr_t)app_path,FLAGS,0);
    }
    if(d->app<0) return -1;
    if(guard(d) || app_reader_fn(ENGLISH_OFFSET,4,english,d)) {
        d->open_reason=10; return -1;
    }
    return 0;
}
static long fd_for(struct device *d,uint64_t offset) {
#if EXTRAS_ACTION == 1u
    return offset==0x03788e00ULL ? d->app : -1;
#elif EXTRAS_ACTION == 3u
    return offset==0x03788c00ULL ? d->app : -1;
#else
    if(offset==0x025c1c00ULL) return d->wbi;
    return offset==0x04c36a00ULL ? d->app : -1;
#endif
}
static long read_target(void *opaque,uint64_t offset,uint8_t *buffer,uint32_t length) {
    struct device *d=opaque; long fd=fd_for(d,offset);
    if(fd<0 || length!=512 || !within_budget(d)) return -1;
    return call4(SYS_PREAD64,fd,(intptr_t)buffer,length,(long)offset);
}
static long write_target(void *opaque,uint64_t offset,const uint8_t *buffer,uint32_t length) {
    struct device *d=opaque; long fd=fd_for(d,offset);
    if(fd<0 || length!=512 || !within_budget(d)) return -1;
    d->last=fd;d->writes++;
    return call4(SYS_PWRITE64,fd,(intptr_t)buffer,length,(long)offset);
}
static int sync_target(void *opaque) {
    struct device *d=opaque;
    return d->last<0 || !within_budget(d) || call4(SYS_FSYNC,d->last,0,0,0)!=0 ? -1 : 0;
}
/* The adapter, not the generic transaction core, owns descriptors and mount. */
static int close_targets(void *opaque) { (void)opaque; return 0; }
static void put32(unsigned at,uint32_t v) { for(unsigned i=0;i<4;i++) response[at+i]=(uint8_t)(v>>(8*i)); }
static void publish(long fd,const struct ftp_wbi_result *r) {
    response[0]='A';response[1]='6';response[2]='E';response[3]='Y';
    put32(4,1);for(unsigned i=0;i<16;i++) response[8+i]=input[8+i];
    put32(24,r->status);put32(28,r->failed_index);put32(32,r->attempted);
    put32(36,r->verified);put32(40,r->uncertain);
    if(call4(SYS_FTRUNCATE,fd,0,0,0)<0 || call4(SYS_LSEEK,fd,0,0,0)!=0) return;
    if(call4(SYS_WRITE,fd,(intptr_t)response,sizeof(response),0)!=(long)sizeof(response)) return;
    (void)call4(SYS_FSYNC,fd,0,0,0);
}
#ifdef PLAYBACK_EXTRAS_WRITER_TEST
void playback_extras_writer_test_run(void) {
#else
__attribute__((constructor)) static void run(void) {
#endif
    uint64_t st[16]={0};
    struct device d={-1,-1,-1,0,0,0,0,0};
    struct ftp_wbi_result result={1,UINT32_MAX,0,0,0};
    const struct ftp_wbi_ops ops={open_targets,read_target,write_target,sync_target,close_targets};
    if(monotonic_ns(&d.started)) d.deadline=1;
    long fd=call4(SYS_OPENAT,AT_FDCWD,(intptr_t)stage,FLAGS,0);
    if(fd<0) return;
    if(!safe_regular(fd,REQUEST_BYTES,1,st) ||
       call4(SYS_PREAD64,fd,(intptr_t)input,REQUEST_BYTES,0)!=(long)REQUEST_BYTES ||
       !profile_fixed() || !policy_fixed()) goto finish;
    if(d.deadline) result.status=14;
    else if(known_preimages()) (void)ftp_wbi_experimental(&FTP_PROFILE,input,sizeof(input),&ops,&d,&result);
    if(d.open_reason && result.status==2) result.status=(uint32_t)d.open_reason;
    if(result.status==0 && (guard(&d) || app_reader_fn(ENGLISH_OFFSET,4,english_after,&d) ||
       !same(english,english_after,4) || !within_budget(&d))) { result.status=11;result.uncertain=1; }
    if(d.deadline) result.status=14;
    if(d.app>=0 && call4(SYS_CLOSE,d.app,0,0,0)!=0 && result.status==0) {
        result.status=12;result.uncertain=1;
    }
    if(d.wbi>=0 && call4(SYS_CLOSE,d.wbi,0,0,0)!=0 && result.status==0) {
        result.status=12;result.uncertain=1;
    }
    if(result.status==0 && !within_budget(&d)) { result.status=14;result.uncertain=1; }
    if(result.status==0 && d.remounted &&
       call6(SYS_MOUNT,0,(intptr_t)usr_path,0,MOUNT_FLAGS|MS_RDONLY,0,0)!=0) {
        result.status=13;result.uncertain=1;
    }
    if(result.status==0 && !within_budget(&d)) { result.status=14;result.uncertain=1; }
    if(result.status && (result.attempted || d.remounted)) result.uncertain=1;
    publish(fd,&result);
finish:
    (void)call4(SYS_CLOSE,fd,0,0,0);
}
