/*
 * Offline-developed, fixed read-only App window helper core.
 *
 * There is deliberately no main(), constructor, request parser, session,
 * transport, USB path, WBI path, temporary-file path, or write syscall. The
 * exported function is not called by any live capture route. Its only target
 * is /usr/lib/appFw.so opened O_RDONLY; output order matches the pinned host
 * profile: 0x03788e00 then 0x03788c00, 512 bytes each.
 */
#include "playback_general_transfer_reader.h"

#define SYS_OPENAT 56L
#define SYS_CLOSE 57L
#define SYS_PREAD64 67L
#define SYS_FSTAT 80L
#define AT_FDCWD (-100L)
#define O_RDONLY 0L
#define O_NOFOLLOW 0x20000L
#define O_CLOEXEC 0x80000L
#define APP_SIZE 89027992u
#define MAX_PREAD_CALLS 64u

static const char app_path[] = "/usr/lib/appFw.so";
static const uint64_t app_offsets[PLAYBACK_GENERAL_TRANSFER_READER_WINDOW_COUNT] = {
    0x03788e00u, 0x03788c00u
};

#ifdef PLAYBACK_GENERAL_TRANSFER_READER_TEST
extern intptr_t playback_general_transfer_test_call4(
    intptr_t number, intptr_t a, intptr_t b, intptr_t c, intptr_t d);
static intptr_t call4(intptr_t number, intptr_t a, intptr_t b,
                      intptr_t c, intptr_t d) {
    return playback_general_transfer_test_call4(number, a, b, c, d);
}
#else
static intptr_t call4(intptr_t number, intptr_t a, intptr_t b,
                      intptr_t c, intptr_t d) {
    register long x8 __asm__("x8") = (long)number;
    register long x0 __asm__("x0") = (long)a;
    register long x1 __asm__("x1") = (long)b;
    register long x2 __asm__("x2") = (long)c;
    register long x3 __asm__("x3") = (long)d;
    __asm__ volatile("svc #0" : "+r"(x0) : "r"(x8), "r"(x1), "r"(x2), "r"(x3)
                     : "memory", "cc");
    return (intptr_t)x0;
}
#endif

static int app_file_safe(int fd, uint64_t stat_words[16]) {
    if (call4(SYS_FSTAT, fd, (intptr_t)stat_words, 0, 0) < 0) return 0;
    return (((uint32_t)stat_words[2] & 0170000u) == 0100000u &&
            stat_words[6] == APP_SIZE);
}

/* Exclude access-time changes caused by these read-only reads. */
static int stable_file_metadata(const uint64_t before[16],
                                const uint64_t after[16]) {
    static const unsigned fields[] = {0, 1, 2, 3, 4, 6, 11, 12, 13, 14};
    for (unsigned i = 0; i < sizeof(fields) / sizeof(fields[0]); i++) {
        if (before[fields[i]] != after[fields[i]]) return 0;
    }
    return 1;
}

static int pread_exact(int fd, uint8_t *output, size_t length, uint64_t offset) {
    size_t completed = 0;
    unsigned calls = 0;
    while (completed < length && calls++ < MAX_PREAD_CALLS) {
        intptr_t count = call4(SYS_PREAD64, fd, (intptr_t)(output + completed),
                               (intptr_t)(length - completed),
                               (intptr_t)(offset + completed));
        if (count == -4) continue;
        if (count <= 0 || (size_t)count > length - completed) return -1;
        completed += (size_t)count;
    }
    return completed == length ? 0 : -1;
}

int playback_general_transfer_read(uint8_t *output, size_t capacity) {
    if (output == 0 || capacity != PLAYBACK_GENERAL_TRANSFER_READER_OUTPUT_BYTES)
        return -1;

    intptr_t fd = call4(SYS_OPENAT, AT_FDCWD, (intptr_t)app_path,
                        O_RDONLY | O_NOFOLLOW | O_CLOEXEC, 0);
    if (fd < 0) return -1;

    uint64_t before[16] = {0};
    uint64_t after[16] = {0};
    int result = -1;
    if (app_file_safe((int)fd, before)) {
        result = 0;
        for (unsigned i = 0; i < PLAYBACK_GENERAL_TRANSFER_READER_WINDOW_COUNT; i++) {
            uint8_t *window = output + i * PLAYBACK_GENERAL_TRANSFER_READER_WINDOW_BYTES;
            if (pread_exact((int)fd, window,
                            PLAYBACK_GENERAL_TRANSFER_READER_WINDOW_BYTES,
                            app_offsets[i]) != 0) {
                result = -1;
                break;
            }
        }
        if (result == 0 &&
            (!app_file_safe((int)fd, after) || !stable_file_metadata(before, after)))
            result = -1;
    }
    if (call4(SYS_CLOSE, fd, 0, 0, 0) < 0) result = -1;
    return result;
}
