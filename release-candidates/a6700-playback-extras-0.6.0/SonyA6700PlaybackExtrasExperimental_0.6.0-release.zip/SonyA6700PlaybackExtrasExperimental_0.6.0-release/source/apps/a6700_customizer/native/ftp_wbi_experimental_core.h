/* SPDX-License-Identifier: GPL-3.0-only
 * Experimental FTP WBI writer core, informed by the original a6700_unlock
 * GPLv3 fixed-profile transaction protocol. This is not an enabled installer.
 */
#ifndef FTP_WBI_EXPERIMENTAL_CORE_H
#define FTP_WBI_EXPERIMENTAL_CORE_H
#include <stddef.h>
#include <stdint.h>

#define FTP_WBI_SECTOR_BYTES 512u
#define FTP_WBI_HEADER_BYTES 56u

struct ftp_wbi_change { uint16_t position; uint8_t before; uint8_t after; };
struct ftp_wbi_target { uint64_t offset; uint16_t profile_index; uint16_t first_change; uint16_t change_count; };
struct ftp_wbi_profile {
    const struct ftp_wbi_target *targets;
    const struct ftp_wbi_change *changes;
    const uint8_t *digest;
    uint32_t target_count;
    uint32_t change_count;
};
struct ftp_wbi_result { uint32_t status, failed_index, attempted, verified, uncertain; };
struct ftp_wbi_ops {
    int (*open)(void *ctx);
    long (*read)(void *ctx, uint64_t offset, uint8_t *buffer, uint32_t length);
    long (*write)(void *ctx, uint64_t offset, const uint8_t *buffer, uint32_t length);
    int (*sync)(void *ctx);
    int (*close)(void *ctx);
};
/* One call only per selected operation. No retry, rollback, or deletion. */
int ftp_wbi_experimental(const struct ftp_wbi_profile *profile,
                         const uint8_t *request, size_t request_bytes,
                         const struct ftp_wbi_ops *ops, void *ctx,
                         struct ftp_wbi_result *result);
#endif
