/* SPDX-License-Identifier: GPL-3.0-only
 * Experimental read-only, fixed-profile playback extras evidence probe.
 * Derived from the existing Jiritsu staging pattern; never executed on camera.
 * The three WBI device-file positions are ASSUMED mappings, not qualified
 * physical addresses. Both targets are opened O_RDONLY; the temporary Jiritsu request
 * inode is changed to publish the response. No camera-file cleanup or retry.
 *
 * Request: 56 bytes, A6XQ | LE32(1) | nonce[16] | profile digest[32].
 * Response: A6XR | LE32(1) | nonce[16] | LE32(status, count, failed, flags),
 * followed by seven 512-byte sectors only on status zero. Flags must be zero.
 * status: 1=open target, 2=read failed/short, 3=close target failed,
 * 4=App metadata mismatch or unavailable.
 * count is completed sector reads; failed is zero-based or UINT32_MAX.
 * An invalid request or failed temporary publication may yield no response.
 * A complete host response does not authenticate a body or prove durability.
 */
#include <stdint.h>
#include <stddef.h>

#define SYS_FTRUNCATE 46L
#define SYS_OPENAT 56L
#define SYS_CLOSE 57L
#define SYS_LSEEK 62L
#define SYS_WRITE 64L
#define SYS_PREAD64 67L
#define SYS_PWRITE64 68L /* used solely for the temporary response status */
#define SYS_FSTAT 80L
#define SYS_FSYNC 82L
#define AT_FDCWD (-100L)
#define O_RDWR 2L
#define O_NOFOLLOW 0x20000L
#define O_CLOEXEC 0x80000L
#define REQUEST_BYTES 56u
#define RESPONSE_HEADER 40u
#define SECTOR_BYTES 512u
#define SECTOR_COUNT 7u
static const char stage[] = "/tmp/jiritsu/tmmc.jit";
static const char app[] = "/usr/lib/appFw.so";
static const char wbi[] = "/dev/nflasha5";
static const uint32_t offsets[SECTOR_COUNT] = {0x04bca200u,0x04c0b400u,0x04c36a00u,
                                              0x02514400u,0x02586600u,0x025c1c00u,0x03788e00u};
static const uint8_t target_group[SECTOR_COUNT] = {0,0,0,1,1,1,0};
static const uint8_t digest[32] = {
    0x23,0xea,0x10,0xa9,0x6a,0x7a,0x7a,0x8e,0x47,0x9c,0x1e,0x2c,0xcf,0xeb,0xd7,0xc9,
    0xd8,0xff,0x64,0xe0,0x12,0xd8,0xd2,0xc1,0x26,0xc2,0xad,0xcc,0x11,0x90,0xfc,0x72
};
static uint8_t request[REQUEST_BYTES];
static uint8_t response[RESPONSE_HEADER + SECTOR_COUNT * SECTOR_BYTES];

#ifdef PLAYBACK_EXTRAS_PROBE_TEST
extern intptr_t playback_extras_probe_test_call4(intptr_t n,intptr_t a,intptr_t b,intptr_t c,intptr_t d);
static intptr_t call4(intptr_t n,intptr_t a,intptr_t b,intptr_t c,intptr_t d) {
    return playback_extras_probe_test_call4(n,a,b,c,d);
}
#else
static intptr_t call4(intptr_t n,intptr_t a,intptr_t b,intptr_t c,intptr_t d) {
    register long x8 __asm__("x8")=n, x0 __asm__("x0")=a;
    register long x1 __asm__("x1")=b, x2 __asm__("x2")=c, x3 __asm__("x3")=d;
    __asm__ volatile("svc #0" : "+r"(x0) : "r"(x8),"r"(x1),"r"(x2),"r"(x3) : "memory","cc");
    return x0;
}
#endif

static void put32(unsigned pos,uint32_t value) {
    for (unsigned i=0;i<4;i++) response[pos+i]=(uint8_t)(value>>(8*i));
}
static int request_file_safe(intptr_t fd) {
    /* AArch64 Linux stat: mode/nlink at bytes 16/20, st_size at 48. */
    uint64_t st[16]={0};
    if (call4(SYS_FSTAT,fd,(intptr_t)st,0,0)<0) return 0;
    uint32_t mode=(uint32_t)st[2], links=(uint32_t)(st[2]>>32);
    return (mode & 0170000u)==0100000u && links==1u && st[6]==REQUEST_BYTES;
}
static int app_file_safe(intptr_t fd) {
    uint64_t st[16]={0};
    return call4(SYS_FSTAT,fd,(intptr_t)st,0,0)>=0 &&
           ((uint32_t)st[2] & 0170000u)==0100000u && st[6]==89027992u;
}
static int request_valid(void) {
    unsigned nonce=0;
    if (request[0]!='A' || request[1]!='6' || request[2]!='X' || request[3]!='Q' ||
        request[4]!=1 || request[5] || request[6] || request[7]) return 0;
    for (unsigned i=0;i<16;i++) nonce|=request[8+i];
    if (!nonce) return 0;
    for (unsigned i=0;i<32;i++) if (request[24+i]!=digest[i]) return 0;
    return 1;
}
static void publish(intptr_t fd,uint32_t status,uint32_t count,uint32_t failed) {
    const uint8_t success[4]={0,0,0,0};
    unsigned length=status ? RESPONSE_HEADER : sizeof(response);
    response[0]='A'; response[1]='6'; response[2]='X'; response[3]='R';
    put32(4,1);
    for (unsigned i=0;i<16;i++) response[8+i]=request[8+i];
    put32(24,status ? status : UINT32_MAX); /* success committed only after body sync */
    put32(28,count); put32(32,failed); put32(36,0);
    if (!request_file_safe(fd) || call4(SYS_FTRUNCATE,fd,0,0,0)<0 ||
        call4(SYS_LSEEK,fd,0,0,0)!=0) return;
    if (call4(SYS_WRITE,fd,(intptr_t)response,length,0)!=(intptr_t)length) return;
    if (call4(SYS_FSYNC,fd,0,0,0)!=0) return;
    if (!status) {
        if (call4(SYS_PWRITE64,fd,(intptr_t)success,4,24)!=4) return;
        (void)call4(SYS_FSYNC,fd,0,0,0);
    }
}

#ifdef PLAYBACK_EXTRAS_PROBE_TEST
void playback_extras_probe_test_run(void) {
#else
__attribute__((constructor)) static void run(void) {
#endif
    intptr_t stage_fd=call4(SYS_OPENAT,AT_FDCWD,(intptr_t)stage,O_RDWR|O_NOFOLLOW|O_CLOEXEC,0);
    if (stage_fd<0) return;
    if (!request_file_safe(stage_fd) ||
        call4(SYS_PREAD64,stage_fd,(intptr_t)request,REQUEST_BYTES,0)!=REQUEST_BYTES ||
        !request_valid()) { (void)call4(SYS_CLOSE,stage_fd,0,0,0); return; }
    uint32_t status=0,count=0,failed=UINT32_MAX;
    for (unsigned group=0;group<2 && !status;group++) {
        const char *path=group ? wbi : app;
        failed=group ? 3u : 0u;
        intptr_t target_fd=call4(SYS_OPENAT,AT_FDCWD,(intptr_t)path,O_NOFOLLOW|O_CLOEXEC,0);
        if (target_fd<0) { status=1; break; }
        if (!group && !app_file_safe(target_fd)) status=4;
        for (unsigned i=0; i<SECTOR_COUNT && !status; i++) {
            if (target_group[i]!=group) continue;
            failed=i;
            if (call4(SYS_PREAD64,target_fd,(intptr_t)(response+RESPONSE_HEADER+i*SECTOR_BYTES),
                      SECTOR_BYTES,offsets[i])!=SECTOR_BYTES) { status=2; break; }
            count++;
        }
        if (call4(SYS_CLOSE,target_fd,0,0,0)!=0 && !status) status=3;
    }
    if (!status) failed=UINT32_MAX;
    publish(stage_fd,status,count,failed);
    (void)call4(SYS_CLOSE,stage_fd,0,0,0);
}
