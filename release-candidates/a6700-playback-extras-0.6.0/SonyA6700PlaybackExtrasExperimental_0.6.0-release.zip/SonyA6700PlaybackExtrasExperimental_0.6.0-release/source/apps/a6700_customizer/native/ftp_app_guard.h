#ifndef FTP_APP_GUARD_H
#define FTP_APP_GUARD_H
#include "ftp_read_v2_core.h"
struct ftp_guard_field {
    uint64_t offset;
    uint32_t width;
    uint8_t reference[4], variant[4];
};
#if defined(__ELF__) && (defined(__GNUC__) || defined(__clang__))
__attribute__((visibility("hidden")))
#endif
int ftp_app_guard(app_reader reader, void *ctx, uint64_t size,
                  const struct ftp_guard_field *fields, size_t field_count,
                  const uint8_t expected[32], uint64_t offset, uint32_t length,
                  uint8_t *out);
#endif
