#include "playback_filter_query.h"

#ifndef A6700_PLAYBACK_FREESTANDING
#include <new>
#endif

namespace a6700_playback {

std::uint64_t normalized_date_key(std::uint16_t year, std::uint8_t month,
                                  std::uint8_t day) noexcept {
    // Explicit sign extension avoids implementation-defined uint16->int16
    // narrowing while matching the target converter's signed halfword load.
    const std::int32_t signed_year = year < 0x8000u ? year : std::int32_t(year) - 0x10000;
    const std::uint32_t relative_year = signed_year > 1900 ? signed_year - 1900 : 0;
    return (std::uint64_t(relative_year & 0xffu) << 36) |
           (std::uint64_t(month & 0x0fu) << 32) |
           (std::uint64_t(day & 0x1fu) << 27);
}

bool same_day(std::uint64_t record_col3, std::uint64_t selected_packed) noexcept {
    return ((record_col3 ^ selected_packed) & UINT64_C(0x00000ffff8000000)) == 0;
}

bool same_still_folder(std::uint32_t public_content_type, std::uint16_t record_folder,
                       std::uint16_t selected_folder) noexcept {
    return public_content_type == 1 && record_folder == selected_folder;
}

namespace {

bool selected_status(const Constituent& value, std::uint32_t mask) {
    return value.present && value.status < 32 && ((mask >> value.status) & 1u);
}

}  // namespace

bool ftp_matches(const Query& query, const Record& value) noexcept {
    static const std::uint32_t masks[] = {0x9u, 0x8u, 0x4u};
    const std::uint32_t mask = masks[query.ftp_selection];
    const bool raw = selected_status(value.raw, mask);
    const bool jpeg = selected_status(value.jpeg, mask);
    const bool heif = selected_status(value.heif, mask);
    const bool main = selected_status(value.main_movie, mask);
    const bool proxy = selected_status(value.proxy_movie, mask);
    bool still;
    if (value.raw.present && (value.jpeg.present || value.heif.present)) {
        still = query.still_mode == 0 ? (jpeg || heif) :
                query.still_mode == 1 ? raw : (raw || jpeg || heif);
    } else {
        still = raw || jpeg || heif;
    }
    bool movie;
    if (value.main_movie.present && value.proxy_movie.present) {
        movie = query.movie_mode == 2 ? proxy :
                query.movie_mode == 1 ? main : (main || proxy);
    } else {
        movie = main || proxy;
    }
    return still || movie;
}

GroupDecision group_decision(std::uint32_t key, std::uint32_t& last,
                             const std::uint32_t* seen, std::size_t count) noexcept {
    if ((key & 0x00ffffffu) == 0) return GroupDecision::keep;
    if (key == last) return GroupDecision::skip;
    last = key;
    while (count) if (seen[--count] == key) return GroupDecision::skip;
    return GroupDecision::remember;
}

#ifndef A6700_PLAYBACK_FREESTANDING
QueryStatus run_query(const Query& query, const std::vector<std::uint32_t>& source,
                      const Reader& reader, std::vector<std::uint32_t>& output) noexcept {
    if ((query.ftp_enabled && (query.ftp_selection > 2 || query.still_mode > 2 || query.movie_mode > 2)) ||
        ((query.ftp_enabled || query.collapse_groups) && !reader.record) ||
        (query.other_criteria_enabled && !reader.other_criteria))
        return QueryStatus::invalid_query;
    bool in_other_predicate = false;
    try {
        std::vector<std::uint32_t> candidate;
        std::vector<std::uint32_t> seen;
        std::uint32_t last = 0xffffffffu;
        for (std::uint32_t id : source) {
            const std::uint32_t slot = id & 0x1ffffu;
            if (query.other_criteria_enabled) {
                in_other_predicate = true;
                const Match matched = reader.other_criteria(reader.context, slot);
                in_other_predicate = false;
                if (matched == Match::no) continue;
                if (matched != Match::yes) return QueryStatus::predicate_error;
            }
            if (query.ftp_enabled || query.collapse_groups) {
                Record value = {};
                if (!reader.record(reader.context, slot, value)) return QueryStatus::read_error;
                if (query.ftp_enabled && !ftp_matches(query, value)) continue;
                if (query.collapse_groups) {
                    const GroupDecision decision = group_decision(value.group_key, last, seen.data(), seen.size());
                    if (decision == GroupDecision::skip) continue;
                    if (decision == GroupDecision::remember) seen.push_back(value.group_key);
                }
            }
            candidate.push_back(id);
        }
        output.swap(candidate);
        return QueryStatus::ok;
    } catch (const std::bad_alloc&) {
        return QueryStatus::allocation_error;
    } catch (...) {
        // Provider/predicate exceptions are failures, never false matches.
        return in_other_predicate ? QueryStatus::predicate_error : QueryStatus::read_error;
    }
}
#endif

}  // namespace a6700_playback
