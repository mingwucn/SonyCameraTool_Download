#ifndef A6700_PLAYBACK_FILTER_REGISTRY_H
#define A6700_PLAYBACK_FILTER_REGISTRY_H
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

enum { A6700_FILTER_SELECTOR_BASE = 0x100, A6700_FILTER_REGISTRY_CAPACITY = 64 };

/* Caller transfers an immutable, process-lifetime native sidb::set wrapper.
 * No database record or native C++ ownership is inferred by this POD table. */
typedef struct {
    void *native_set;
    uint32_t count;
    uint32_t media;
    uint64_t generation;
    uint64_t reserved;
} A6700FilterEntry;

typedef struct {
    uint32_t used;
    uint32_t reserved;
    uint64_t reserved2;
    A6700FilterEntry entries[A6700_FILTER_REGISTRY_CAPACITY];
} A6700FilterRegistry;

#if defined(__aarch64__) && defined(__ELF__)
/* Direct PC-relative reference in the injected image, never an absolute GOT
 * entry which the original App dynamic relocations do not know about. */
extern __attribute__((visibility("hidden"))) A6700FilterRegistry a6700_filter_registry;
#else
extern A6700FilterRegistry a6700_filter_registry;
#endif

/* Registry must initially be all-zero allocated storage. Returns 0 on success,
 * 1 on invalid input, 2 at capacity. Failure preserves the caller's selector.
 * Retain every published native wrapper and backing until process exit.
 * The caller separately serializes freshness checks and Sony model publication.
 */
int a6700_filter_register(A6700FilterRegistry *, void *native_set, uint32_t count,
                         uint32_t media, uint64_t generation, uint32_t *selector);
const A6700FilterEntry *a6700_filter_lookup(const A6700FilterRegistry *, uint32_t selector);

#ifdef __cplusplus
}
#endif
#endif
