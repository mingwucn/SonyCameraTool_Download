#ifndef A6700_PLAYBACK_FILTER_SONY_H
#define A6700_PLAYBACK_FILTER_SONY_H

#include "playback_filter_query.h"

namespace a6700_playback {

// Target sidb::set wrapper, constructed/destructed by Sony's own functions.
// Its C++ members, backing tree and mutex remain opaque to authored code.
struct alignas(8) SonySet { unsigned char opaque[0x20]; };

struct SonyApi {
    void (*construct)(SonySet*);
    void (*destroy)(SonySet*);
    std::uint32_t (*size)(const SonySet*);
    std::uint32_t (*at)(const SonySet*, std::uint32_t);
    void (*append)(SonySet*, std::uint32_t);
    int (*root)(std::uint32_t, std::uint32_t, bool, bool, SonySet*);
    int (*get_bool)(std::uint32_t, std::uint32_t, std::uint32_t, bool*);
    int (*get_u16)(std::uint32_t, std::uint32_t, std::uint32_t, std::uint16_t*);
    int (*get_u32)(std::uint32_t, std::uint32_t, std::uint32_t, std::uint32_t*);
    int (*get_u64)(std::uint32_t, std::uint32_t, std::uint32_t, std::uint64_t*);
    void* media_converter;
    unsigned char* database_locks;
    std::uint32_t (*database_slot)(void*, std::uint32_t);
    int (*database_read_lock)(void*);
    int (*database_unlock)(void*);
    std::uint32_t (*search)(const SonySet*, std::uint32_t);
};

typedef void* (*SonyDlsym)(void*, const char*);
// Resolve already-loaded libmpr exports; no dlopen, load, driver or IO action.
// The profile must separately qualify the complete App/provider identities.
// Failure leaves the caller's API unchanged. No unresolved function is called.
bool sony_resolve_api(SonyDlsym resolve, SonyApi& result) noexcept;

// Match native ComplexRefine: map the public media ID to a database slot and
// take that slot's native read lock. GetValue<T> takes the converted slot,
// whereas root() takes the public media ID. The returned lock is released by
// sony_database_leave. Caller first owns the App's ordinary SIDB API guard.
// These helpers do not claim a database epoch or establish lock ordering with
// later model publication; that integration must preserve the native order.
bool sony_database_enter(const SonyApi& api, std::uint32_t media_id,
                         std::uint32_t& database_slot, void*& lock) noexcept;
bool sony_database_leave(const SonyApi& api, void* lock) noexcept;

struct SonyCriteria {
    Query query;
    bool date_enabled;
    bool folder_enabled;
    const std::uint64_t* dates;      // normalized day keys; owned snapshot
    std::uint32_t date_count;       // 1..100 when enabled
    const std::uint16_t* folders;   // qualified occupied still-folder numbers
    std::uint32_t folder_count;     // 1..900 when enabled
    bool unsupported_enabled;      // any checked criterion not represented here
    bool exclude_col62;            // target pre-filter kind11, false COL62
    bool current_group_enabled;    // expanded current-group kind5 restriction
    std::uint32_t current_group_key;
};

enum class SonyQueryStatus {
    ok, invalid_query, unsupported_criterion, invalid_binding,
    invalid_destination, insufficient_scratch, read_error, append_error
};

// Synchronous native-set adapter. Source/destination must be distinct, real
// constructed sets and destination must be unpublished and empty. Caller owns
// the native database read lock and keeps its snapshot alive throughout.
// Each returned error invalidates the private candidate; destroy it, never
// publish it. Existing published sets are never touched. Result count changes
// only on success. No STL, exception, global result or selector crosses ABI.
// database_slot is the converted slot, never the public media ID.
SonyQueryStatus sony_filter_set(const SonyApi& api, std::uint32_t database_slot,
    const SonySet& source, SonySet& destination, const SonyCriteria& criteria,
    std::uint32_t* seen, std::uint32_t seen_capacity,
    std::uint32_t& result_count) noexcept;

}  // namespace a6700_playback
#endif
