/* SPDX-License-Identifier: GPL-3.0-only
 * Experimental read-only probe for the two App windows used by the general
 * FTP Transfer roster action. This is a constructor wrapper around the
 * separately reviewed playback_general_transfer_read() core. It has no WBI
 * path, no App write path and no key-assignment change.
 *
 * Request: A6XQ | LE32(1) | nonce[16] | profile digest[32].
 * Response: A6XR | LE32(1) | nonce[16] | LE32(status,count,failed,flags),
 * followed by exactly two 512-byte App windows on status zero.
 */
#include "playback_general_transfer_reader.h"

#define SYS_FTRUNCATE 46L
#define SYS_OPENAT 56L
#define SYS_CLOSE 57L
#define SYS_LSEEK 62L
#define SYS_WRITE 64L
#define SYS_PREAD64 67L
#define SYS_PWRITE64 68L
#define SYS_FSTAT 80L
#define SYS_FSYNC 82L
#define AT_FDCWD (-100L)
#define O_RDWR 2L
#define O_NOFOLLOW 0x20000L
#define O_CLOEXEC 0x80000L
#define REQUEST_BYTES 56u
#define RESPONSE_HEADER 40u
#define BODY_BYTES PLAYBACK_GENERAL_TRANSFER_READER_OUTPUT_BYTES
static const char stage[] = "/tmp/jiritsu/tmmc.jit";
static const uint8_t profile_digest[32] = {
    0xa4,0x4c,0x6c,0x38,0x06,0x2d,0x67,0x11,0x41,0xd2,0xb4,0x16,0xcf,0xe8,0x23,0x4b,
    0x15,0xf8,0xac,0xb3,0xe6,0x7e,0x79,0x7c,0x4f,0x86,0x8f,0x32,0x35,0xc1,0x14,0x15
};
static uint8_t request[REQUEST_BYTES];
static uint8_t response[RESPONSE_HEADER + BODY_BYTES];

#ifdef PLAYBACK_GENERAL_TRANSFER_PROBE_TEST
extern intptr_t playback_general_transfer_probe_test_call4(
    intptr_t, intptr_t, intptr_t, intptr_t, intptr_t);
static intptr_t call4(intptr_t n, intptr_t a, intptr_t b, intptr_t c, intptr_t d) {
    return playback_general_transfer_probe_test_call4(n, a, b, c, d);
}
#else
static intptr_t call4(intptr_t n, intptr_t a, intptr_t b, intptr_t c, intptr_t d) {
    register long x8 __asm__("x8") = n, x0 __asm__("x0") = a;
    register long x1 __asm__("x1") = b, x2 __asm__("x2") = c, x3 __asm__("x3") = d;
    __asm__ volatile("svc #0" : "+r"(x0) : "r"(x8), "r"(x1), "r"(x2), "r"(x3)
                     : "memory", "cc");
    return x0;
}
#endif

static void put32(unsigned pos, uint32_t value) {
    for (unsigned i = 0; i < 4; i++) response[pos + i] = (uint8_t)(value >> (8 * i));
}

static int stage_file_safe(intptr_t fd) {
    /* AArch64 Linux stat: mode/nlink at bytes 16/20, st_size at 48. */
    uint64_t st[16] = {0};
    if (call4(SYS_FSTAT, fd, (intptr_t)st, 0, 0) < 0) return 0;
    uint32_t mode = (uint32_t)st[2], links = (uint32_t)(st[2] >> 32);
    return (mode & 0170000u) == 0100000u && links == 1u && st[6] == REQUEST_BYTES;
}

static int request_valid(void) {
    unsigned nonce_nonzero = 0;
    if (request[0] != 'A' || request[1] != '6' || request[2] != 'X' || request[3] != 'Q' ||
        request[4] != 1 || request[5] || request[6] || request[7]) return 0;
    for (unsigned i = 0; i < 16; i++) nonce_nonzero |= request[8 + i];
    if (!nonce_nonzero) return 0;
    for (unsigned i = 0; i < 32; i++) if (request[24 + i] != profile_digest[i]) return 0;
    return 1;
}

static void publish(intptr_t fd, uint32_t status) {
    const uint8_t success[4] = {0, 0, 0, 0};
    unsigned length = status ? RESPONSE_HEADER : sizeof(response);
    response[0] = 'A'; response[1] = '6'; response[2] = 'X'; response[3] = 'R';
    put32(4, 1);
    for (unsigned i = 0; i < 16; i++) response[8 + i] = request[8 + i];
    put32(24, status ? status : UINT32_MAX);
    put32(28, status ? 0u : PLAYBACK_GENERAL_TRANSFER_READER_WINDOW_COUNT);
    put32(32, status ? 0u : UINT32_MAX);
    put32(36, 0);
    if (!stage_file_safe(fd) || call4(SYS_FTRUNCATE, fd, 0, 0, 0) < 0 ||
        call4(SYS_LSEEK, fd, 0, 0, 0) != 0) return;
    if (call4(SYS_WRITE, fd, (intptr_t)response, length, 0) != (intptr_t)length) return;
    if (call4(SYS_FSYNC, fd, 0, 0, 0) != 0) return;
    if (!status) {
        if (call4(SYS_PWRITE64, fd, (intptr_t)success, 4, 24) != 4) return;
        (void)call4(SYS_FSYNC, fd, 0, 0, 0);
    }
}

#ifdef PLAYBACK_GENERAL_TRANSFER_PROBE_TEST
void playback_general_transfer_probe_test_run(void) {
#else
__attribute__((constructor)) static void run(void) {
#endif
    intptr_t fd = call4(SYS_OPENAT, AT_FDCWD, (intptr_t)stage,
                        O_RDWR | O_NOFOLLOW | O_CLOEXEC, 0);
    if (fd < 0) return;
    if (!stage_file_safe(fd) ||
        call4(SYS_PREAD64, fd, (intptr_t)request, REQUEST_BYTES, 0) != REQUEST_BYTES ||
        !request_valid()) {
        (void)call4(SYS_CLOSE, fd, 0, 0, 0);
        return;
    }
    uint32_t status = playback_general_transfer_read(
        response + RESPONSE_HEADER, BODY_BYTES) == 0 ? 0u : 2u;
    publish(fd, status);
    (void)call4(SYS_CLOSE, fd, 0, 0, 0);
}
