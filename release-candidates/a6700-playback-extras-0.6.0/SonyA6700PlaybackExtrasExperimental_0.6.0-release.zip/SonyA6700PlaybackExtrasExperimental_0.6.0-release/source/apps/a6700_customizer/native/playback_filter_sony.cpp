#include "playback_filter_sony.h"

namespace a6700_playback {

bool sony_resolve_api(SonyDlsym resolve, SonyApi& result) noexcept {
    if (!resolve) return false;
    SonyApi next;
    next.construct = reinterpret_cast<void (*)(SonySet*)>(resolve(nullptr, "_ZN4sidb3setC1Ev"));
    next.destroy = reinterpret_cast<void (*)(SonySet*)>(resolve(nullptr, "_ZN4sidb3setD1Ev"));
    next.size = reinterpret_cast<std::uint32_t (*)(const SonySet*)>(resolve(nullptr, "_ZNK4sidb3set4sizeEv"));
    next.at = reinterpret_cast<std::uint32_t (*)(const SonySet*, std::uint32_t)>(resolve(nullptr, "_ZNK4sidb3set2atEj"));
    next.append = reinterpret_cast<void (*)(SonySet*, std::uint32_t)>(resolve(nullptr, "_ZN4sidb3set9push_backEj"));
    next.root = reinterpret_cast<int (*)(std::uint32_t, std::uint32_t, bool, bool, SonySet*)>(resolve(nullptr, "_ZN4sidb10GetRootSetEjNS_13ROOT_SET_TYPEEbbPNS_3setE"));
    next.get_bool = reinterpret_cast<int (*)(std::uint32_t, std::uint32_t, std::uint32_t, bool*)>(resolve(nullptr, "_ZN4sidb8GetValueIbEEijNS_6COL_IDEjPT_"));
    next.get_u16 = reinterpret_cast<int (*)(std::uint32_t, std::uint32_t, std::uint32_t, std::uint16_t*)>(resolve(nullptr, "_ZN4sidb8GetValueItEEijNS_6COL_IDEjPT_"));
    next.get_u32 = reinterpret_cast<int (*)(std::uint32_t, std::uint32_t, std::uint32_t, std::uint32_t*)>(resolve(nullptr, "_ZN4sidb8GetValueIjEEijNS_6COL_IDEjPT_"));
    next.get_u64 = reinterpret_cast<int (*)(std::uint32_t, std::uint32_t, std::uint32_t, std::uint64_t*)>(resolve(nullptr, "_ZN4sidb8GetValueImEEijNS_6COL_IDEjPT_"));
    next.media_converter = resolve(nullptr, "_ZN4sidb10g_msidconvE");
    next.database_locks = static_cast<unsigned char*>(resolve(nullptr, "_ZN4sidb8g_rwlockE"));
    next.database_slot = reinterpret_cast<std::uint32_t (*)(void*, std::uint32_t)>(resolve(nullptr, "_ZN3mpr8msidconv9GetSlotIDEj"));
    next.database_read_lock = reinterpret_cast<int (*)(void*)>(resolve(nullptr, "pthread_rwlock_rdlock"));
    next.database_unlock = reinterpret_cast<int (*)(void*)>(resolve(nullptr, "pthread_rwlock_unlock"));
    next.search = reinterpret_cast<std::uint32_t (*)(const SonySet*, std::uint32_t)>(resolve(nullptr, "_ZNK4sidb3set6searchEj"));
    if (!next.construct || !next.destroy || !next.size || !next.at || !next.append ||
        !next.root || !next.get_bool || !next.get_u16 || !next.get_u32 || !next.get_u64 ||
        !next.media_converter || !next.database_locks || !next.database_slot ||
        !next.database_read_lock || !next.database_unlock || !next.search)
        return false;
    result = next;
    return true;
}

bool sony_database_enter(const SonyApi& api, std::uint32_t media_id,
                         std::uint32_t& slot, void*& lock) noexcept {
    if (!api.media_converter || !api.database_locks || !api.database_slot ||
        !api.database_read_lock || !api.database_unlock || media_id == 0xffffffffu)
        return false;
    const std::uint32_t candidate_slot = api.database_slot(api.media_converter, media_id);
    if (candidate_slot >= 4) return false;
    // g_rwlock is a 0x40-stride array; native rwLock::rdlock/unlock forward
    // this+8 to the corresponding pthread function.
    void* candidate_lock = api.database_locks + candidate_slot * 0x40u + 8u;
    if (api.database_read_lock(candidate_lock) != 0) return false;
    slot = candidate_slot;
    lock = candidate_lock;
    return true;
}

bool sony_database_leave(const SonyApi& api, void* lock) noexcept {
    return lock && api.database_unlock && api.database_unlock(lock) == 0;
}

namespace {

bool read_constituent(const SonyApi& api, std::uint32_t media, std::uint32_t slot,
                      std::uint32_t present_column, std::uint32_t status_column,
                      Constituent& value) noexcept {
    value.present = false;
    value.status = 0;
    if (api.get_bool(media, present_column, slot, &value.present) != 0) return false;
    // An absent format's status is not required or read.
    return !value.present || api.get_u32(media, status_column, slot, &value.status) == 0;
}

bool read_ftp(const SonyApi& api, std::uint32_t media, std::uint32_t slot,
              Record& value) noexcept {
    return read_constituent(api, media, slot, 0xd, 0x1f, value.raw) &&
           read_constituent(api, media, slot, 0xc, 0x1b, value.jpeg) &&
           read_constituent(api, media, slot, 0xe, 0x1d, value.heif) &&
           read_constituent(api, media, slot, 0x10, 0x22, value.main_movie) &&
           read_constituent(api, media, slot, 0x13, 0x23, value.proxy_movie);
}

Match other_match(const SonyApi& api, std::uint32_t media, std::uint32_t slot,
                   const SonyCriteria& c) noexcept {
    if (c.exclude_col62) {
        bool excluded;
        if (api.get_bool(media, 0x62, slot, &excluded) != 0) return Match::error;
        if (excluded) return Match::no;
    }
    if (c.current_group_enabled) {
        std::uint32_t key;
        if (api.get_u32(media, 2, slot, &key) != 0) return Match::error;
        if (key != c.current_group_key) return Match::no;
    }
    if (c.date_enabled) {
        std::uint64_t date;
        if (api.get_u64(media, 3, slot, &date) != 0) return Match::error;
        bool found = false;
        for (std::uint32_t i = 0; i < c.date_count; ++i)
            if (same_day(date, c.dates[i])) { found = true; break; }
        if (!found) return Match::no;
    }
    if (c.folder_enabled) {
        std::uint32_t type;
        if (api.get_u32(media, 0, slot, &type) != 0) return Match::error;
        if (type != 1) return Match::no;
        std::uint16_t folder;
        if (api.get_u16(media, 5, slot, &folder) != 0) return Match::error;
        bool found = false;
        for (std::uint32_t i = 0; i < c.folder_count; ++i)
            if (same_still_folder(type, folder, c.folders[i])) { found = true; break; }
        if (!found) return Match::no;
    }
    return Match::yes;
}

} // namespace

SonyQueryStatus sony_filter_set(const SonyApi& api, std::uint32_t media,
    const SonySet& source, SonySet& destination, const SonyCriteria& c,
    std::uint32_t* seen, std::uint32_t seen_capacity,
    std::uint32_t& result_count) noexcept {
    if (c.unsupported_enabled ||
        (c.query.other_criteria_enabled && !c.date_enabled && !c.folder_enabled))
        return SonyQueryStatus::unsupported_criterion;
    if (media >= 4 ||
        (c.query.ftp_enabled && (c.query.ftp_selection > 2 || c.query.still_mode > 2 || c.query.movie_mode > 2)) ||
        (c.date_enabled && (!c.dates || !c.date_count || c.date_count > 100)) ||
        (c.folder_enabled && (!c.folders || !c.folder_count || c.folder_count > 900)))
        return SonyQueryStatus::invalid_query;
    if (!api.size || !api.at || !api.append ||
        ((c.query.ftp_enabled || c.exclude_col62) && !api.get_bool) ||
        (c.query.ftp_enabled && !api.get_u32) ||
        (c.current_group_enabled && !api.get_u32) ||
        (c.query.collapse_groups && !api.get_u32) ||
        (c.date_enabled && !api.get_u64) ||
        (c.folder_enabled && (!api.get_u16 || !api.get_u32)))
        return SonyQueryStatus::invalid_binding;
    if (&source == &destination || api.size(&destination) != 0)
        return SonyQueryStatus::invalid_destination;
    // Native ComplexRefine stores the public media ID in destination+0;
    // GetRootSet put the same ID at source+0. The default constructor leaves
    // this word uninitialized, so it must be carried with accepted IDs.
    for (unsigned i = 0; i != 4; ++i) destination.opaque[i] = source.opaque[i];
    const std::uint32_t length = api.size(&source);
    if (c.query.collapse_groups && (seen_capacity < length || (length && !seen)))
        return SonyQueryStatus::insufficient_scratch;
    std::uint32_t count = 0, seen_count = 0, last = 0xffffffffu;
    for (std::uint32_t i = 0; i < length; ++i) {
        const std::uint32_t full_id = api.at(&source, i);
        const std::uint32_t slot = full_id & 0x1ffffu;
        const Match matched = other_match(api, media, slot, c);
        if (matched == Match::error) return SonyQueryStatus::read_error;
        if (matched == Match::no) continue;
        Record value = {};
        if (c.query.ftp_enabled) {
            if (!read_ftp(api, media, slot, value)) return SonyQueryStatus::read_error;
            if (!ftp_matches(c.query, value)) continue;
        }
        if (c.query.collapse_groups) {
            if (api.get_u32(media, 2, slot, &value.group_key) != 0)
                return SonyQueryStatus::read_error;
            const GroupDecision decision = group_decision(value.group_key, last, seen, seen_count);
            if (decision == GroupDecision::skip) continue;
            if (decision == GroupDecision::remember) seen[seen_count++] = value.group_key;
        }
        api.append(&destination, full_id);
        ++count;
        if (api.size(&destination) != count) return SonyQueryStatus::append_error;
    }
    result_count = count;
    return SonyQueryStatus::ok;
}

} // namespace a6700_playback
