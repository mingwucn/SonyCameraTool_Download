/* Offline-qualified only. Normalized SHA-256 of a complete App stream; no OS
 * calls or writes. Known fields are canonicalized only in hash input. Output
 * always retains observed bytes, including English. Not a body attestation or
 * an atomic snapshot. Reader must fill exactly the requested bytes on success.
 * SHA-256 algorithm: FIPS 180-4 sections 4.2.2, 5.3.3 and 6.2. */
#include "ftp_app_guard.h"
struct sha256 { uint32_t h[8]; uint64_t total; uint8_t block[64]; size_t used; };
static uint32_t rotr(uint32_t x, unsigned n) { return (x>>n)|(x<<(32-n)); }
static void compress(struct sha256 *s, const uint8_t *p) {
    static const uint32_t k[64]={
        0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
        0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
        0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
        0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
        0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
        0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
        0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
        0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2};
    uint32_t w[64],a,b,c,d,e,f,g,h;
    for (unsigned i=0;i<16;i++) w[i]=((uint32_t)p[i*4]<<24)|((uint32_t)p[i*4+1]<<16)|((uint32_t)p[i*4+2]<<8)|p[i*4+3];
    for (unsigned i=16;i<64;i++) {
        uint32_t x=w[i-15], y=w[i-2];
        w[i]=w[i-16]+(rotr(x,7)^rotr(x,18)^(x>>3))+w[i-7]+(rotr(y,17)^rotr(y,19)^(y>>10));
    }
    a=s->h[0];b=s->h[1];c=s->h[2];d=s->h[3];e=s->h[4];f=s->h[5];g=s->h[6];h=s->h[7];
    for (unsigned i=0;i<64;i++) {
        uint32_t t=h+(rotr(e,6)^rotr(e,11)^rotr(e,25))+((e&f)^((~e)&g))+k[i]+w[i];
        uint32_t u=(rotr(a,2)^rotr(a,13)^rotr(a,22))+((a&b)^(a&c)^(b&c));
        h=g;g=f;f=e;e=d+t;d=c;c=b;b=a;a=t+u;
    }
    s->h[0]+=a;s->h[1]+=b;s->h[2]+=c;s->h[3]+=d;s->h[4]+=e;s->h[5]+=f;s->h[6]+=g;s->h[7]+=h;
}
static void update(struct sha256 *s, const uint8_t *p, size_t n) {
    s->total+=n;
    while (n) {
        size_t part=64-s->used; if (part>n) part=n;
        for (size_t i=0;i<part;i++) s->block[s->used+i]=p[i];
        s->used+=part;p+=part;n-=part;
        if (s->used==64) { compress(s,s->block);s->used=0; }
    }
}
static void finish(struct sha256 *s, uint8_t digest[32]) {
    uint64_t bits=s->total*8; uint8_t pad[64]={0x80};
    size_t count=s->used<56 ? 56-s->used : 120-s->used;
    update(s,pad,count);
    uint8_t end[8]; for (unsigned i=0;i<8;i++) end[7-i]=(uint8_t)(bits>>(8*i));
    update(s,end,8);
    for (unsigned i=0;i<32;i++) digest[i]=(uint8_t)(s->h[i/4]>>(24-8*(i%4)));
}
static void capture(uint64_t pos, const uint8_t *p, size_t n,
                    uint64_t offset, uint32_t length, uint8_t *out) {
    uint64_t lo=pos>offset ? pos : offset;
    uint64_t hi=pos+n<offset+length ? pos+n : offset+length;
    for (uint64_t i=lo;i<hi;i++) out[i-offset]=p[i-pos];
}
int ftp_app_guard(app_reader reader, void *ctx, uint64_t size,
                  const struct ftp_guard_field *fields, size_t field_count,
                  const uint8_t expected[32], uint64_t offset, uint32_t length,
                  uint8_t *out) {
    /* One session owns the adapter. Static scratch avoids a large helper stack;
     * this routine deliberately has no concurrent/reentrant calling contract. */
    static uint8_t scratch[65536];
    struct sha256 sha={{0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,
                        0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19},0,{0},0};
    uint64_t pos=0,previous=0;
    if (!reader || !expected || size>128ULL*1024*1024 || field_count>256 ||
        (field_count && !fields) || (length && !out) || offset>size || length>size-offset) return -1;
    for (size_t i=0;i<field_count;i++) {
        const struct ftp_guard_field *f=fields+i;
        if (!f->width || f->width>4 || f->offset<previous || f->offset>size || f->width>size-f->offset) return -1;
        previous=f->offset+f->width;
    }
    for (size_t i=0;i<=field_count;i++) {
        uint64_t stop=i==field_count ? size : fields[i].offset;
        while (pos<stop) {
            uint32_t n=(uint32_t)(stop-pos>sizeof(scratch) ? sizeof(scratch) : stop-pos);
            if (reader(pos,n,scratch,ctx)) return -2;
            capture(pos,scratch,n,offset,length,out);update(&sha,scratch,n);pos+=n;
        }
        if (i<field_count) {
            const struct ftp_guard_field *f=fields+i;
            unsigned reference=1,variant=1;
            if (reader(pos,f->width,scratch,ctx)) return -2;
            for (unsigned j=0;j<f->width;j++) {
                reference &= scratch[j]==f->reference[j]; variant &= scratch[j]==f->variant[j];
            }
            if (!reference && !variant) return -3;
            capture(pos,scratch,f->width,offset,length,out);
            update(&sha,f->reference,f->width);pos+=f->width;
        }
    }
    uint8_t digest[32];finish(&sha,digest);
    unsigned difference=0;for (unsigned i=0;i<32;i++) difference |= digest[i]^expected[i];
    return difference ? -4 : 0;
}
