#ifndef A6700_PLAYBACK_FILTER_QUERY_H
#define A6700_PLAYBACK_FILTER_QUERY_H

#include <cstdint>
#include <cstddef>
#ifndef A6700_PLAYBACK_FREESTANDING
#include <vector>
#endif

namespace a6700_playback {

// Target COL3 day key/comparison. These preserve native bit packing, not
// calendar validation or the selected-date list's empty-entry lifecycle.
std::uint64_t normalized_date_key(std::uint16_t year, std::uint8_t month,
                                  std::uint8_t day) noexcept;
bool same_day(std::uint64_t record_col3, std::uint64_t selected_packed) noexcept;

// Target still-folder predicate: public COL0==1 plus exact COL5 uint16 value.
// Directory row UI-state types and list-selection policy are not inputs here.
bool same_still_folder(std::uint32_t public_content_type, std::uint16_t record_folder,
                       std::uint16_t selected_folder) noexcept;

// New normalized values, not a firmware object/request layout. Target adapters
// must qualify native reads and snapshot ownership before invoking this kernel.
struct Constituent {
    bool present;
    std::uint32_t status;
};

struct Record {
    Constituent raw, jpeg, heif, main_movie, proxy_movie;
    std::uint32_t group_key;  // native COL2 value, not the packed record word
};

struct Query {
    bool ftp_enabled;
    std::uint32_t ftp_selection; // 0 Non-transferred, 1 Failed, 2 Success
    std::uint32_t still_mode;    // 0 compressed, 1 RAW, 2 either
    std::uint32_t movie_mode;    // 0 either, 1 main, 2 proxy
    bool other_criteria_enabled;
    bool collapse_groups;
};

// Shared by the host runner and the freestanding Sony set adapter. Neither
// routine allocates or passes a standard-library object through the Sony ABI.
bool ftp_matches(const Query& query, const Record& value) noexcept;
enum class GroupDecision { keep, skip, remember };
GroupDecision group_decision(std::uint32_t key, std::uint32_t& last,
                             const std::uint32_t* seen, std::size_t count) noexcept;

enum class Match { no, yes, error };
enum class QueryStatus { ok, invalid_query, read_error, predicate_error, allocation_error };

struct Reader {
    void* context;
    // Slot is full_unique_id & 0x1ffff, matching native ComplexRefine callbacks.
    // Return false for an unqualified format/column read or provider error.
    bool (*record)(void* context, std::uint32_t slot, Record& result);
    // All other checked criteria combined. An enabled criterion may not be
    // silently skipped: missing callback or error rejects the complete query.
    Match (*other_criteria)(void* context, std::uint32_t slot);
};

// Synchronous and nonescaping. Preserve source order/full IDs. Output changes
// only on success; source and output may alias. Does not publish model state.
#ifndef A6700_PLAYBACK_FREESTANDING
QueryStatus run_query(const Query& query, const std::vector<std::uint32_t>& source,
                      const Reader& reader, std::vector<std::uint32_t>& output) noexcept;
#endif

}  // namespace a6700_playback
#endif
