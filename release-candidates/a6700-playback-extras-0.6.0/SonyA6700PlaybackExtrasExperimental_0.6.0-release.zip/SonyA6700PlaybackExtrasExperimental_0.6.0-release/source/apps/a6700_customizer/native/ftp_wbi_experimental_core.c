/* SPDX-License-Identifier: GPL-3.0-only
 * Experimental fixed FTP-only transaction core. Protocol and mask concepts
 * derive from a6700_unlock/native/transaction.c, GPLv3 (see bundled LICENSE).
 * Full backup, startup recovery, physical geometry, and payload integrity are
 * not established. This code does not authenticate a camera or install itself.
 */
#include "ftp_wbi_experimental_core.h"

enum { BAD_REQUEST=1, OPEN_FAILED=2, READ_FAILED=3, PREIMAGE_MISMATCH=4,
       WRITE_FAILED=5, SYNC_FAILED=6, READBACK_FAILED=7, READBACK_MISMATCH=8, CLOSE_FAILED=9 };
static uint32_t get32(const uint8_t *p) {
    return (uint32_t)p[0] | ((uint32_t)p[1]<<8) | ((uint32_t)p[2]<<16) | ((uint32_t)p[3]<<24);
}
static int same(const uint8_t *a, const uint8_t *b, size_t n) {
    for (size_t i=0;i<n;i++) if (a[i]!=b[i]) return 0;
    return 1;
}
static int validate(const struct ftp_wbi_profile *p, const uint8_t *r, size_t n) {
    uint32_t used=0; unsigned nonce=0;
    if (!p || !r || !p->targets || !p->changes || !p->digest || !p->target_count ||
        !p->change_count || p->target_count>512 || p->change_count>65535 ||
        n!=FTP_WBI_HEADER_BYTES+(size_t)p->target_count*1024u ||
        !same(r,(const uint8_t *)"A67X",4) || get32(r+4)!=1 ||
        !same(r+24,p->digest,32)) return 0;
    for (unsigned i=0;i<16;i++) nonce|=r[8+i];
    if (!nonce) return 0;
    for (uint32_t i=0;i<p->target_count;i++) {
        const struct ftp_wbi_target *t=&p->targets[i];
        const uint8_t *before=r+FTP_WBI_HEADER_BYTES+(size_t)i*1024u, *after=before+512;
        if ((t->offset%512u)!=0 || t->profile_index>=260 ||
            (i && (t->offset<=p->targets[i-1].offset || t->profile_index<=p->targets[i-1].profile_index)) ||
            t->first_change!=used || !t->change_count ||
            (uint32_t)t->first_change+t->change_count>p->change_count) return 0;
        for (unsigned pos=0;pos<512;pos++) {
            const struct ftp_wbi_change *c=used<p->change_count ? &p->changes[used] : 0;
            if (used<(uint32_t)t->first_change+t->change_count && c->position==pos) {
                if (c->before==c->after || before[pos]!=c->before || after[pos]!=c->after) return 0;
                used++;
            } else if (before[pos]!=after[pos]) return 0;
        }
        if (used!=(uint32_t)t->first_change+t->change_count) return 0;
    }
    return used==p->change_count;
}
int ftp_wbi_experimental(const struct ftp_wbi_profile *p, const uint8_t *request,
                         size_t n, const struct ftp_wbi_ops *ops, void *ctx,
                         struct ftp_wbi_result *result) {
    uint8_t buffer[512];
    if (!result) return -1;
    result->status=BAD_REQUEST; result->failed_index=UINT32_MAX;
    result->attempted=0; result->verified=0; result->uncertain=0;
    if (!ops || !ops->open || !ops->read || !ops->write || !ops->sync || !ops->close ||
        !validate(p,request,n)) return -1;
    if (ops->open(ctx)!=0) { result->status=OPEN_FAILED; return -1; }
    /* Preflight every affected full request sector before issuing any write. */
    for (uint32_t i=0;i<p->target_count;i++) {
        const uint8_t *before=request+FTP_WBI_HEADER_BYTES+(size_t)i*1024u;
        result->failed_index=i;
        if (ops->read(ctx,p->targets[i].offset,buffer,512)!=512) { result->status=READ_FAILED; goto stop; }
        if (!same(buffer,before,512)) { result->status=PREIMAGE_MISMATCH; goto stop; }
    }
    for (uint32_t i=0;i<p->target_count;i++) {
        const uint8_t *before=request+FTP_WBI_HEADER_BYTES+(size_t)i*1024u, *after=before+512;
        result->failed_index=i;
        if (ops->read(ctx,p->targets[i].offset,buffer,512)!=512) { result->status=READ_FAILED; goto stop; }
        if (!same(buffer,before,512)) { result->status=PREIMAGE_MISMATCH; goto stop; }
        /* A failed or short write may still have changed the camera. */
        result->attempted++;
        if (ops->write(ctx,p->targets[i].offset,after,512)!=512) { result->status=WRITE_FAILED; goto stop; }
        if (ops->sync(ctx)!=0) { result->status=SYNC_FAILED; goto stop; }
        if (ops->read(ctx,p->targets[i].offset,buffer,512)!=512) { result->status=READBACK_FAILED; goto stop; }
        if (!same(buffer,after,512)) { result->status=READBACK_MISMATCH; goto stop; }
        result->verified++;
    }
    /* Verify all full sectors again after the final write. */
    for (uint32_t i=0;i<p->target_count;i++) {
        const uint8_t *after=request+FTP_WBI_HEADER_BYTES+(size_t)i*1024u+512;
        result->failed_index=i;
        if (ops->read(ctx,p->targets[i].offset,buffer,512)!=512) { result->status=READBACK_FAILED; goto stop; }
        if (!same(buffer,after,512)) { result->status=READBACK_MISMATCH; goto stop; }
    }
    result->failed_index=UINT32_MAX;
    if (ops->close(ctx)!=0) { result->status=CLOSE_FAILED; result->uncertain=1; return -1; }
    result->status=0; return 0;
stop:
    if (result->attempted) result->uncertain=1;
    ops->close(ctx); return -1;
}
