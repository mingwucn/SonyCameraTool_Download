#ifndef A6700_PLAYBACK_FILTER_ACTIVE_H
#define A6700_PLAYBACK_FILTER_ACTIVE_H
#include "playback_filter_snapshot.h"
#include "playback_filter_registry.h"

namespace a6700_playback {
struct ActiveBindings {
    SonyApi native;
    SonyModelApi model;
    void* (*allocate)(std::size_t);
    void (*release)(void*);
    void* app_sidb_mutex;
    void (*app_lock)(void*);
    void (*app_unlock)(void*); // address of a stored mutex pointer, not mutex
    void (*model_set)(std::uint32_t, std::uint32_t);
    void (*model_notify)(std::uint32_t);
};
struct ActiveContext;

// Caller already owns Sony's model guard. Under that same guard this function
// takes App SIDB then native DB read ownership, builds an unpublished native
// result, and supplies the original publisher's selector/count. Success leaves
// a DB read lease in context; cleanup must run before releasing the model guard.
// 0 ordinary, -1 error/no publication, 2 success/nonmember, 3 success/member.
int sony_active_prepare(const ActiveBindings&, A6700FilterRegistry&, void* active,
                        std::uint32_t& selector, ActiveContext*& context) noexcept;
bool sony_active_cleanup(ActiveContext*& context) noexcept;
bool sony_active_bind(std::uintptr_t app_load_bias, ActiveBindings&) noexcept;
}

extern "C" int a6700_filter_active_prepare(void* active, void* frame,
                                           std::uintptr_t app_load_bias) noexcept;
extern "C" int a6700_filter_active_cleanup(void* frame,
                                           std::uintptr_t app_load_bias) noexcept;
#endif
