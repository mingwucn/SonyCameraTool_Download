#ifndef PLAYBACK_GENERAL_TRANSFER_READER_H
#define PLAYBACK_GENERAL_TRANSFER_READER_H

#include <stddef.h>
#include <stdint.h>

#define PLAYBACK_GENERAL_TRANSFER_READER_WINDOW_BYTES 512u
#define PLAYBACK_GENERAL_TRANSFER_READER_WINDOW_COUNT 2u
#define PLAYBACK_GENERAL_TRANSFER_READER_OUTPUT_BYTES \
    (PLAYBACK_GENERAL_TRANSFER_READER_WINDOW_BYTES * \
     PLAYBACK_GENERAL_TRANSFER_READER_WINDOW_COUNT)

/*
 * Read two fixed App file windows into caller-owned memory in this order:
 *   0: 0x03788e00 (current-image roster context)
 *   1: 0x03788c00 (general-transfer roster context)
 * This object has no entry point or constructor and is not wired to a camera
 * session, transport, request staging, WBI access, or writer.
 */
int playback_general_transfer_read(uint8_t *output, size_t capacity);

#endif
