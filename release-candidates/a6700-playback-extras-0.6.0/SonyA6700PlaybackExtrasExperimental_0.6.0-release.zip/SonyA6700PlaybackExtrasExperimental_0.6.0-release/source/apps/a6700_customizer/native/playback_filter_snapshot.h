#ifndef A6700_PLAYBACK_FILTER_SNAPSHOT_H
#define A6700_PLAYBACK_FILTER_SNAPSHOT_H
#include "playback_filter_sony.h"

namespace a6700_playback {
struct SonyModelApi {
    void (*enter)(void*);
    void (*leave)(void*);
    const void* (*active)();
    const void* (*criterion[11])();
    const void* (*ftp_selection)();
    const void* (*still_target)();
    const void* (*movie_target)();
    const void* (*media_info)();
    const void* (*view)();
    const void* (*group)();
    const void* (*expand)();
    const void* (*edit)();
    const void* (*last_screen)();
};

// Link VAs are for the exact pinned historical App, never raw storage offsets.
// A qualified payload obtains its App load bias separately from its linker.
SonyModelApi sony_model_api(std::uintptr_t app_load_bias) noexcept;

struct SonySnapshot {
    std::uint32_t context, media, view, group, expand, edit, last_screen;
    std::uint32_t ftp_selection, still_target, movie_target;
    unsigned char active, criterion[11];
};

// Caller already holds the existing native model guard. No nested query, model
// notification or allocation. On any failure the output remains unchanged.
bool sony_capture_locked(const SonyModelApi&, std::uint32_t context, SonySnapshot&) noexcept;
// Acquire/release the same guard used by the original target constructor.
bool sony_capture(const SonyModelApi&, std::uint32_t context, SonySnapshot&) noexcept;
bool sony_same_snapshot(const SonySnapshot&, const SonySnapshot&) noexcept;
// FTP-only initial integration: never silently ignore another checked filter.
SonyCriteria sony_ftp_criteria(const SonySnapshot&) noexcept;
} // namespace a6700_playback
#endif
