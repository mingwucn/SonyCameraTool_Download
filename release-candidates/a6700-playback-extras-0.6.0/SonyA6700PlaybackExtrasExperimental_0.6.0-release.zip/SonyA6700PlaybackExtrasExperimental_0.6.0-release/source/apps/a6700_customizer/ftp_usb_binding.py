"""Private descriptor correlation inputs; never establishes hardware identity."""
from dataclasses import dataclass, field


class BindingError(ValueError):
    pass


@dataclass(frozen=True)
class UsbObservation:
    pid: int
    bus: int = field(repr=False)
    ports: tuple[int, ...] = field(repr=False)
    serial: str | None = field(repr=False)
    vendor: int = 0x054c

    def __post_init__(self):
        if (type(self.pid) is not int or self.pid not in (0x047d, 0x0e76, 0x0336) or
                type(self.vendor) is not int or self.vendor != 0x054c or
                type(self.bus) is not int or not 1 <= self.bus <= 255 or
                type(self.ports) is not tuple or not 1 <= len(self.ports) <= 8 or
                any(type(port) is not int or not 1 <= port <= 255 for port in self.ports) or
                not (self.pid == 0x0336 and self.serial is None) and (
                    type(self.serial) is not str or not 1 <= len(self.serial) <= 255 or
                    self.serial.strip() != self.serial or
                    any(ord(char) < 33 or ord(char) == 127 for char in self.serial) or
                    self.serial.upper() in ('UNKNOWN', 'NONE', 'N/A') or
                    len(set(self.serial)) == 1)):
            raise BindingError('Missing, placeholder or invalid USB identity observation')


def correlate(initial, service, *, allow_service_without_serial=False):
    """Conservative equality check on supplied data, NOT same-body attestation.

    By default, missing serials stop. The experimental session can explicitly
    allow a service device that exposes no serial index, but only on the same
    bus and port. That weaker correlation does not establish body identity.
    ContainerID, device address and matching PID alone are deliberately absent.
    A qualified observation/acquisition route and firmware evidence are separate.
    """
    if type(initial) is not UsbObservation or type(service) is not UsbObservation:
        raise BindingError('Typed initial and service observations are required')
    if initial.pid not in (0x047d, 0x0e76) or service.pid != 0x0336:
        raise BindingError('Unexpected initial or service USB mode')
    if (initial.vendor, initial.bus, initial.ports) != (service.vendor, service.bus, service.ports):
        raise BindingError('Initial/service descriptor identifiers do not match')
    if service.serial is None:
        if allow_service_without_serial is not True:
            raise BindingError('Service serial is unavailable')
        label = 'TOPOLOGY_MATCH_SERVICE_SERIAL_UNAVAILABLE'
    elif initial.serial != service.serial:
        raise BindingError('Initial/service descriptor identifiers do not match')
    else:
        label = 'MATCH'
    return {'descriptor_correlation': label, 'evidence': 'CALLER_SUPPLIED_OBSERVATIONS',
            'device_identity': 'UNVERIFIED', 'firmware': 'UNVERIFIED', 'service_eligible': False}
