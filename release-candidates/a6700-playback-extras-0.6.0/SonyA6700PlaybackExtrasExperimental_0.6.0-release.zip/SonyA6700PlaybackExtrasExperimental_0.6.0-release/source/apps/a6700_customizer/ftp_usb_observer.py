"""Bounded standard USB descriptor reads on a caller-selected device.

Experimental until exercised on the owner's camera. No discovery, interface
claim, mode/configuration change, authentication, reset, driver change or retry.
The caller owns/closes the handle and must have authorization for device access.
Serial/port data stay private. Descriptor equality is not body attestation.
"""
import math
import struct
import sys
import time

from .ftp_usb_binding import UsbObservation, BindingError

_PIDS = (0x047d, 0x0e76, 0x0336)


class ObservationError(RuntimeError):
    pass


def _backend_trace_diagnostic(error):
    """Report only known PyUSB call phases and actual libusb check results.

    Do not infer a native return code from an exception class or its text.
    PyUSB maps NOT_SUPPORTED to NotImplementedError without preserving its
    numeric code, so recover that code only from its actual loaded _check frame.
    No file names, general locals, messages or device values are returned.
    """
    diagnostic = {}
    traceback = error.__traceback__
    core = sys.modules.get('usb.core')
    backend = sys.modules.get('usb.backend.libusb1')
    checker = getattr(backend, '_check', None)
    check_code = getattr(checker, '__code__', None)
    for _ in range(32):
        if traceback is None:
            break
        frame = traceback.tb_frame
        name = frame.f_code.co_name
        if core is not None and frame.f_globals is core.__dict__ and name == 'managed_open':
            diagnostic['operation'] = 'open_device'
        if backend is not None and frame.f_globals is backend.__dict__:
            if name == 'open_device':
                diagnostic['operation'] = 'open_device'
            elif name == 'ctrl_transfer':
                diagnostic['operation'] = 'ctrl_transfer'
            elif check_code is not None and frame.f_code is check_code:
                result = frame.f_locals.get('ret')
                if type(result) is int and result in (*range(-12, 0), -99):
                    diagnostic['native_error_code'] = result
        traceback = traceback.tb_next
    return diagnostic


def _metadata(device):
    values = (device.idVendor, device.idProduct, device.bus,
              device.port_numbers, device.iSerialNumber)
    vendor, pid, bus, ports, serial_index = values
    if (type(vendor) is not int or vendor != 0x054c or
            type(pid) is not int or pid not in _PIDS or
            type(bus) is not int or not 1 <= bus <= 255 or
            type(ports) is not tuple or not 1 <= len(ports) <= 8 or
            any(type(p) is not int or not 1 <= p <= 255 for p in ports) or
            type(serial_index) is not int or not 0 <= serial_index <= 255 or
            (serial_index == 0 and pid != 0x0336)):
        raise ObservationError('Required USB serial index or bus/port metadata is unavailable')
    return values


def _string_payload(raw):
    if len(raw) < 4 or len(raw) > 254 or len(raw) % 2 or raw[0] != len(raw) or raw[1] != 3:
        raise ObservationError('Incomplete or invalid USB string descriptor')
    return raw[2:]


class UsbDescriptorObservation:
    """One attempt, up to four device-to-host GET_DESCRIPTOR requests, one deadline.

    Read device, LANGID, serial and device again, or read the device twice if
    service mode explicitly reports no serial index. The fresh device descriptor
    must match the selected handle's VID/PID/serial index, then remain identical.
    This reduces stale-handle mistakes; it is not an atomic/cryptographic proof.
    A backend must honor timeouts. Late results lock the attempt, but a hung
    native backend cannot be preempted by this class.
    """
    def __init__(self, device, expected_pid, *, clock=time.monotonic):
        self._device, self._pid, self._clock = device, expected_pid, clock
        self.state = 'READY'

    def read(self, timeout_ms=3000):
        if self.state != 'READY':
            raise ObservationError('USB observation cannot be retried')
        self.state = 'NEEDS_REVIEW'
        step = 'metadata'
        try:
            if (type(timeout_ms) is not int or not 1 <= timeout_ms <= 30000 or
                    type(self._pid) is not int or self._pid not in _PIDS or not callable(self._clock)):
                raise ObservationError('Invalid USB observation inputs')
            started = self._clock()
            if type(started) not in (int, float) or not math.isfinite(started):
                raise ObservationError('Invalid USB observation clock')
            last, deadline = started, started + timeout_ms / 1000

            def remaining():
                nonlocal last
                now = self._clock()
                if type(now) not in (int, float) or not math.isfinite(now) or now < last or now >= deadline:
                    raise ObservationError('USB observation deadline expired or clock is invalid')
                last = now
                return min(timeout_ms, max(1, math.ceil((deadline-now)*1000)))

            metadata = _metadata(self._device)
            vendor, pid, bus, ports, index = metadata
            if pid != self._pid:
                raise ObservationError('Selected USB mode changed before observation')
            remaining()

            def descriptor(value, language, count):
                data = self._device.ctrl_transfer(0x80, 0x06, value, language, count, timeout=remaining())
                try:
                    view = memoryview(data)
                    if view.nbytes > count:
                        raise ObservationError('Oversized USB descriptor response')
                    raw = view.tobytes()
                except TypeError:
                    raise ObservationError('Invalid USB descriptor buffer') from None
                remaining()
                return raw

            step = 'device_descriptor'
            device = descriptor(0x0100, 0, 18)
            if (len(device) != 18 or device[:2] != b'\x12\x01' or
                    struct.unpack_from('<HH', device, 8) != (vendor, pid) or
                    device[16] != index or not device[17]):
                raise ObservationError('Fresh USB device descriptor does not match the selected handle')
            serial = None
            if index:
                step = 'language_descriptor'
                language_bytes = _string_payload(descriptor(0x0300, 0, 255))
                languages = struct.unpack('<' + 'H' * (len(language_bytes)//2), language_bytes)
                if not all(languages) or len(set(languages)) != len(languages):
                    raise ObservationError('USB language descriptor is invalid')
                language = 0x0409 if 0x0409 in languages else languages[0]
                step = 'serial_descriptor'
                serial = _string_payload(descriptor(0x0300 | index, language, 255)).decode('utf-16-le', errors='strict')
                if serial.startswith('\ufeff'):
                    raise ObservationError('USB serial descriptor has an unexpected byte-order mark')
            observation = UsbObservation(pid=pid, bus=bus, ports=ports, serial=serial, vendor=vendor)
            step = 'repeat_device_descriptor'
            if descriptor(0x0100, 0, 18) != device or _metadata(self._device) != metadata:
                raise ObservationError('USB descriptor or topology changed during observation')
            remaining()
            self.state = 'OBSERVED_DESCRIPTORS_UNVERIFIED_BODY'
            return observation
        except ObservationError as error:
            error.observation_step = step
            raise
        except (UnicodeError, BindingError):
            error = ObservationError('USB serial is malformed, missing or a placeholder; stop without retry')
            error.observation_step = step
            raise error from None
        except Exception as exc:
            # USB/decode exceptions may contain raw identifiers or response data.
            error = ObservationError('USB identity observation failed; stop without retry or driver changes')
            error.observation_step = step
            kind = type(exc).__name__
            error.backend_diagnostic = {'type': kind if len(kind) <= 80 and kind.replace('_', '').isalnum() else 'Error'}
            error.backend_diagnostic.update(_backend_trace_diagnostic(exc))
            for field in ('errno', 'backend_error_code'):
                value = getattr(exc, field, None)
                if type(value) is int:
                    error.backend_diagnostic[field] = value
            raise error from None


def read_usb_observation(device, timeout_ms):
    """Deadline-aware callback shared by capture and nominal service exit.

    Only the selected handle is read. No enumeration, first-device selection or
    fallback identifiers. Unsupported modes/missing topology must stop.
    """
    try:
        pid = device.idProduct
    except Exception:
        raise ObservationError('USB handle metadata is unavailable') from None
    return UsbDescriptorObservation(device, pid).read(timeout_ms)
