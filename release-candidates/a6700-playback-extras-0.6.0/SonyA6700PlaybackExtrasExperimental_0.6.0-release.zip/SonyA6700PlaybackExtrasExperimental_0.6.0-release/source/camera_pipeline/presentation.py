"""Pure immutable presentation inputs; camera adapters supply verified facts.

Nothing here imports Tk, reads storage, detects hardware or decides whether an
application transaction is eligible. Labels in snapshots belong to the model;
the small catalogue translates the shared shell's chrome only.
"""
from abc import ABC, abstractmethod
from dataclasses import dataclass
from types import MappingProxyType


def _text(value, *, empty=True):
    return type(value) is str and (empty or bool(value.strip()))


@dataclass(frozen=True)
class Profile:
    id: str
    label: str
    available: bool = True
    description: str = ""

    def __post_init__(self):
        if (not _text(self.id, empty=False) or not _text(self.label, empty=False)
                or type(self.available) is not bool or not _text(self.description)):
            raise ValueError("Invalid presentation profile")


@dataclass(frozen=True)
class Action:
    id: str
    label: str
    enabled: bool = True
    reason: str = ""

    def __post_init__(self):
        if (not _text(self.id, empty=False) or not _text(self.label, empty=False)
                or type(self.enabled) is not bool or not _text(self.reason)):
            raise ValueError("Invalid presentation action")


@dataclass(frozen=True)
class CameraObservation:
    """Caller-supplied last camera facts, independent of a later host job.

    The descriptor preserves supplied text without parsing a time or technical
    result. Establishing the facts belongs to the camera adapter and engine.
    """
    profile: str
    operation: str
    observed_at: str
    facts: tuple[tuple[str, str], ...] = ()
    technical_result: str = ""

    def __post_init__(self):
        if (any(not _text(value, empty=False)
                for value in (self.profile, self.operation, self.observed_at))
                or type(self.facts) is not tuple
                or any(type(row) is not tuple or len(row) != 2
                       or any(not _text(value) for value in row) for row in self.facts)
                or len({row[0] for row in self.facts}) != len(self.facts)
                or not _text(self.technical_result)):
            raise ValueError("Invalid immutable camera observation")

    def fact(self, name, default=""):
        if not _text(name) or not _text(default):
            raise ValueError("Fact name and default must be strings")
        return next((value for key, value in self.facts if key == name), default)


@dataclass(frozen=True)
class WorkbenchSnapshot:
    state: str
    heading: str
    message: str = ""
    profiles: tuple[Profile, ...] = ()
    selected_profile: str = ""
    observations: tuple[tuple[str, str], ...] = ()
    next_action: Action | None = None
    feature_title: str = ""
    feature_message: str = ""
    feature_actions: tuple[Action, ...] = ()
    activity: tuple[str, ...] = ()
    technical_result: str = ""
    busy: bool = False
    status: str = ""
    tone: str = "neutral"
    language: str = "en"

    def __post_init__(self):
        strings = (self.message, self.selected_profile, self.feature_title,
                   self.feature_message, self.technical_result, self.status)
        if (not _text(self.state, empty=False) or not _text(self.heading, empty=False)
                or any(not _text(value) for value in strings)
                or type(self.profiles) is not tuple
                or any(type(value) is not Profile for value in self.profiles)
                or len({value.id for value in self.profiles}) != len(self.profiles)
                or self.profiles and self.selected_profile not in {value.id for value in self.profiles}
                or type(self.observations) is not tuple
                or any(type(row) is not tuple or len(row) != 2
                       or any(not _text(value) for value in row) for row in self.observations)
                or self.next_action is not None and type(self.next_action) is not Action
                or type(self.feature_actions) is not tuple
                or any(type(value) is not Action for value in self.feature_actions)
                or len({value.id for value in self.feature_actions}) != len(self.feature_actions)
                or type(self.activity) is not tuple or any(not _text(value) for value in self.activity)
                or type(self.busy) is not bool
                or self.tone not in ("neutral", "success", "info", "warning", "error")
                or self.language not in ("en", "zh")):
            raise ValueError("Invalid immutable workbench snapshot")


# A short alias is convenient for adapters without creating another schema.
Snapshot = WorkbenchSnapshot


class CameraPresentationAdapter(ABC):
    @abstractmethod
    def present(self, context, *, language="en") -> WorkbenchSnapshot:
        """Project supplied model facts without performing I/O or an operation."""


_CATALOGUE = {
    "en": {
        "product": "Camera Workbench", "product_subtitle": "Sony camera tools",
        "overview": "Overview", "features": "Features", "activity": "Activity", "advanced": "Advanced",
        "selected_profile": "Selected camera profile", "language": "Interface language",
        "last_observation": "Last observation", "no_observation": "Not inspected",
        "profile_hint": "Selecting a profile does not detect a camera.", "unavailable": "unavailable",
        "next_step": "Next step", "feature_summary": "Feature summary", "view_features": "View features",
        "view_activity": "View activity", "technical_result": "Technical result",
        "show_technical": "Show technical result", "hide_technical": "Hide technical result",
        "no_activity": "No activity recorded in this window.", "ready": "Ready · no automatic camera action",
        "working": "Operation in progress", "experimental": "Experimental build",
        "footer_note": "Camera actions require an explicit selection.",
        "overview_description": "The current observation and your next permitted step.",
        "features_description": "Features supplied by the selected camera adapter.",
        "activity_description": "Session events, with technical results kept separate.",
        "advanced_description": "Paths, references and contextual service setup.",
    },
    "zh": {
        "product": "相机工作台", "product_subtitle": "Sony 相机工具",
        "overview": "概览", "features": "功能", "activity": "活动记录", "advanced": "高级",
        "selected_profile": "已选相机配置", "language": "界面语言", "last_observation": "最近一次观察",
        "no_observation": "尚未检查", "profile_hint": "选择配置不代表已检测到相机。", "unavailable": "暂不可用",
        "next_step": "下一步", "feature_summary": "功能摘要", "view_features": "查看功能",
        "view_activity": "查看活动记录", "technical_result": "技术结果", "show_technical": "显示技术结果",
        "hide_technical": "隐藏技术结果", "no_activity": "此窗口尚无活动记录。",
        "ready": "就绪 · 不会自动操作相机", "working": "操作进行中", "experimental": "实验版本",
        "footer_note": "相机操作需要明确选择。", "overview_description": "当前观察结果与下一步可执行操作。",
        "features_description": "仅显示所选相机适配器提供的功能。", "activity_description": "会话活动与独立的技术结果。",
        "advanced_description": "路径、原始文件和当前适用的服务设置。",
    },
}
CATALOGUE = MappingProxyType({language: MappingProxyType(values) for language, values in _CATALOGUE.items()})
del _CATALOGUE


class Translator:
    """Shared view labels; changing language has no external side effects."""
    def __init__(self, language="en"):
        self.set_language(language)

    def set_language(self, language):
        if type(language) is not str or language not in CATALOGUE:
            raise ValueError("Unsupported interface language")
        self.language = language

    def __call__(self, key, **values):
        return CATALOGUE[self.language].get(key, key).format(**values)
