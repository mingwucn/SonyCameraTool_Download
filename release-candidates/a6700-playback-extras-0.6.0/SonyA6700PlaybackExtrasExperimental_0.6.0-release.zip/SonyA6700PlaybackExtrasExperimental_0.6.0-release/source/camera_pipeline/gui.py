"""Small UI-independent workflow template and single-job background controller.

Camera adapters supply commands and validation. This module never opens a device,
retries an operation, reuses approval, or interprets a camera's write policy.
"""
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from copy import deepcopy
from pathlib import Path
import queue
from threading import Event, Lock, Thread
from types import MappingProxyType


@dataclass(frozen=True)
class WorkflowCommand:
    action: str
    arguments: tuple[str, ...] = field(default=(), repr=False)
    state_dir: Path | None = None

    def __post_init__(self):
        if (type(self.action) is not str or not self.action
                or type(self.arguments) is not tuple
                or any(type(value) is not str for value in self.arguments)
                or self.state_dir is not None and not isinstance(self.state_dir, Path)):
            raise ValueError("Invalid workflow command")


class WorkflowRefusal(RuntimeError):
    def __init__(self, result):
        if type(result) is not dict or result.get("ok") is not False:
            raise ValueError("A refused workflow needs a failed result")
        self.result = dict(result)
        super().__init__("Workflow preconditions are not satisfied")


def review_operation(parent, title, summary, document, *, language="en"):
    """Display a concrete document; only the affirmative button returns True."""
    import tkinter as tk
    from tkinter import ttk
    window = tk.Toplevel(parent)
    window.title(title); window.transient(parent)
    width = min(1000, max(480, parent.winfo_screenwidth() - 100))
    height = min(700, max(400, parent.winfo_screenheight() - 120))
    window.geometry("%sx%s" % (width, height))
    chinese = language == "zh"
    styled = bool(ttk.Style(parent).lookup("Workbench.TFrame", "background"))
    frame_style = "Workbench.TFrame" if styled else "TFrame"
    label_style = "Workbench.TLabel" if styled else "TLabel"
    button_style = "Workbench.TButton" if styled else "TButton"
    frame = ttk.Frame(window, padding=14, style=frame_style); frame.pack(fill="both", expand=True)
    ttk.Label(frame, text=summary, style=label_style, wraplength=width - 60).pack(anchor="w", pady=(0, 10))
    text = tk.Text(frame, wrap="word", height=15, font=("Consolas", 10))
    if styled:
        text.configure(background="#18181b", foreground="#f4f4f5", insertbackground="#f4f4f5", relief="flat")
    scroll = ttk.Scrollbar(text, orient="vertical", command=text.yview)
    text.configure(yscrollcommand=scroll.set)
    scroll.pack(side="right", fill="y"); text.pack(fill="both", expand=True)
    text.insert("1.0", document); text.configure(state="disabled")
    selected = [False]
    def finish(approved):
        selected[0] = approved; window.destroy()
    row = ttk.Frame(frame, style=frame_style); row.pack(fill="x", pady=(12, 0))
    cancel = ttk.Button(row, style=button_style,
        text="取消 — 仅保留草稿" if chinese else "Cancel — keep draft only", command=lambda: finish(False))
    cancel.pack(side="right")
    ttk.Button(row, style=button_style, text="批准本次操作" if chinese else "Approve this one operation",
        command=lambda: finish(True)).pack(side="right", padx=10)
    cancel.focus_set()
    window.protocol("WM_DELETE_WINDOW", lambda: finish(False))
    window.grab_set(); parent.wait_window(window)
    return selected[0]


class WorkflowAdapter(ABC):
    @abstractmethod
    def prepare(self, action, values) -> WorkflowCommand:
        """Validate the camera's inputs and persist any pre-launch intent."""

    @abstractmethod
    def execute(self, command, progress):
        """Execute exactly one selected command using the camera's engine."""

    def run(self, action, values, progress=lambda _text: None):
        try:
            command = self.prepare(action, values)
            if type(command) is not WorkflowCommand or command.action != action:
                raise ValueError("Workflow preparation changed the selected action")
            return self.execute(command, progress)
        except WorkflowRefusal as exc:
            return exc.result


class WorkflowController:
    """One background job; the UI drains results on its own thread."""

    def __init__(self, adapter, *, events=None, failure=None):
        if not isinstance(adapter, WorkflowAdapter):
            raise TypeError("A workflow adapter is required")
        self.adapter = adapter
        self.events = events if events is not None else queue.Queue()
        self.failure = failure or (lambda _action, _exc: "Operation stopped; review retained evidence.")
        self._lock, self._busy, self._thread = Lock(), False, None

    @property
    def busy(self):
        with self._lock:
            return self._busy

    def start(self, action, values, *, label=None):
        # Capture GUI values on its thread, before starting a background worker.
        snapshot = MappingProxyType(deepcopy(dict(values)))
        active = Event(); active.set()
        def selected():
            try:
                return self.adapter.run(action, snapshot,
                    lambda text: self.events.put(("progress", label or action, text)) if active.is_set() else None)
            finally:
                active.clear()
        return self.start_function(label or action, selected)

    def start_function(self, label, function):
        with self._lock:
            if self._busy:
                return False
            self._busy = True

        def worker():
            try:
                terminal = ("result", label, function())
            except Exception as exc:
                try:
                    failure = self.failure(label, exc)
                except Exception:
                    failure = "Operation stopped; review retained evidence."
                terminal = ("error", label, failure)
            finally:
                with self._lock:
                    self._busy = False
            # A UI may accept the next job as soon as it drains this terminal.
            self.events.put(terminal)

        self._thread = Thread(target=worker, name="camera-selected-operation", daemon=False)
        try:
            self._thread.start()
        except BaseException:
            with self._lock:
                self._busy = False
            raise
        return True

    def wait(self, timeout=None):
        if self._thread is not None:
            self._thread.join(timeout)
        return not self.busy
