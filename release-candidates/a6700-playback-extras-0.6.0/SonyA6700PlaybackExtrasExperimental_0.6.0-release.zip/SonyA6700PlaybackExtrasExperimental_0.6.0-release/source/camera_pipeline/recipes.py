"""The shared 'how' for exact application byte plans and their inverse.

This module handles immutable bytes, with no filesystem or camera operations.
Persistent execution belongs to a separately selected transaction and adapter.
"""
from abc import ABC, abstractmethod
from dataclasses import dataclass
import hashlib

from .models import ApplicationTarget, ByteChange


@dataclass(frozen=True)
class ByteRecipe:
    """Exact edits within immutable bytes; no file identity or I/O is implied."""
    changes: tuple[ByteChange, ...]

    def __post_init__(self):
        if (type(self.changes) is not tuple or not self.changes
                or any(type(change) is not ByteChange for change in self.changes)):
            raise ValueError("An immutable tuple of exact byte changes is required")
        end = 0
        for change in self.changes:
            if change.offset < end:
                raise ValueError("Byte edits must be ordered and disjoint")
            end = change.offset + len(change.before)

    def _apply(self, data, restore):
        if type(data) is not bytes:
            raise ValueError("An immutable byte source is required")
        for change in self.changes:
            expected = change.after if restore else change.before
            end = change.offset + len(expected)
            if end > len(data):
                raise ValueError("Byte edits exceed the source extent")
            if data[change.offset:end] != expected:
                raise ValueError("Byte preimage disagrees with the exact recipe")
        result = bytearray(data)
        for change in self.changes:
            replacement = change.before if restore else change.after
            result[change.offset:change.offset + len(replacement)] = replacement
        return bytes(result)

    def modify(self, data):
        return self._apply(data, False)

    def reverse(self, data):
        return self._apply(data, True)


class ApplicationRecipe(ABC):
    @property
    @abstractmethod
    def target(self) -> ApplicationTarget:
        """The camera subclass supplies model, identity and exact file changes."""

    def preview(self, *, restore=False):
        if type(restore) is not bool:
            raise ValueError("Select the direction explicitly")
        target = self.target
        if type(target) is not ApplicationTarget:
            raise ValueError("An immutable exact application target is required")
        before, after = ((target.candidate_sha256, target.stock_sha256) if restore
                         else (target.stock_sha256, target.candidate_sha256))
        plan = {"model": target.model, "firmware": target.firmware,
                "target_file": target.target_file, "address_type": "elf_file_offset",
                "application_bytes": target.size, "source_sha256": before, "target_sha256": after,
                "direction": "restore" if restore else "apply",
                "changes": [{"offset": c.offset, "before_hex": (c.after if restore else c.before).hex(),
                             "after_hex": (c.before if restore else c.after).hex()}
                            for c in target.changes], "camera_access_performed": False}
        if target.appended:
            plan.update(application_bytes=target.candidate_size if restore else target.size,
                        target_application_bytes=target.size if restore else target.candidate_size,
                        appended_bytes=len(target.appended),
                        appended_sha256=hashlib.sha256(target.appended).hexdigest())
        return plan

    def verify_source(self, data, *, restore=False):
        plan = self.preview(restore=restore)
        if (type(data) is not bytes or len(data) != plan["application_bytes"]
                or hashlib.sha256(data).hexdigest() != plan["source_sha256"]):
            raise ValueError("Complete application source identity disagrees with the recipe")
        for change in plan["changes"]:
            at = change["offset"]
            before = bytes.fromhex(change["before_hex"])
            if data[at:at + len(before)] != before:
                raise ValueError("Application preimage disagrees with the exact recipe")
        if restore and self.target.appended and data[self.target.size:] != self.target.appended:
            raise ValueError("Application tail disagrees with the exact recipe")
        return plan

    def build_candidate(self, data, *, restore=False):
        plan = self.verify_source(data, restore=restore)
        recipe = ByteRecipe(self.target.changes)
        # Reverse verifies the complete candidate (including its exact tail)
        # before truncating. All equal-width edits remain in the original file.
        result = (recipe.reverse(data[:self.target.size]) if restore else
                  recipe.modify(data) + self.target.appended)
        expected_size = self.target.size if restore else self.target.candidate_size
        if len(result) != expected_size:
            raise ValueError("Complete candidate extent disagrees with the recipe")
        if hashlib.sha256(result).hexdigest() != plan["target_sha256"]:
            raise ValueError("Complete candidate identity disagrees with the recipe")
        self.verify_source(result, restore=not restore)
        return result
