"""Small injected facade shared by command-line and graphical callers."""
from .transactions import ApplicationTransaction, TransactionError


class ResearchPipeline:
    def __init__(self, *, install_transaction=None, restore_transaction=None):
        for transaction in (install_transaction, restore_transaction):
            if transaction is not None and not isinstance(transaction, ApplicationTransaction):
                raise TypeError("Inject an ApplicationTransaction implementation")
        if install_transaction is not None and install_transaction.operation != "apply":
            raise ValueError("The installation slot requires an apply transaction")
        if restore_transaction is not None and restore_transaction.operation != "restore":
            raise ValueError("The restoration slot requires an explicit inverse transaction")
        self._install = install_transaction
        self._restore = restore_transaction

    def install_application(self, request):
        if self._install is None:
            raise TransactionError("No model-specific application installation transaction was selected")
        return self._install.execute(request)

    def restore_application(self, request):
        if self._restore is None:
            raise TransactionError("No model-specific application restoration transaction was selected")
        return self._restore.execute(request)
