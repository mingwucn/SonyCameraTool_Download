"""Reusable passive Tk shell for a model's immutable presentation snapshot.

Only explicit user commands invoke the three supplied callbacks. This module
has no worker/controller, operation policy, model adapter, storage or device I/O.
Extension frames stay alive across renders; their owner supplies their gates.
"""
from .presentation import Translator, WorkbenchSnapshot


COLORS = {
    "canvas": "#18181b", "sidebar": "#121214", "card": "#27272a",
    "border": "#3f3f46", "text": "#f4f4f5", "muted": "#a1a1aa",
    "primary": "#2563eb", "focus": "#93b4ff", "success": "#86d9a4",
    "warning": "#f0cb80", "error": "#f2a0a7",
}
PAGES = ("overview", "features", "activity", "advanced")


class WorkbenchWindow:
    """A view over an existing root; constructors/renders never select an action.

    Public extension points: ``frames`` (also ``overview``/``features``/
    ``activity``/``advanced``), ``feature_controls``, ``activity_controls``, ``advanced_controls``,
    ``primary_button``, ``technical_output``/``output``, ``translator``,
    ``label``, ``render``, ``set_page`` and ``set_status``.
    """
    def __init__(self, root, on_action, on_profile, on_language):
        # Lazy Tk import keeps importing this shared module UI-inert.
        import tkinter as tk
        from tkinter import ttk
        if any(not callable(callback) for callback in (on_action, on_profile, on_language)):
            raise TypeError("Explicit view callbacks are required")
        self.tk, self.ttk, self.root = tk, ttk, root
        self.on_action, self.on_profile, self.on_language = on_action, on_profile, on_language
        self.translator = Translator()
        self.snapshot = None
        self.page, self._busy, self._progress_running = "overview", False, False
        self._wrap_labels, self._feature_buttons = [], []
        self._wrap_after = None
        self._last_canvas_width = None
        self._disposed = False
        self._technical_visible = False
        self._styles()
        self.widget = ttk.Frame(root, style="Workbench.TFrame")
        self.widget.pack(fill="both", expand=True)
        self.widget.columnconfigure(1, weight=1)
        self.widget.rowconfigure(0, weight=1)
        self._sidebar()
        main = ttk.Frame(self.widget, style="Workbench.TFrame")
        main.grid(row=0, column=1, sticky="nsew")
        main.columnconfigure(0, weight=1)
        main.rowconfigure(1, weight=1)
        self._header(main)
        self._content(main)
        self._footer(main)
        self._wheel_binding = root.bind("<MouseWheel>", self._mousewheel, add="+")
        self.widget.bind("<Destroy>", self._destroyed, add="+")
        self._translate_chrome()
        self.set_page("overview")

    def _styles(self):
        ttk = self.ttk
        style = ttk.Style(self.root)
        style.theme_use("clam")
        family = "Segoe UI"
        body, title, heading = (family, 11), (family, 21, "bold"), (family, 18, "bold")
        self._font_body = body
        style.configure("Workbench.TFrame", background=COLORS["canvas"])
        style.configure("Workbench.Sidebar.TFrame", background=COLORS["sidebar"])
        style.configure("Workbench.Card.TFrame", background=COLORS["card"], bordercolor=COLORS["border"], relief="solid", borderwidth=1)
        style.configure("Workbench.TLabel", background=COLORS["canvas"], foreground=COLORS["text"], font=body)
        style.configure("Workbench.Muted.TLabel", background=COLORS["canvas"], foreground=COLORS["muted"], font=(family, 10))
        style.configure("Workbench.Card.TLabel", background=COLORS["card"], foreground=COLORS["text"], font=body)
        style.configure("Workbench.CardMuted.TLabel", background=COLORS["card"], foreground=COLORS["muted"], font=(family, 10))
        style.configure("Workbench.Title.TLabel", background=COLORS["canvas"], foreground=COLORS["text"], font=title)
        style.configure("Workbench.Heading.TLabel", background=COLORS["card"], foreground=COLORS["text"], font=heading)
        style.configure("Workbench.Section.TLabel", background=COLORS["card"], foreground=COLORS["text"], font=(family, 12, "bold"))
        style.configure("Workbench.Sidebar.TLabel", background=COLORS["sidebar"], foreground=COLORS["muted"], font=(family, 10))
        style.configure("Workbench.Brand.TLabel", background=COLORS["sidebar"], foreground=COLORS["text"], font=(family, 14, "bold"))
        style.configure("Workbench.TButton", background="#34343b", foreground=COLORS["text"], bordercolor=COLORS["border"], focuscolor=COLORS["focus"], padding=(16, 10), font=body)
        style.map("Workbench.TButton", background=[("active", "#41414b")], foreground=[("disabled", "#92929d")])
        style.configure("Workbench.Primary.TButton", background=COLORS["primary"], foreground=COLORS["text"], bordercolor="#4077ee", focuscolor=COLORS["focus"], padding=(18, 11), font=(family, 11, "bold"))
        style.map("Workbench.Primary.TButton", background=[("disabled", "#323b52"), ("active", "#2e6af0")], foreground=[("disabled", "#a1a1b0")])
        style.configure("Workbench.Nav.TButton", background=COLORS["sidebar"], foreground=COLORS["muted"], borderwidth=0, anchor="w", padding=(18, 14), font=body, focuscolor=COLORS["focus"])
        style.map("Workbench.Nav.TButton", background=[("selected", "#232c43"), ("active", "#202023")], foreground=[("selected", "#b5ccff"), ("active", COLORS["text"])])
        style.configure("Workbench.TCombobox", fieldbackground=COLORS["card"], background="#34343b", foreground=COLORS["text"], arrowcolor=COLORS["text"], padding=8, font=body, bordercolor=COLORS["border"], focuscolor=COLORS["focus"])
        style.map("Workbench.TCombobox", fieldbackground=[("readonly", COLORS["card"]), ("disabled", "#222226")], foreground=[("readonly", COLORS["text"]), ("disabled", COLORS["muted"])], selectbackground=[("readonly", COLORS["card"])], selectforeground=[("readonly", COLORS["text"])])
        style.configure("Workbench.TEntry", fieldbackground=COLORS["card"], foreground=COLORS["text"], insertcolor=COLORS["text"], bordercolor=COLORS["border"], padding=8, font=body)
        style.configure("Workbench.TCheckbutton", background=COLORS["canvas"], foreground=COLORS["text"], font=body, padding=6, focuscolor=COLORS["focus"])
        style.map("Workbench.TCheckbutton", background=[("active", COLORS["canvas"])], foreground=[("disabled", COLORS["muted"])])
        style.configure("Workbench.Horizontal.TProgressbar", background=COLORS["focus"], troughcolor="#34343b", borderwidth=0, thickness=4)
        self.style = style

    def label(self, parent, *, text=None, textvariable=None, kind="body", **kwargs):
        """Create a shared label whose wrapping follows its allocated width."""
        styles = {"body": "Workbench.TLabel", "muted": "Workbench.Muted.TLabel",
                  "card": "Workbench.Card.TLabel", "card_muted": "Workbench.CardMuted.TLabel",
                  "heading": "Workbench.Heading.TLabel", "title": "Workbench.Title.TLabel",
                  "section": "Workbench.Section.TLabel"}
        if kind not in styles:
            raise ValueError("Unknown workbench label kind")
        kwargs.setdefault("style", styles[kind])
        kwargs.setdefault("justify", "left")
        kwargs.setdefault("anchor", "w")
        kwargs.setdefault("wraplength", 620)
        if text is not None:
            kwargs["text"] = text
        if textvariable is not None:
            kwargs["textvariable"] = textvariable
        result = self.ttk.Label(parent, **kwargs)
        self._wrap_labels.append(result)
        return result

    def _sidebar(self):
        ttk = self.ttk
        self.sidebar = ttk.Frame(self.widget, width=224, padding=(16, 28), style="Workbench.Sidebar.TFrame")
        self.sidebar.grid(row=0, column=0, sticky="nsew")
        self.sidebar.grid_propagate(False)
        self.sidebar.columnconfigure(0, weight=1)
        self.sidebar.rowconfigure(6, weight=1)
        self.brand = ttk.Label(self.sidebar, style="Workbench.Brand.TLabel",
                               wraplength=168, justify="left", anchor="w")
        self.brand.grid(row=0, column=0, sticky="w", padx=12, pady=(0, 8))
        self.brand_subtitle = ttk.Label(self.sidebar, style="Workbench.Sidebar.TLabel")
        self.brand_subtitle.grid(row=1, column=0, sticky="w", padx=12, pady=(0, 32))
        self.nav_buttons = {}
        for index, page in enumerate(PAGES):
            button = ttk.Button(self.sidebar, style="Workbench.Nav.TButton", command=lambda selected=page: self.set_page(selected))
            button.grid(row=index + 2, column=0, sticky="ew", pady=3)
            self.nav_buttons[page] = button
        self.build_label = ttk.Label(self.sidebar, style="Workbench.Sidebar.TLabel", wraplength=180)
        self.build_label.grid(row=7, column=0, sticky="sw", padx=12, pady=(24, 0))

    def _header(self, parent):
        ttk = self.ttk
        header = ttk.Frame(parent, padding=(24, 24, 24, 18), style="Workbench.TFrame")
        header.grid(row=0, column=0, sticky="ew")
        header.columnconfigure(0, weight=1)
        self.header_title = self.label(header, kind="title")
        self.header_title.grid(row=0, column=0, sticky="ew")
        self.header_description = self.label(header, kind="muted")
        self.header_description.grid(row=1, column=0, sticky="ew", pady=(7, 18))
        controls = ttk.Frame(header, style="Workbench.TFrame")
        controls.grid(row=2, column=0, sticky="ew")
        controls.columnconfigure(0, weight=1)
        self.profile_label = self.label(controls, kind="muted")
        self.profile_label.grid(row=0, column=0, sticky="ew", padx=(0, 16), pady=(0, 6))
        self.language_label = self.label(controls, kind="muted")
        self.language_label.grid(row=0, column=1, sticky="w", pady=(0, 6))
        self.profile_var = self.tk.StringVar(parent)
        self.profile_selector = ttk.Combobox(controls, textvariable=self.profile_var, state="readonly", width=27, style="Workbench.TCombobox")
        self.profile_selector.grid(row=1, column=0, sticky="ew", padx=(0, 16))
        self.profile_selector.bind("<<ComboboxSelected>>", self._profile_selected)
        self.language_var = self.tk.StringVar(parent, value="EN")
        self.language_selector = ttk.Combobox(controls, textvariable=self.language_var, values=("EN", "简体中文"), state="readonly", width=11, style="Workbench.TCombobox")
        self.language_selector.grid(row=1, column=1, sticky="ew")
        self.language_selector.bind("<<ComboboxSelected>>", self._language_selected)

    def _content(self, parent):
        tk, ttk = self.tk, self.ttk
        holder = ttk.Frame(parent, style="Workbench.TFrame")
        holder.grid(row=1, column=0, sticky="nsew")
        holder.columnconfigure(0, weight=1)
        holder.rowconfigure(0, weight=1)
        self.canvas = tk.Canvas(holder, background=COLORS["canvas"], highlightthickness=0, borderwidth=0, yscrollincrement=24)
        self.canvas.grid(row=0, column=0, sticky="nsew")
        scrollbar = ttk.Scrollbar(holder, orient="vertical", command=self.canvas.yview)
        scrollbar.grid(row=0, column=1, sticky="ns")
        self.canvas.configure(yscrollcommand=scrollbar.set)
        self.content = ttk.Frame(self.canvas, padding=(24, 0, 24, 24), style="Workbench.TFrame")
        self.content.columnconfigure(0, weight=1)
        self._canvas_window = self.canvas.create_window(0, 0, window=self.content, anchor="nw")
        self.canvas.bind("<Configure>", self._canvas_resized)
        self.content.bind("<Configure>", self._content_resized)
        self.canvas.bind("<MouseWheel>", self._mousewheel)
        self.content.bind("<MouseWheel>", self._mousewheel)
        self.frames = {}
        for page in PAGES:
            frame = ttk.Frame(self.content, style="Workbench.TFrame")
            frame.columnconfigure(0, weight=1)
            frame.grid(row=0, column=0, sticky="nsew")
            self.frames[page] = frame
            setattr(self, page, frame)
            frame.bind("<MouseWheel>", self._mousewheel)
        self._overview()
        self._features()
        self._activity()
        self.advanced_controls = ttk.Frame(self.advanced, style="Workbench.TFrame")
        self.advanced_controls.grid(row=0, column=0, sticky="nsew")
        self.advanced_controls.columnconfigure(0, weight=1)

    def _card(self, parent, row):
        result = self.ttk.Frame(parent, padding=24, style="Workbench.Card.TFrame")
        result.grid(row=row, column=0, sticky="ew", pady=(0, 16))
        result.columnconfigure(0, weight=1)
        return result

    def _overview(self):
        ttk = self.ttk
        observation = self._card(self.overview, 0)
        self.observation_title = self.label(observation, kind="section")
        self.observation_title.grid(row=0, column=0, sticky="ew", pady=(0, 12))
        self.observation_text = self.label(observation, kind="card")
        self.observation_text.grid(row=1, column=0, sticky="ew")
        self.observation_hint = self.label(observation, kind="card_muted")
        self.observation_hint.grid(row=2, column=0, sticky="ew", pady=(10, 0))
        self.action_card = self._card(self.overview, 1)
        self.action_heading = self.label(self.action_card, kind="heading")
        self.action_heading.grid(row=0, column=0, sticky="ew")
        self.action_message = self.label(self.action_card, kind="card_muted")
        self.action_message.grid(row=1, column=0, sticky="ew", pady=(12, 16))
        self.action_reason = self.label(self.action_card, kind="card_muted")
        self.action_reason.grid(row=2, column=0, sticky="ew", pady=(0, 12))
        self.primary_button = ttk.Button(self.action_card, style="Workbench.Primary.TButton", command=self._primary_selected)
        self.primary_button.grid(row=3, column=0, sticky="w")
        summary = self._card(self.overview, 2)
        self.summary_title = self.label(summary, kind="section")
        self.summary_title.grid(row=0, column=0, sticky="ew")
        self.summary_message = self.label(summary, kind="card_muted")
        self.summary_message.grid(row=1, column=0, sticky="ew", pady=(8, 16))
        self.view_features_button = ttk.Button(summary, style="Workbench.TButton", command=lambda: self.set_page("features"))
        self.view_features_button.grid(row=2, column=0, sticky="w")

    def _features(self):
        self.feature_card = self._card(self.features, 0)
        self.feature_title = self.label(self.feature_card, kind="heading")
        self.feature_title.grid(row=0, column=0, sticky="ew")
        self.feature_message = self.label(self.feature_card, kind="card_muted")
        self.feature_message.grid(row=1, column=0, sticky="ew", pady=(12, 16))
        self._feature_action_frame = self.ttk.Frame(self.feature_card, style="Workbench.Card.TFrame")
        self._feature_action_frame.grid(row=2, column=0, sticky="ew")
        self.feature_controls = self.ttk.Frame(self.features, style="Workbench.TFrame")
        self.feature_controls.grid(row=1, column=0, sticky="nsew")
        self.feature_controls.columnconfigure(0, weight=1)

    def _activity(self):
        ttk, tk = self.ttk, self.tk
        card = self._card(self.activity, 0)
        self.activity_text = self.label(card, kind="card")
        self.activity_text.grid(row=0, column=0, sticky="ew")
        self.technical_toggle = ttk.Button(self.activity, style="Workbench.TButton", command=self._toggle_technical)
        self.technical_toggle.grid(row=1, column=0, sticky="w", pady=(0, 12))
        self.technical_frame = ttk.Frame(self.activity, style="Workbench.TFrame")
        self.technical_frame.grid(row=2, column=0, sticky="nsew")
        self.technical_frame.columnconfigure(0, weight=1)
        self.technical_frame.rowconfigure(0, weight=1)
        self.technical_output = tk.Text(self.technical_frame, height=14, width=1, wrap="word", background="#202024", foreground=COLORS["text"], insertbackground=COLORS["text"], selectbackground="#304976", relief="flat", borderwidth=0, padx=16, pady=16, font=("Consolas", 10), state="disabled")
        self.technical_output.grid(row=0, column=0, sticky="nsew")
        scroll = ttk.Scrollbar(self.technical_frame, orient="vertical", command=self.technical_output.yview)
        scroll.grid(row=0, column=1, sticky="ns")
        self.technical_output.configure(yscrollcommand=scroll.set)
        self.output = self.technical_output
        self.technical_frame.grid_remove()
        self.activity_controls = ttk.Frame(self.activity, style="Workbench.TFrame")
        self.activity_controls.grid(row=3, column=0, sticky="ew", pady=(16, 0))

    def _footer(self, parent):
        ttk = self.ttk
        footer = ttk.Frame(parent, padding=(24, 12), style="Workbench.TFrame")
        footer.grid(row=2, column=0, sticky="ew")
        footer.columnconfigure(0, weight=1)
        self.status_var = self.tk.StringVar(parent)
        self.status_label = self.label(footer, textvariable=self.status_var, kind="muted")
        self.status_label.grid(row=0, column=0, sticky="ew", padx=(0, 16))
        self.footer_progress = ttk.Progressbar(footer, mode="indeterminate", length=110, style="Workbench.Horizontal.TProgressbar")
        self.footer_progress.grid(row=0, column=1, sticky="e", padx=(0, 16))
        self.footer_progress.grid_remove()
        self.activity_button = ttk.Button(footer, style="Workbench.TButton", command=lambda: self.set_page("activity"))
        self.activity_button.grid(row=0, column=2, sticky="e")

    def _translate_chrome(self):
        tr = self.translator
        self.brand.configure(text="α  " + tr("product"))
        self.brand_subtitle.configure(text=tr("product_subtitle"))
        self.build_label.configure(text=tr("experimental"))
        self.profile_label.configure(text=tr("selected_profile"))
        self.language_label.configure(text=tr("language"))
        self.observation_title.configure(text=tr("last_observation"))
        self.observation_hint.configure(text=tr("profile_hint"))
        self.view_features_button.configure(text=tr("view_features"))
        self.activity_button.configure(text=tr("view_activity"))
        for page, button in self.nav_buttons.items():
            button.configure(text=tr(page))
        self.technical_toggle.configure(text=tr("hide_technical" if self._technical_visible else "show_technical"))
        self.header_title.configure(text=tr(self.page))
        self.header_description.configure(text=tr(self.page + "_description"))

    def render(self, snapshot):
        if type(snapshot) is not WorkbenchSnapshot:
            raise TypeError("An immutable WorkbenchSnapshot is required")
        self.snapshot = snapshot
        self.translator.set_language(snapshot.language)
        self._translate_chrome()
        values = tuple(profile.label + (" · " + self.translator("unavailable") if not profile.available else "") for profile in snapshot.profiles)
        self.profile_selector.configure(values=values)
        selected = next((index for index, profile in enumerate(snapshot.profiles) if profile.id == snapshot.selected_profile), None)
        if selected is None:
            self.profile_var.set("")
        else:
            self.profile_selector.current(selected)
        self.language_var.set("简体中文" if snapshot.language == "zh" else "EN")
        observations = "\n".join(label + ": " + value for label, value in snapshot.observations)
        self.observation_text.configure(text=observations or self.translator("no_observation"))
        self.action_heading.configure(text=snapshot.heading)
        self.action_message.configure(text=snapshot.message)
        self.action_reason.configure(text=snapshot.next_action.reason if snapshot.next_action else "")
        if snapshot.next_action is None:
            self.primary_button.grid_remove()
        else:
            self.primary_button.configure(text=snapshot.next_action.label)
            self.primary_button.grid()
        self.action_heading.configure(foreground=COLORS.get(snapshot.tone, COLORS["focus"] if snapshot.tone == "info" else COLORS["text"]))
        self.summary_title.configure(text=snapshot.feature_title or self.translator("feature_summary"))
        self.summary_message.configure(text=snapshot.feature_message)
        self.feature_title.configure(text=snapshot.feature_title or self.translator("features"))
        self.feature_message.configure(text=snapshot.feature_message)
        for widget in self._feature_action_frame.winfo_children():
            widget.destroy()
        self._feature_buttons = []
        for index, action in enumerate(snapshot.feature_actions):
            button = self.ttk.Button(self._feature_action_frame, text=action.label, style="Workbench.TButton", command=lambda item=action: self._action_selected(item))
            button.grid(row=index * 2, column=0, sticky="w", pady=(0, 8))
            self._feature_buttons.append((button, action))
            if action.reason:
                reason = self.label(self._feature_action_frame, text=action.reason, kind="card_muted")
                reason.grid(row=index * 2 + 1, column=0, sticky="ew", pady=(0, 12))
        self.activity_text.configure(text="\n\n".join("•  " + event for event in snapshot.activity) or self.translator("no_activity"))
        self.technical_output.configure(state="normal")
        self.technical_output.delete("1.0", "end")
        self.technical_output.insert("1.0", snapshot.technical_result)
        self.technical_output.configure(state="disabled")
        self.set_status(snapshot.status or self.translator("working" if snapshot.busy else "ready"), busy=snapshot.busy)
        self._schedule_wrap()

    def set_page(self, page):
        if page not in PAGES:
            raise ValueError("Unknown workbench page")
        self.page = page
        for name, frame in self.frames.items():
            if name == page:
                frame.grid()
            else:
                frame.grid_remove()
            self.nav_buttons[name].state(["selected" if name == page else "!selected"])
        self.header_title.configure(text=self.translator(page))
        self.header_description.configure(text=self.translator(page + "_description"))
        self.canvas.yview_moveto(0)
        self._schedule_wrap()

    def set_status(self, text, *, busy=None):
        if type(text) is not str or busy is not None and type(busy) is not bool:
            raise ValueError("Invalid workbench status")
        self.status_var.set(text)
        if busy is not None:
            self._busy = busy or bool(self.snapshot and self.snapshot.busy)
            self.profile_selector.configure(state="disabled" if self._busy else "readonly")
            action = self.snapshot.next_action if self.snapshot else None
            self.primary_button.state(["!disabled" if action and action.enabled and not self._busy else "disabled"])
            for button, item in self._feature_buttons:
                button.state(["!disabled" if item.enabled and not self._busy else "disabled"])
            if self._busy and not self._progress_running:
                self.footer_progress.grid()
                self.footer_progress.start(12)
                self._progress_running = True
            elif not self._busy and self._progress_running:
                self.footer_progress.stop()
                self.footer_progress.grid_remove()
                self._progress_running = False

    def _primary_selected(self):
        if self.snapshot and self.snapshot.next_action:
            self._action_selected(self.snapshot.next_action)

    def _action_selected(self, action):
        if not self._busy and action.enabled:
            self.on_action(action.id)

    def _profile_selected(self, _event=None):
        if self._busy or self.snapshot is None:
            return
        index = self.profile_selector.current()
        if 0 <= index < len(self.snapshot.profiles):
            self.on_profile(self.snapshot.profiles[index].id)

    def _language_selected(self, _event=None):
        self.on_language("zh" if self.language_var.get() == "简体中文" else "en")

    def _toggle_technical(self):
        self._technical_visible = not self._technical_visible
        if self._technical_visible:
            self.technical_frame.grid()
        else:
            self.technical_frame.grid_remove()
        self.technical_toggle.configure(text=self.translator("hide_technical" if self._technical_visible else "show_technical"))

    def _canvas_resized(self, event):
        self.canvas.itemconfigure(self._canvas_window, width=max(1, event.width))
        if event.width != self._last_canvas_width:
            self._last_canvas_width = event.width
            self._schedule_wrap()

    def _content_resized(self, _event=None):
        self.canvas.configure(scrollregion=self.canvas.bbox("all"))

    def _schedule_wrap(self, _event=None):
        if not self._disposed and self._wrap_after is None and self.widget.winfo_exists():
            self._wrap_after = self.widget.after_idle(self._wrap)

    def _wrap(self):
        self._wrap_after = None
        live = []
        for widget in self._wrap_labels:
            if widget.winfo_exists():
                live.append(widget)
                if widget.winfo_ismapped() and widget.master.winfo_width() > 1:
                    width = max(80, min(widget.master.winfo_width() - 48, self.canvas.winfo_width() - 96))
                    sticky = str(widget.grid_info().get("sticky", ""))
                    if "e" in sticky and "w" in sticky and widget.winfo_width() > 1:
                        width = max(80, min(width, widget.winfo_width() - 4))
                    if int(widget.cget("wraplength")) != width:
                        widget.configure(wraplength=width)
        self._wrap_labels = live
        self._content_resized()

    def _mousewheel(self, event):
        widget = event.widget
        if isinstance(widget, (self.tk.Text, self.ttk.Combobox, self.ttk.Entry)):
            return
        while widget is not None and widget is not self.widget:
            widget = getattr(widget, "master", None)
        if widget is None:
            return
        if event.delta:
            self.canvas.yview_scroll(-1 if event.delta > 0 else 1, "units")
            return "break"

    def _destroyed(self, event):
        if event.widget is not self.widget:
            return
        self.dispose()

    def dispose(self):
        """Stop only this view's scheduled UI callbacks before root destruction."""
        if self._disposed:
            return
        self._disposed = True
        if self._wrap_after is not None:
            try:
                self.widget.after_cancel(self._wrap_after)
            except self.tk.TclError:
                pass
            self._wrap_after = None
        if self._progress_running:
            try:
                self.footer_progress.stop()
            except self.tk.TclError:
                pass
            self._progress_running = False
        try:
            self.root.unbind("<MouseWheel>", self._wheel_binding)
        except self.tk.TclError:
            pass
