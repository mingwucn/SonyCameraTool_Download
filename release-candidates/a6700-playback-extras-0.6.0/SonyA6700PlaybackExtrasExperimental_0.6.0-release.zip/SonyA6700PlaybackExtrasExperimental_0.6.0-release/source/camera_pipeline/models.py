"""Immutable inputs; models supply values, shared workflows validate their shape."""
from dataclasses import dataclass
from pathlib import Path


def is_sha256(value):
    return type(value) is str and len(value) == 64 and all(c in "0123456789abcdef" for c in value)


@dataclass(frozen=True)
class ArtifactReference:
    path: Path
    sha256: str

    def __post_init__(self):
        if not isinstance(self.path, Path) or not self.path.is_absolute() or not is_sha256(self.sha256):
            raise ValueError("An absolute artifact path and exact SHA-256 are required")


@dataclass(frozen=True)
class ApplicationRequest:
    recovery: ArtifactReference
    backup: ArtifactReference
    owner_approval_text: str

    def __post_init__(self):
        if (type(self.recovery) is not ArtifactReference or type(self.backup) is not ArtifactReference
                or type(self.owner_approval_text) is not str or not self.owner_approval_text.strip()
                or len(self.owner_approval_text.encode("utf-8")) > 16384):
            raise ValueError("Supply the selected scope, backup and bounded owner approval text")


@dataclass(frozen=True)
class ByteChange:
    """An offset within supplied bytes; never a camera storage address."""
    offset: int
    before: bytes
    after: bytes
    alignment: int = 1

    def __post_init__(self):
        if (type(self.offset) is not int or self.offset < 0
                or type(self.alignment) is not int or self.alignment < 1
                or self.offset % self.alignment
                or type(self.before) is not bytes or type(self.after) is not bytes
                or not self.before or len(self.before) != len(self.after) or self.before == self.after):
            raise ValueError("A bounded, aligned, equal-width byte change is required")


@dataclass(frozen=True)
class ApplicationTarget:
    model: str
    firmware: str
    target_file: str
    size: int
    stock_sha256: str
    candidate_sha256: str
    changes: tuple[ByteChange, ...]
    # Explicit model-owned file growth. Existing equal-size targets default to
    # no tail; this does not imply that any camera engine supports resizing.
    appended: bytes = b""

    def __post_init__(self):
        if (any(type(v) is not str or not v.strip() for v in (self.model, self.firmware, self.target_file))
                or not self.target_file.startswith("/") or ".." in self.target_file.split("/")
                or type(self.size) is not int or self.size < 1
                or not is_sha256(self.stock_sha256) or not is_sha256(self.candidate_sha256)
                or self.stock_sha256 == self.candidate_sha256
                or type(self.changes) is not tuple or not self.changes
                or any(type(c) is not ByteChange for c in self.changes)
                or type(self.appended) is not bytes):
            raise ValueError("An exact model/firmware application target is required")
        end = 0
        for change in self.changes:
            if change.offset < end or change.offset + len(change.before) > self.size:
                raise ValueError("Application edits must be ordered, disjoint and within the file")
            end = change.offset + len(change.before)

    @property
    def candidate_size(self):
        return self.size + len(self.appended)
