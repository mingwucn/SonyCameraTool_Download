"""Reusable execution template; camera adapters keep their proven I/O engines.

Availability -> request -> preconditions -> one execution -> outcome validation.
No lease, device address, USB operation, retry, rollback or activation is inferred
by this template. Those belong to the explicitly injected model implementation.
"""
from abc import ABC, abstractmethod
from copy import deepcopy
from threading import Lock

from .models import ApplicationRequest


class TransactionError(RuntimeError):
    pass


class ApplicationTransaction(ABC):
    operation = "application"

    def __init__(self):
        self._guard = Lock()
        self._state_guard = Lock()
        self._state = "ready"
        self._execution_started = False
        self._result = None

    def _record(self, state, *, execution_started=False, result=None):
        # State readers never wait for a camera operation or an execution lock.
        with self._state_guard:
            self._state = state
            self._execution_started = self._execution_started or execution_started
            if state == "complete":
                self._result = deepcopy(result)

    @abstractmethod
    def require_available(self):
        """Reject an unavailable action before storage, factories or hardware."""

    @abstractmethod
    def describe_target(self):
        """Return a pure-data model-specific preview; do not open hardware."""

    def preview(self):
        return {"operation": self.operation, "target": deepcopy(self.describe_target()),
                "camera_access_performed": False, "activation_included": False}

    def validate_request(self, request):
        if type(request) is not ApplicationRequest:
            raise TransactionError("An explicit immutable application request is required")

    @abstractmethod
    def validate_preconditions(self, request):
        """Verify selected artifacts/scope without executing the mutation."""

    @abstractmethod
    def perform(self, request):
        """Delegate once to the model transaction; preserve its errors/evidence."""

    @abstractmethod
    def validate_outcome(self, result):
        """Accept only the model's complete verified result; never infer UI success."""

    def execute(self, request):
        # Authorization/capability checks precede even structural validation.
        self.require_available()
        if not self._guard.acquire(blocking=False):
            raise TransactionError("This transaction is already executing")
        try:
            if self._state != "ready":
                raise TransactionError("This transaction was already selected; inspect its retained outcome")
            self._record("validating")
            try:
                self.validate_request(request)
                self.validate_preconditions(request)
                self._record("executing", execution_started=True)
                result = self.perform(request)
                self._record("verifying")
                self.validate_outcome(result)
                self._record("complete", result=result)
                return deepcopy(result)
            except BaseException:
                # Keep the original exception/cause chain for the caller's
                # transport diagnostic and journal. Never run an exit/retry here.
                self._record("needs_review")
                raise
        finally:
            self._guard.release()

    def inspect_outcome(self):
        with self._state_guard:
            return {"operation": self.operation, "status": self._state,
                    "execution_started": self._execution_started,
                    "result": deepcopy(self._result), "automatic_retry": False}
