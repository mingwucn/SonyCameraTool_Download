"""Explicit playback extras inspection or one separately reviewed experimental action."""
import os
import json
from pathlib import Path
import queue
import sys
import threading
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

if not getattr(sys, "frozen", False):
    for parent in Path(__file__).resolve().parents:
        if (parent / "camera_pipeline").is_dir():
            sys.path.insert(0, str(parent))
            break

from camera_pipeline.gui import WorkflowController
from camera_pipeline.workbench import WorkbenchWindow
from tools.playback_extras_workflow import Workflow
from tools.playback_extras_pipeline import PlaybackExtrasPipeline, run_cli_worker, workflow_event
from tools.playback_extras_presentation import PlaybackExtrasPresentation


def driver_dependencies():
    return Path(__file__).resolve().parent / '.data/playback-driver-assets-20261104'


def driver_state_root(create=False):
    local = os.environ.get('LOCALAPPDATA')
    if not local:
        raise RuntimeError('LOCALAPPDATA is unavailable; no driver action started')
    if not Path(local).is_absolute():
        raise RuntimeError('LOCALAPPDATA must be an absolute local directory')
    path = Path(local) / 'SonyA6700DriverJobs'
    if create:
        from tools import a6700_drivers
        a6700_drivers._directory(path.parent, durable=True)
        path.mkdir(exist_ok=True)
        a6700_drivers._directory(path, durable=True)
    return path


def assert_no_driver_uncertainty():
    lock = driver_state_root() / 'a6700-driver.lock'
    if lock.exists() or lock.is_symlink():
        raise RuntimeError('A USB driver job needs review. Preserve SonyA6700DriverJobs; no service action started.')


def offline_filter_arguments(argv):
    """Capture two explicit absolute paths without inspecting or opening them."""
    if (type(argv) not in (list, tuple) or len(argv) != 4 or
            any(type(value) is not str for value in argv) or
            argv[0] != '--prepare-filter-candidate' or argv[2] != '--output-parent' or
            any(not value or value.startswith('--') for value in (argv[1], argv[3]))):
        raise ValueError('Select an App reference and an existing output parent')
    paths = Path(argv[1]), Path(argv[3])
    if not all(path.is_absolute() for path in paths):
        raise ValueError('The App reference and output parent must be absolute paths')
    return paths


def prepare_offline_filter_candidate(app_reference, output_parent):
    # Import only after an explicit offline selection. This helper owns no
    # camera workflow state and never sets up the customizer runtime.
    from tools.playback_filter_offline import prepare
    return prepare(app_reference=app_reference, output_parent=output_parent)


def setup_runtime():
    if getattr(sys, "frozen", False):
        root = Path(sys.executable).resolve().parent
    else:
        configured_root = os.environ.get("POWERFUL6700_ROOT")
        if not configured_root:
            raise SystemExit("Set POWERFUL6700_ROOT to the existing customizer runtime directory")
        root = Path(configured_root).expanduser().resolve()
    if not (root / "_internal/third_party/a6700_unlock").is_dir():
        raise SystemExit("Original customizer runtime is missing; no camera action started")
    os.environ["POWERFUL6700_ROOT"] = str(root)
    if not getattr(sys, "frozen", False):
        sys.path.insert(0, str(Path(__file__).resolve().parent / "apps/a6700_customizer"))


def worker(argv):
    if argv == ['--filter-payload-self-check']:
        from tools.playback_filter_offline import self_check
        print(json.dumps(self_check()), flush=True)
        return 0
    if argv and argv[0] == '--prepare-filter-candidate':
        try:
            app_reference, output_parent = offline_filter_arguments(argv)
            result = prepare_offline_filter_candidate(app_reference, output_parent)
            if type(result) is not dict:
                raise TypeError('Offline preparation did not return a result')
        except Exception as exc:
            print(json.dumps({'status': 'STOPPED', 'error_type': type(exc).__name__,
                              'camera_commands': 0}), flush=True)
            return 2
        print(json.dumps(result), flush=True)
        return 0
    if argv == ['--workflow-self-check']:
        from tools.playback_extras_workflow import self_check
        print(json.dumps(self_check()), flush=True)
        return 0
    if argv == ['--general-transfer-reader-self-check']:
        from tools import playback_general_transfer_probe
        return playback_general_transfer_probe.main(argv)
    if argv == ['--check-connection']:
        from tools import a6700_drivers
        print(json.dumps(a6700_drivers.check_connection()), flush=True)
        return 0
    if argv == ['--driver-self-check']:
        from tools import a6700_drivers
        a6700_drivers.validate_assets(driver_dependencies() / 'driver/libwdi')
        print('PINNED_DRIVER_ASSETS_OK; CAMERA_COMMANDS=0; DRIVER_CHANGES=0')
        return 0
    if argv == ['--usb-observer-self-check']:
        from tools.usb_observer_self_check import run
        print(json.dumps(run()), flush=True)
        return 0
    if len(argv) == 2 and argv[0] == '--driver-worker' and argv[1] and not argv[1].startswith('--'):
        from tools import a6700_drivers
        result = a6700_drivers.execute_job(argv[1], dependency_root=driver_dependencies())
        print(json.dumps(result), flush=True)
        return 0 if result.get('ok') is True else 2
    if argv in (["--self-check"], ["--transport-self-check"], ["--inspect-playback-extras"],
                ["--inspect-general-transfer"]):
        if argv in (['--inspect-playback-extras'], ['--inspect-general-transfer']):
            assert_no_driver_uncertainty()
        if argv[0] in ("--inspect-playback-extras", "--inspect-general-transfer", "--transport-self-check"):
            setup_runtime()
        if argv == ['--inspect-general-transfer']:
            from tools import playback_general_transfer_probe
            return playback_general_transfer_probe.main(argv)
        from tools import playback_extras_probe
        return playback_extras_probe.main(argv)
    if argv in (["--writer-self-check"], ["--describe"]):
        from tools import experimental_playback_extras
        return experimental_playback_extras.main(["--self-check"] if argv == ["--writer-self-check"] else argv)
    if (len(argv) == 5 and argv[0] == "--apply-playback-extras" and
            argv[1] in ("shortcut", "label", "general_transfer") and argv[2] == "--inspection-record" and
            argv[3] and not argv[3].startswith("--") and
            argv[4] == "--confirm-experimental-playback-extras"):
        assert_no_driver_uncertainty()
        setup_runtime()
        from tools import experimental_playback_extras
        return experimental_playback_extras.main(argv)
    print("Unknown or incomplete action; no camera action started", file=sys.stderr)
    return 2


SHORTCUT_BUTTON_TITLE = "Enable current-image FTP action…"
CURRENT_IMAGE_NOTE = (
    "FTP Trans. (This Img.) is the action for the currently displayed image; α6700 assignment "
    "and transfer still need owner checks."
)
GENERAL_TRANSFER_NOTE = (
    "FTP Transfer is a separate C1/C2 playback action. The experimental path reads only two App-only windows, "
    "the 0x4a8 general row and the existing 0x4c7 current-image row; it does not "
    "read or write WBI. Picker visibility and transfer behavior still need physical checks."
)
ACTION_TITLES = {
    "shortcut": "Expose FTP Trans. (This Img.) for the currently displayed image",
    "general_transfer": "Expose FTP Transfer for C1/C2 playback assignment",
    "label": "Correct transferred-image label",
}
COMMON_REVIEW = (
    "The fresh seven-window read must match the selected saved inspection. The complete normalized "
    "App and English are checked before and after. All seven complete windows are independently "
    "read afterward. Verified 3,584-byte preimages are saved on C: and D:; these are partial backups.\n\n"
    "Service authentication and helper staging may change camera files. Failed-start recovery, "
    "physical WBI geometry and WBI integrity handling remain unproven. The logical byte count "
    "does not bound physical flash writes. This could affect the working camera.\n\n"
    "This does not repair playback-filter execution. One attempt only; no automatic retry or rollback. "
    "If completion is uncertain, keep camera power and USB connected and preserve all records. "
    "Continue only for the owner-confirmed ILCE-6700 Body 2.00 with normal English operation."
)
ACTION_REVIEWS = {
    "shortcut": (
        "Expose FTP Trans. (This Img.) in playback Custom Key Setting?\n\n"
        "Exactly two App permission bytes change 00 to 01: 0x03788e52 and 0x03788e53. "
        "They cover the existing playback assignment categories 20 and 21. Existing button "
        "permissions and assignments stay as they are. The writer opens only App, with one "
        "512-byte transaction target. No WBI shortcut mapping is used.\n\n"
        "The function may still be hidden or fail at runtime; assignment and a real transfer "
        "need physical testing.\n\n" + COMMON_REVIEW),
    "label": (
        "Correct the third FTP-status choice to Success. Trans. Img.?\n\n"
        "Redirect title RID 0x020080ce to existing Sony RID 0x02006077 at App file 0x04c36b8c "
        "and the existing assumed WBI device-file coordinate 0x025c1d8c. Two bytes change in "
        "each four-byte field, four bytes total across two 512-byte transaction targets, WBI "
        "then App. The smartphone title and all UXC resource files stay as they are.\n\n" + COMMON_REVIEW),
    "general_transfer": (
        "Expose FTP Transfer in the C1/C2 Playback Custom Key picker?\n\n"
        "The fresh two-window App-only read must match the selected inspection. Exactly one byte "
        "changes from 00 to 01 at App file offset 0x03788dc3 (the FTP Transfer row, playback "
        "category 21). The current-image 0x4c7 C1/C2 pair is checked and preserved. One 512-byte "
        "App transaction target is used. This action uses no WBI read or write path and does not repair "
        "playback-filter execution.\n\n"
        "The local two-window App preimage is copied to two host volumes; it is a partial backup, "
        "not a full firmware backup. Failed-start recovery and physical flash-write extent remain "
        "unverified. One attempt only; no automatic retry or rollback.\n\n"
        "If the change completes, verify normal English and Network FTP, then check that FTP "
        "Transfer appears in the picker. Assignment, persistence after restart, selection behavior, "
        "and server receipts still require physical checks.\n\n"
        "Inspection Folder:\n"),
}


def confirmed_action_arguments(action, folder, confirm):
    """Review one exact action; cancellation or an absent record dispatches nothing."""
    if action not in ACTION_REVIEWS or not folder or folder.startswith("--"):
        raise ValueError("Select an action and a saved inspection folder")
    inspection = ("two-window App-only" if action == "general_transfer" else "seven-window")
    if not confirm(ACTION_TITLES[action], ACTION_REVIEWS[action] +
                   "\n\nSelected " + inspection + " inspection folder:\n" + folder):
        return None
    return ["--apply-playback-extras", action, "--inspection-record", folder,
            "--confirm-experimental-playback-extras"]


def is_fake_root(r):
    return hasattr(r, 'callbacks') or type(r).__name__ == 'FakeRoot'


def main():
    gui_check = sys.argv[1:] == ["--gui-self-check"]
    if len(sys.argv) > 1 and not gui_check:
        return worker(sys.argv[1:])
    root = tk.Tk()
    if gui_check:
        root.withdraw()
    root.title("Sony α6700 — Playback FTP Extras Experimental 0.6.0")
    width = min(1120, max(640, root.winfo_screenwidth() - 80))
    height = min(820, max(600, root.winfo_screenheight() - 100))
    root.geometry("%sx%s" % (width, height))
    root.minsize(min(940, width), min(700, height))
    language = ["en"]
    presentation = PlaybackExtrasPresentation()
    activity = []

    def dispatch(action):
        if action == 'inspect':
            start(["--inspect-playback-extras"])
        elif action in ('features', 'activity', 'advanced'):
            view.set_page(action)

    def change_language(selected):
        language[0] = selected
        update_controls()

    view = WorkbenchWindow(root, on_action=dispatch,
                           on_profile=lambda _profile: None, on_language=change_language)
    view.style.configure('Workbench.TLabelframe', background='#18181b', foreground='#f4f4f5',
                         bordercolor='#3f3f46')
    view.style.configure('Workbench.TLabelframe.Label', background='#18181b', foreground='#f4f4f5',
                         font=('Segoe UI', 11))
    frame = view.feature_controls

    # 1. State Variables: Keep checked, status, folder as the FIRST THREE for test fixture compatibility
    checked = tk.BooleanVar(value=False)
    status = tk.StringVar(value="Shortcut behavior and label rendering need camera checks. Filter execution is unchanged. No automatic retry.")
    folder = tk.StringVar()
    shortcut_var = tk.BooleanVar(value=True)
    label_var = tk.BooleanVar(value=False)
    conn_badge_var = tk.StringVar(value="⚪ Checking connection…")
    conn_detail_var = tk.StringVar(value="Connecting to Sony ILCE-6700 PnP metadata…")
    shortcut_badge_var = tk.StringVar(value="[Ready to apply]")
    label_badge_var = tk.StringVar(value="[Cosmetic option]")
    general_var = tk.BooleanVar(value=False)
    general_badge_var = tk.StringVar(value="[Not inspected]")

    flow = Workflow()
    quick_state = {'auto': False, 'want_shortcut': True, 'want_label': False,
                   'want_general': False}

    def camera_conditions_changed():
        if checked.get() and flow.state == 'ACK_REQUIRED':
            flow.acknowledge()
            status.set(flow.message)
        update_controls()

    events, busy = queue.Queue(), [False]
    connection, driver_used = [None], [False]
    command_prefix = ([sys.executable] if getattr(sys, "frozen", False) else
                      [sys.executable, "-B", str(Path(__file__).resolve())])
    service = WorkflowController(PlaybackExtrasPipeline(
        lambda arguments, progress: run_cli_worker(arguments, progress, command_prefix=command_prefix)),
        events=events, failure=lambda _action, error: type(error).__name__)

    def update_connection_display(res):
        if not res:
            conn_badge_var.set("⚪ Connection: Unknown")
            conn_detail_var.set("Connect Sony α6700 via USB and set USB mode to Mass Storage.")
            return
        status_code = res.get('status')
        reason = res.get('reason', '')
        devices = res.get('devices', [])
        is_096f = any(d.get('pid') == 0x096F or '096F' in d.get('hardware_id', '') for d in devices)
        if status_code == 'ready':
            conn_badge_var.set("🟢 Camera Connected: Sony ILCE-6700 (0E76 MSC · WinUSB Ready)")
            conn_detail_var.set("Camera is connected and verified. Ready for inspection and function unlock.")
        elif status_code == 'driver_required':
            conn_badge_var.set("🟡 Driver Needed: Sony ILCE-6700 (0E76 MSC)")
            conn_detail_var.set("WinUSB driver required. Go to Advanced tab ➔ Install USB driver to bind WinUSB.")
        elif is_096f or status_code in ('device_model_unverified', 'unsupported_service'):
            conn_badge_var.set("🟠 Wrong USB Mode: Camera in PC Remote / Updater Mode (096F)")
            conn_detail_var.set("Switch on camera: Menu ➔ Network ➔ USB ➔ USB Connection Mode ➔ Mass Storage (MSC).")
        elif status_code == 'no_camera':
            conn_badge_var.set("⚪ No Camera Detected")
            conn_detail_var.set("Connect your Sony ILCE-6700 via USB and set USB Connection Mode to Mass Storage.")
        elif status_code == 'ambiguous':
            conn_badge_var.set("🔴 Multiple Cameras Detected")
            conn_detail_var.set("Please connect only one Sony camera at a time.")
        else:
            conn_badge_var.set("⚪ Camera Status: " + str(status_code))
            conn_detail_var.set(reason)

    def refresh_badges_from_folder(folder_path):
        if not folder_path:
            shortcut_badge_var.set("[Ready to apply]")
            label_badge_var.set("[Cosmetic option]")
            general_badge_var.set("[Not inspected]")
            return
        try:
            from tools import playback_extras_probe as p_probe
            from tools import playback_general_transfer_probe as g_probe
            from tools import playback_extras_candidate as p_cand
            if flow.selected_inspection == 'inspect_general':
                sectors = g_probe.saved_windows(folder_path)
            else:
                sectors = p_probe.saved_sectors(folder_path)
            live_st = p_cand.inspect_state(sectors)
            if live_st['shortcut']:
                shortcut_badge_var.set("[✓ Already Active]")
            else:
                shortcut_badge_var.set("[Ready to apply]")
            if 'label' in live_st:
                label_badge_var.set("[✓ Already Active]" if live_st['label'] else "[Cosmetic option]")
            else:
                label_badge_var.set("[Not included in this inspection]")
            if 'general_transfer' in live_st:
                general_badge_var.set("[✓ Already Active]" if live_st['general_transfer'] else "[Ready to apply]")
            else:
                general_badge_var.set("[Not included in this inspection]")
        except Exception:
            shortcut_badge_var.set("[Unknown]")
            label_badge_var.set("[Unknown]")
            general_badge_var.set("[Unknown]")

    def schedule_connection_poll():
        if is_fake_root(root):
            return
        if not busy[0] and flow.can_service:
            def poll():
                from tools import a6700_drivers
                try:
                    res = a6700_drivers.check_connection()
                    events.put(('connection_poll', res))
                except Exception:
                    pass
            threading.Thread(target=poll, daemon=True).start()
        root.after(3500, schedule_connection_poll)

    def update_controls():
        idle = not busy[0] and flow.can_service
        for widget in (read_button, read_general_button, browse_button, connection_button, refresh_button):
            widget.configure(state='normal' if idle else 'disabled')
        for widget in (shortcut_button, label_button, general_button):
            widget.configure(state='normal' if idle and flow.selected_folder else 'disabled')
        check.configure(state='normal' if not busy[0] and flow.state in ('READY', 'ACK_REQUIRED') else 'disabled')
        shortcut_check.configure(state='normal' if not busy[0] else 'disabled')
        label_check.configure(state='normal' if not busy[0] else 'disabled')
        general_check.configure(state='normal' if not busy[0] else 'disabled')
        quick_unlock_button.configure(state='normal' if idle and checked.get() else 'disabled')
        install_button.configure(state='normal' if idle and not driver_used[0] and
                                 connection[0] and connection[0].get('driver_install_available') else 'disabled')
        offline_button.configure(state='disabled' if busy[0] else 'normal')
        # Projection is passive: the original workflow remains the authority for
        # every worker/driver gate. Rendering cannot select a camera operation.
        technical = output.get('1.0', 'end-1c')
        view.render(presentation.present({
            'state': flow.state, 'busy': busy[0], 'conditions': checked.get(),
            'selected_folder': flow.selected_folder, 'connection': connection[0],
            'message': status.get(), 'activity': tuple(activity),
            'technical_result': technical,
        }, language=language[0]))
        output.configure(state='normal')

    def status_changed(*_args):
        message = status.get()
        if not activity or activity[-1] != message:
            activity.append(message)
        view.set_status(message, busy=busy[0])

    status.trace_add('write', status_changed)

    def driver_task(label, function, completed):
        if busy[0] or not flow.can_service:
            return
        busy[0] = True
        status.set(label + '…')
        update_controls()
        def run():
            try:
                result = function()
                events.put(('driver_result', (completed, result)))
            except Exception as exc:
                events.put(('driver_error', str(exc)))
        threading.Thread(target=run, daemon=False).start()

    def consume():
        try:
            while True:
                event = events.get_nowait()
                # An offline job shares the controller's one-job gate, but is
                # never an inspection/write result or a camera acknowledgement.
                if len(event) == 3 and event[1] == 'offline-filter':
                    kind, _label, value = event
                    if kind == 'progress':
                        output.insert('end', str(value) + '\n')
                    else:
                        busy[0] = False
                        if kind == 'result' and type(value) is dict:
                            output.insert('end', json.dumps(value, indent=2) + '\n')
                            status.set('Offline candidate preparation finished. Review its report; it is not installed.')
                        else:
                            output.insert('end', 'Offline preparation stopped: ' + str(value) + '\n')
                            status.set('Offline candidate preparation stopped. Review retained output before continuing.')
                        update_controls()
                    output.see('end')
                    continue
                kind, value = workflow_event(event) if len(event) == 3 else event
                if kind == "line":
                    run_id, line = value
                    if run_id != flow.run_id or flow.state != 'RUNNING':
                        continue
                    flow.feed(run_id, line)
                    output.insert("end", line)
                    output.see("end")
                elif kind == 'driver_result':
                    busy[0] = False
                    callback, result = value
                    output.insert('end', json.dumps(result, indent=2) + '\n')
                    output.see('end')
                    try:
                        callback(result)
                    except Exception as exc:
                        connection[0] = None
                        status.set('Driver/connection review stopped. No automatic continuation.')
                        output.insert('end', 'STOPPED: ' + str(exc) + '\n')
                    update_controls()
                elif kind == 'driver_error':
                    busy[0] = False
                    connection[0] = None
                    status.set('Driver/connection action stopped. Preserve its records; no automatic retry.')
                    output.insert('end', 'STOPPED: ' + value + '\n')
                    output.see('end')
                    update_controls()
                elif kind == 'connection_poll':
                    connection[0] = value
                    update_connection_display(value)
                    update_controls()
                    continue
                elif kind == 'done':
                    run_id, code = value
                    if run_id != flow.run_id or flow.state != 'RUNNING':
                        continue
                    completed_op = flow._operation
                    try:
                        flow.finish(run_id, code)
                    except Exception:
                        flow.state = 'NEEDS_REVIEW'
                        flow.selected_folder = ''
                        flow.message = ('The worker result could not be reconciled. Keep camera power and USB '
                                        'connected; preserve records and do not repeat.')
                    busy[0] = False
                    connection[0] = None
                    folder.set(flow.selected_folder)
                    refresh_badges_from_folder(flow.selected_folder)
                    if flow.state in ('ACK_REQUIRED', 'NEEDS_REVIEW'):
                        checked.set(False)
                    status.set(flow.message)
                    update_controls()

                    if quick_state.get('auto'):
                        quick_state['auto'] = False
                        if flow.state == 'ACK_REQUIRED' and flow.selected_folder:
                            flow.acknowledge()
                            checked.set(True)
                            proceed_with_unlock(quick_state['want_shortcut'], quick_state['want_label'],
                                                quick_state['want_general'])
                    elif flow.state == 'ACK_REQUIRED' and completed_op in ('shortcut', 'label', 'general_transfer'):
                        if not is_fake_root(root):
                            op_name = ({'shortcut': "Current-image FTP action",
                                        'label': "Transferred-Image Label",
                                        'general_transfer': "General FTP Transfer"}[completed_op])
                            next_steps = {
                                'shortcut': (
                                    "5. Assign an available playback key to 'FTP Trans. (This Img.)'.\n"
                                    "6. Test it with the configured FTP receiver.\n"),
                                'general_transfer': (
                                    "5. Assign a different playback key to 'FTP Transfer'.\n"
                                    "6. With Auto Transfer off, test two selected JPEGs and verify the receipts.\n"),
                                'label': "5. Check the third FTP-status label in playback filtering.\n",
                            }[completed_op]
                            success_guide = (
                                "🎉 " + op_name + " Unlocked & Verified!\n\n"
                                "Independent readback verification succeeded. Menu visibility and FTP behavior still need camera checks.\n\n"
                                "Next Steps to Use on Your Camera:\n"
                                "1. Turn off camera power and disconnect the USB cable.\n"
                                "2. Turn camera power back on. Verify normal English menu operation.\n"
                                "3. Open Menu ➔ Setup ➔ Operation Customize ➔ Custom Key/Dial Setting.\n"
                                "4. Switch to Playback tab (page 3/3).\n" + next_steps
                            )
                            if completed_op == 'shortcut' and quick_state.get('want_label'):
                                success_guide += (
                                    "\nNote on Label Correction:\n"
                                    "To apply the cosmetic label correction now:\n"
                                    "1. Power cycle camera and reconnect in Mass Storage mode.\n"
                                    "2. Re-check camera conditions and click Unlock Selected Functions with Label selected."
                                )
                            messagebox.showinfo("Unlock Completed", success_guide, parent=root)
                elif kind == 'worker_unconfirmed':
                    run_id, error_type = value
                    if run_id != flow.run_id or flow.state != 'RUNNING':
                        continue
                    status.set('Worker termination is unconfirmed. Keep camera power and USB connected; '
                               'preserve records. No further operation is available.')
                    output.insert('end', 'Worker termination could not be confirmed: ' + error_type + '\n')
                elif kind == 'worker_failed':
                    run_id, error_type = value
                    if run_id != flow.run_id or flow.state != 'RUNNING':
                        continue
                    busy[0] = False
                    flow.state = 'NEEDS_REVIEW'
                    flow.selected_folder = ''
                    checked.set(False)
                    folder.set('')
                    connection[0] = None
                    status.set('The worker failed before its result could be reconciled. Keep camera power '
                               'and USB connected; preserve records. No further operation is available.')
                    output.insert('end', 'Worker failed: ' + error_type + '\n')
                    update_controls()
        except queue.Empty:
            pass
        root.after(100, consume)

    def start(argv):
        if not checked.get() or busy[0] or not flow.can_service:
            return
        operation = ('inspect' if argv == ['--inspect-playback-extras'] else
                     'inspect_general' if argv == ['--inspect-general-transfer'] else argv[1])
        try:
            run_id = flow.begin(operation)
        except (ValueError, RuntimeError) as exc:
            status.set(str(exc))
            return
        folder.set(flow.selected_folder)
        busy[0] = True
        update_controls()
        status.set("One operation running. Keep USB connected. Preserve the private records and follow the result.")
        try:
            accepted = service.start(operation, {"arguments": tuple(argv)}, label=run_id)
        except Exception as exc:
            events.put(('worker_failed', (run_id, type(exc).__name__)))
        else:
            if not accepted:
                events.put(('worker_failed', (run_id, 'WorkflowBusy')))

    driver_frame = ttk.LabelFrame(view.advanced_controls, text='Windows USB connection', padding=8,
                                  style='Workbench.TLabelframe')
    driver_frame.pack(fill='x', pady=6)
    driver_row = ttk.Frame(driver_frame, style='Workbench.TFrame')
    driver_row.pack(anchor='w')

    def connection_result(result):
        connection[0] = result
        update_connection_display(result)
        status.set(result.get('reason', 'Connection check finished'))

    def check_connection():
        from tools import a6700_drivers
        driver_task('Checking Windows connection (no service command)',
                    a6700_drivers.check_connection, connection_result)

    def driver_result(result):
        connection[0] = None
        update_connection_display(None)
        status.set('Driver job finished. Select Check connection to verify the current binding.')

    def review_driver(plan):
        target = plan['target']
        review = (
            'Install WinUSB for this exact connected camera?\n\n'
            'Model: ILCE-6700\nTarget: ' + target['hardware_id'] + '\n'
            'Current driver: ' + target['current_service'] + ' / ' + target['current_inf'] + '\n\n'
            'This changes the Windows USB driver. The camera/card may disappear from Explorer. '
            'It does not write camera firmware. Original driver metadata is retained at:\n' +
            plan['original_driver_record'] + '\n\n'
            'Windows administrator approval (UAC) will be requested if needed. '
            'Only the normal 0E76 interface is allowed; A7CR and shared service 0336 are excluded. '
            'An uncertain install is retained for review, without retry or automatic restoration.'
        )
        if not messagebox.askyesno('Review USB driver installation', review, parent=root,
                                   icon='warning', default='no'):
            status.set('Driver plan retained. Installation was not selected.')
            return
        driver_used[0] = True
        from tools import a6700_drivers
        def install():
            result = a6700_drivers.install_driver(
                plan, 'Owner selected Install USB driver and confirmed the exact ILCE-6700 0E76 target, Windows driver effects and UAC handoff.')
            if result.get('status') == 'requires_elevation':
                a6700_drivers.request_elevation(result['request_path'], entrypoint=Path(__file__).resolve())
                return a6700_drivers.wait_for_job(result['request_path'])
            return result
        driver_task('Installing the reviewed USB driver once', install, driver_result)

    def prepare_driver():
        if not connection[0] or not connection[0].get('driver_install_available'):
            status.set('Select Check connection first. An existing WinUSB binding needs no installation.')
            return
        from tools import a6700_drivers
        driver_task('Preparing the exact driver review',
                    lambda: a6700_drivers.prepare_driver(connection[0], driver_dependencies(), driver_state_root(create=True)),
                    review_driver)

    connection_button = ttk.Button(driver_row, text='Check connection', command=check_connection,
                                    style='Workbench.TButton')
    connection_button.pack(side='left')
    install_button = ttk.Button(driver_row, text='Install USB driver…', command=prepare_driver, state='disabled',
                                style='Workbench.TButton')
    install_button.pack(side='left', padx=8)
    view.label(driver_frame, text='Check reads Windows metadata only. Install is separate and asks for the exact target before UAC.').pack(anchor='w', fill='x', pady=(5, 0))

    offline_frame = ttk.LabelFrame(view.advanced_controls, text='Offline playback filter candidate',
                                   padding=8, style='Workbench.TLabelframe')
    offline_frame.pack(fill='x', pady=6)
    view.label(offline_frame, text=(
        'Prepare an FTP-status-only candidate from the exact historical stock α6700 App. '
        'The candidate is not installed. Qualification against the camera’s modified App, '
        'loader and write profile is pending.'
    )).pack(anchor='w', fill='x', pady=(0, 6))

    def prepare_offline_filter():
        if busy[0]:
            return
        chosen_app = filedialog.askopenfilename(parent=root, title='Select the historical stock α6700 App reference',
                                                filetypes=(('App reference', '*.so'), ('All files', '*.*')))
        if not chosen_app:
            return
        chosen_output = filedialog.askdirectory(parent=root, title='Select an existing private output parent',
                                                mustexist=True)
        if not chosen_output:
            return
        try:
            app_reference, output_parent = offline_filter_arguments([
                '--prepare-filter-candidate', chosen_app, '--output-parent', chosen_output])
        except ValueError as exc:
            status.set(str(exc))
            return
        busy[0] = True
        status.set('Preparing an offline FTP filter candidate…')
        update_controls()
        def selected():
            events.put(('progress', 'offline-filter', 'Preparing selected ordinary files; camera commands: 0.'))
            return prepare_offline_filter_candidate(app_reference, output_parent)
        try:
            accepted = service.start_function('offline-filter', selected)
        except Exception as exc:
            events.put(('error', 'offline-filter', type(exc).__name__))
        else:
            if not accepted:
                events.put(('error', 'offline-filter', 'WorkflowBusy'))

    offline_button = ttk.Button(offline_frame, text='Prepare offline filter candidate…',
                                command=prepare_offline_filter, style='Workbench.TButton')
    offline_button.pack(anchor='w')

    # 1. Live USB Connection Card
    conn_frame = ttk.LabelFrame(frame, text="Live USB Connection Status", padding=10,
                                style='Workbench.TLabelframe')
    conn_frame.pack(fill="x", pady=(0, 10))
    conn_header = ttk.Frame(conn_frame, style='Workbench.TFrame')
    conn_header.pack(fill="x")
    ttk.Label(conn_header, textvariable=conn_badge_var, font=('Segoe UI', 11, 'bold'),
              style='Workbench.TLabel').pack(side='left', anchor='w')
    refresh_button = ttk.Button(conn_header, text='↻ Refresh', command=check_connection,
                                style='Workbench.TButton')
    refresh_button.pack(side='right')
    ttk.Label(conn_frame, textvariable=conn_detail_var, style='Workbench.Muted.TLabel',
              wraplength=640, justify='left').pack(anchor='w', fill='x', pady=(4, 0))

    # 2. Quick Unlock Card
    quick_frame = ttk.LabelFrame(frame, text="⚡ Quick Unlock (Recommended)", padding=10,
                                 style='Workbench.TLabelframe')
    quick_frame.pack(fill="x", pady=(0, 10))
    view.label(quick_frame, text=(
        "One-click inspection, preimage verification, and unlock for your Sony α6700.\n"
        "Preimages are backed up to C: and D:; writes are verified by immediate readback."
    ), kind='muted').pack(anchor="w", fill="x", pady=(0, 8))

    # Feature 1: Current-image FTP action
    sc_row = ttk.Frame(quick_frame, style='Workbench.TFrame')
    sc_row.pack(fill="x", pady=2)
    shortcut_check = ttk.Checkbutton(sc_row, text="Enable Current-image FTP Action (Custom Key) [Primary]",
                                     variable=shortcut_var, command=update_controls,
                                     style="Workbench.TCheckbutton")
    shortcut_check.pack(side='left', anchor='w')
    ttk.Label(sc_row, textvariable=shortcut_badge_var, style='Workbench.Muted.TLabel').pack(side='left', padx=10)
    view.label(quick_frame, text=(
        "  ↳ " + CURRENT_IMAGE_NOTE
    ), kind='muted').pack(anchor='w', fill='x', pady=(0, 4))

    gt_row = ttk.Frame(quick_frame, style='Workbench.TFrame')
    gt_row.pack(fill="x", pady=2)
    general_check = ttk.Checkbutton(gt_row, text="Enable General FTP Transfer (Custom Key)",
                                    variable=general_var, command=update_controls,
                                    style='Workbench.TCheckbutton')
    general_check.pack(side='left', anchor='w')
    ttk.Label(gt_row, textvariable=general_badge_var,
              style='Workbench.Muted.TLabel').pack(side='left', padx=10)
    view.label(quick_frame, text="  ↳ " + GENERAL_TRANSFER_NOTE,
               kind='muted').pack(anchor="w", fill='x', pady=(0, 8))

    # Feature 2: Transferred-Image Label
    lbl_row = ttk.Frame(quick_frame, style='Workbench.TFrame')
    lbl_row.pack(fill="x", pady=2)
    label_check = ttk.Checkbutton(lbl_row, text="Correct Transferred-Image Menu Label [Follow-up]",
                                  variable=label_var, command=update_controls,
                                  style="Workbench.TCheckbutton")
    label_check.pack(side='left', anchor='w')
    ttk.Label(lbl_row, textvariable=label_badge_var, style='Workbench.Muted.TLabel').pack(side='left', padx=10)
    view.label(quick_frame, text=(
        "  ↳ Fixes Japanese translation string RID to 'Success. Trans. Img.' in FTP filter choices."
    ), kind='muted').pack(anchor='w', fill='x', pady=(0, 8))

    def proceed_with_unlock(want_shortcut, want_label, want_general=False):
        if not flow.selected_folder:
            status.set("No valid inspection record selected.")
            return
        try:
            from tools import playback_extras_probe as p_probe
            from tools import playback_general_transfer_probe as g_probe
            from tools import playback_extras_candidate as p_cand
            if want_general:
                if want_shortcut or want_label or flow.selected_inspection != 'inspect_general':
                    raise ValueError("FTP Transfer needs its own two-window App-only inspection; select it separately.")
                sectors = g_probe.saved_windows(flow.selected_folder)
            else:
                if flow.selected_inspection != 'inspect':
                    raise ValueError("The current-image shortcut and label need their own seven-window inspection.")
                sectors = p_probe.saved_sectors(flow.selected_folder)
            live_st = p_cand.inspect_state(sectors)
        except Exception as exc:
            status.set("Inspection invalid: " + str(exc))
            return

        refresh_badges_from_folder(flow.selected_folder)
        needs_shortcut = want_shortcut and not live_st['shortcut']
        needs_label = want_label and not live_st['label']
        needs_general = want_general and not live_st['general_transfer']

        if not needs_shortcut and not needs_label and not needs_general:
            if not is_fake_root(root):
                name = "FTP Transfer" if want_general else "FTP Trans. (This Img.)"
                messagebox.showinfo("Already Active",
                    name + " already has its C1/C2 playback permission byte enabled. "
                    "Confirm it appears in the picker and test it physically with the receiver.",
                    parent=root)
            status.set("Selected functions are already active on this camera.")
            return

        actions_list = []
        if needs_shortcut:
            actions_list.append("• Enable current-image FTP action ('FTP Trans. (This Img.)')")
        if needs_general:
            actions_list.append("• Enable general FTP action ('FTP Transfer') for C1/C2")
        if needs_label:
            actions_list.append("• Correct Transferred-Image Menu Label ('Success. Trans. Img.')")
        if want_shortcut and live_st['shortcut']:
            actions_list.append("• Current-image FTP action: ALREADY active (will skip)")
        if want_label and live_st['label']:
            actions_list.append("• Transferred-Image Label: ALREADY active (will skip)")

        target_action = ('general_transfer' if needs_general else
                         'shortcut' if needs_shortcut else 'label')
        argv = confirmed_action_arguments(target_action, flow.selected_folder,
            lambda title, review: messagebox.askyesno(title, review, parent=root,
                                                      icon="warning", default="no"))
        if argv is None:
            status.set("Change cancelled. The camera was not contacted.")
            return
        start(argv)

    def on_quick_unlock():
        if busy[0] or not flow.can_service:
            return
        if not checked.get():
            status.set("Please confirm the camera conditions before unlocking.")
            return
        want_shortcut = shortcut_var.get()
        want_label = label_var.get()
        want_general = general_var.get()
        if want_general and (want_shortcut or want_label):
            status.set("Read and apply FTP Transfer separately from the current-image shortcut and label.")
            return
        if not want_shortcut and not want_label and not want_general:
            status.set("Please select at least one function to unlock.")
            return

        if not flow.selected_folder:
            if connection[0]:
                st = connection[0].get('status')
                if st == 'no_camera':
                    status.set("No camera detected. Please connect your α6700 via USB.")
                    return
                if st in ('device_model_unverified', 'unsupported_service'):
                    status.set("Camera is in PC Remote mode (096F). Switch to Mass Storage.")
                    return
                if st == 'driver_required':
                    status.set("WinUSB driver required. Please install driver first via Advanced tab.")
                    return
            quick_state['auto'] = True
            quick_state['want_shortcut'] = want_shortcut
            quick_state['want_label'] = want_label
            quick_state['want_general'] = want_general
            status.set("Reading current camera App state to verify the exact preimage...")
            start(["--inspect-general-transfer"] if want_general else ["--inspect-playback-extras"])
            return

        proceed_with_unlock(want_shortcut, want_label, want_general)

    quick_unlock_button = ttk.Button(quick_frame, text="🚀 Unlock Selected Functions",
                                     command=on_quick_unlock, style='Workbench.Primary.TButton')
    quick_unlock_button.pack(anchor="w", pady=(4, 2))

    # 3. Camera Conditions Card
    cond_frame = ttk.LabelFrame(frame, text="Safety & Camera Conditions", padding=10,
                                style='Workbench.TLabelframe')
    cond_frame.pack(fill="x", pady=(0, 10))
    check = ttk.Checkbutton(cond_frame, text="I confirm the camera conditions below.",
                            variable=checked, command=camera_conditions_changed,
                            style="Workbench.TCheckbutton")
    check.pack(anchor="w")
    view.label(cond_frame, text=(
        "1. Normal screen and English work; the camera is connected in Mass Storage mode.\n"
        "2. Other camera tools and apps are closed.\n"
        "3. Keep USB connected during operations. Access lamp alone is not an indicator."
    ), kind='muted').pack(anchor='w', fill='x', pady=(4, 0))

    # 4. Advanced / Manual Operations Card
    apply_frame = ttk.LabelFrame(frame, text="Advanced / Manual Operations", padding=10,
                                 style='Workbench.TLabelframe')
    apply_frame.pack(fill="x", pady=6)
    read_button = ttk.Button(apply_frame, text="Read playback state — experimental service inspection",
                             command=lambda: start(["--inspect-playback-extras"]), style='Workbench.TButton')
    read_button.pack(anchor="w", pady=(0, 6))
    read_general_button = ttk.Button(
        apply_frame, text="Read FTP Transfer row — two-window App-only inspection",
        command=lambda: start(["--inspect-general-transfer"]), style='Workbench.TButton')
    read_general_button.pack(anchor="w", pady=(0, 6))
    view.label(apply_frame, text=(
        "Choose the seven-window read for the current-image shortcut or label; choose the two-window App-only read for FTP Transfer.\n"
        "After following the camera report, reconnect and check the camera-conditions box to continue here."
    )).pack(anchor="w", fill="x")
    picker = ttk.Frame(apply_frame, style='Workbench.TFrame')
    picker.pack(fill="x", pady=6)
    ttk.Entry(picker, textvariable=folder, state="readonly", style='Workbench.TEntry').pack(side="left", fill="x", expand=True)

    def browse():
        if busy[0] or not flow.can_service:
            return
        chosen = filedialog.askdirectory(parent=root, title="Select a saved playback inspection RECORD_DIR", mustexist=True)
        if chosen:
            try:
                flow.adopt(chosen)
            except (ValueError, OSError) as exc:
                status.set(str(exc))
                output.insert('end', str(exc) + '\n')
            else:
                status.set(flow.message)
            folder.set(flow.selected_folder)
            refresh_badges_from_folder(flow.selected_folder)
            update_controls()

    browse_button = ttk.Button(picker, text="Choose saved inspection folder…", command=browse, style='Workbench.TButton')
    browse_button.pack(side="left", padx=(8, 0))

    def apply_extra(action):
        if busy[0] or not flow.can_service:
            return
        if not checked.get():
            status.set("Confirm the camera conditions before selecting an operation.")
            return
        if not folder.get():
            status.set("Choose the saved inspection RECORD_DIR before reviewing a change.")
            return
        try:
            flow.adopt(folder.get(), 'inspect_general' if action == 'general_transfer' else 'inspect')
        except (ValueError, OSError) as exc:
            folder.set(flow.selected_folder)
            status.set(str(exc))
            output.insert('end', str(exc) + '\n')
            update_controls()
            return
        argv = confirmed_action_arguments(action, folder.get(),
            lambda title, review: messagebox.askyesno(title, review, parent=root,
                                                      icon="warning", default="no"))
        if argv is not None:
            start(argv)

    shortcut_button = ttk.Button(apply_frame, text=SHORTCUT_BUTTON_TITLE,
                                 command=lambda: apply_extra("shortcut"), style='Workbench.TButton')
    shortcut_button.pack(anchor="w", pady=(4, 0))
    label_button = ttk.Button(apply_frame, text="Correct transferred-image label…",
                              command=lambda: apply_extra("label"), style='Workbench.TButton')
    label_button.pack(anchor="w", pady=(4, 0))
    general_button = ttk.Button(apply_frame, text="Enable FTP Transfer for C1/C2…",
                                command=lambda: apply_extra("general_transfer"), style='Workbench.TButton')
    general_button.pack(anchor="w", pady=(4, 0))
    output = view.technical_output
    output.configure(state='normal')
    def close():
        if busy[0]:
            status.set("An operation is running. Wait for its result before closing.")
        else:
            root.destroy()
    root.protocol("WM_DELETE_WINDOW", close)
    view.set_page("features")
    update_controls()
    if not is_fake_root(root):
        root.after(500, schedule_connection_poll)
    if gui_check:
        root.update_idletasks()
        root.destroy()
        print("GUI_WIDGET_SELF_CHECK_PASSED; CAMERA_COMMANDS=0")
        return 0
    consume()
    root.mainloop()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
