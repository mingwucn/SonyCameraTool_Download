"""Explicit ordinary-file candidate preparation; never imports a device engine."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import tempfile
import uuid

from tools import playback_filter_patch as patch

ROOT = Path(__file__).resolve().parents[1]


def load_payload():
    # Kept lazy: a GUI import or an unrelated camera action does not read assets.
    from tools import playback_filter_payload as profile
    payload_path = ROOT / profile.ASSET_DIRECTORY / 'playback_filter_payload.bin'
    manifest_path = ROOT / profile.ASSET_DIRECTORY / 'payload_manifest.json'
    payload, encoded = payload_path.read_bytes(), manifest_path.read_bytes()
    if (hashlib.sha256(payload).hexdigest() != profile.PAYLOAD_SHA256 or
            hashlib.sha256(encoded).hexdigest() != profile.MANIFEST_SHA256):
        raise ValueError('Bundled authored filter payload identity disagrees')
    manifest = json.loads(encoded)
    if (manifest.get('device_install_allowed') is not False or
            manifest.get('payload_sha256') != profile.PAYLOAD_SHA256):
        raise ValueError('Bundled filter payload scope disagrees')
    return payload, manifest, (payload_path, manifest_path)


def payload_assets():
    return load_payload()[2]


def self_check():
    payload, manifest, _paths = load_payload()
    return dict(status='OFFLINE_FILTER_PAYLOAD_VERIFIED', camera_commands=0,
                installation_enabled=False, payload_sha256=hashlib.sha256(payload).hexdigest(),
                payload_bytes=len(payload), source_sha256=manifest['source_sha256'])


def _write(path, content):
    with path.open('xb') as stream:
        stream.write(content)
        stream.flush()
        os.fsync(stream.fileno())
    if path.read_bytes() != content:
        raise OSError('Offline candidate output readback disagrees')


def _durable_parent(value):
    if not isinstance(value, Path) or not value.is_absolute():
        raise ValueError('Select an absolute existing private output folder')
    parent = value.resolve(strict=True)
    system_temp = Path(tempfile.gettempdir()).resolve(strict=True)
    if not parent.is_dir() or parent == system_temp or system_temp in parent.parents:
        raise ValueError('Select a durable output folder outside system Temp')
    # Output includes private complete firmware; keep it outside Git checkouts.
    if any((p / '.git').exists() for p in (parent, *parent.parents)):
        raise ValueError('Select private output storage outside a Git checkout')
    return parent


def prepare(*, app_reference, output_parent):
    """Save an exact historical candidate and inverse in one new private folder.

    Known English/FTP fields are preserved using the existing exact guard. A
    byte round trip does not qualify the current camera, loader or installer.
    """
    if not isinstance(app_reference, Path) or not app_reference.is_absolute():
        raise ValueError('Select an absolute complete historical App reference')
    parent = _durable_parent(output_parent)
    app = app_reference.resolve(strict=True)
    if not app.is_file():
        raise ValueError('Select a complete ordinary App reference file')
    source = app.read_bytes()
    payload, manifest, _assets = load_payload()
    recipe = patch.prepare(source, payload, manifest)
    candidate = recipe.build_candidate(source)
    inverse = recipe.build_candidate(candidate, restore=True)
    if inverse != source:
        raise ValueError('Complete offline inverse differs from the selected original')
    stamp = datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S')
    output = parent / ('A6700PlaybackFilterOffline-' + stamp + '-' + uuid.uuid4().hex[:12])
    output.mkdir(exist_ok=False)
    result = dict(patch.summary(recipe, manifest), status='OFFLINE_CANDIDATE_PREPARED',
                  camera_commands=0, installation_enabled=False, inverse_exact=True,
                  record_dir=str(output))
    try:
        _write(output / 'candidate.app', candidate)
        _write(output / 'inverse.original.app', inverse)
        _write(output / 'plan.json', (json.dumps(recipe.preview(), indent=2) + '\n').encode())
        _write(output / 'result.json', (json.dumps(result, indent=2) + '\n').encode())
    except Exception as exc:
        # Preserve any completed output for review; never retry or delete it.
        failure = dict(status='OFFLINE_PREPARATION_STOPPED', error_type=type(exc).__name__,
                       camera_commands=0, installation_enabled=False)
        marker = output / 'failure.json'
        if not marker.exists():
            _write(marker, (json.dumps(failure, indent=2) + '\n').encode())
        raise
    return result
