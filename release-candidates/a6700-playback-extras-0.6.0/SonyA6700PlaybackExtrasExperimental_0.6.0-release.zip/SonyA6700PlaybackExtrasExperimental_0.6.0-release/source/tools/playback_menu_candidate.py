"""Pure offline counterfactual for ten playback menu permission low bytes.

No files, devices, USB, process, network or live writer API is used. The input
and output are private in-memory sector images. WBI coordinates are assumptions,
not approved physical write addresses. This models menu visibility only; the
filter backend and parameter 0x568 are not enabled or verified by this module.
"""
from dataclasses import dataclass, fields
import hashlib
import json
import struct


SECTOR_BYTES = 512
SECTOR_COUNT = 6
HEADER = struct.Struct("<4sI16s32s")
REFERENCE_HASHES = (
    "1f06a5c8b6c868eae6c217accf0f650f0d48d9aa45413a56add37761369dbb4f",
    "c50c2e0e3534c6f0fa8eba12a3e5dca7bd8c5010303de26b037b95e18d37e428",
    "57377f7a9950972c9e59359dfba1b6ea5fc8a4d10d99fd8e6cec747b220c4383",
    "c574732a90eb63d1063b73279643a6b6770ea53c6a34a277a592da6130cb0f2a",
    "d9111e872139b3c2c1688c9d1137595b9f5a27046c49733185946737b63990a2",
    "2ea908b577118e593a33f5646abe7c680b2be4fa81769768893d91ed2d72b21b",
)
PROBE_OFFSETS = (0x04BCA200, 0x04C0B400, 0x04C36A00,
                 0x02514400, 0x02586600, 0x025C1C00)
LOW_BYTE_POSITIONS = ((0x160,), (0x112,), (0x6A, 0x10A, 0x1AA),
                      (0x160,), (0x112,), (0x6A, 0x10A, 0x1AA))
PROFILE_ORDER = (3, 4, 5, 0, 1, 2)
PROFILE_SHA256 = "9dbf8a5bf5fccf7b2e5585b410bff7fb9bca739283c269b94443626fe55aa994"
MENU_IDS = ((0x1D5,), (0x1DC,), (0x7BD, 0x7BE, 0x7BF),
            (0x1D5,), (0x1DC,), (0x7BD, 0x7BE, 0x7BF))


@dataclass(frozen=True)
class Change:
    menu_id: int
    domain: str
    probe_index: int
    position: int
    coordinate: int
    before: int = 0
    after: int = 1


@dataclass(frozen=True)
class Candidate:
    """Private sector images in probe order: App three, then WBI three."""
    before: tuple
    after: tuple
    changes: tuple

    @property
    def changed_bytes(self):
        return len(self.changes)


def profile_definition():
    """Return public coordinates, hashes and masks; no device geometry approval."""
    return {"schema_version": 1, "sector_bytes": 512, "request_magic": "A67X",
            "profile_order": list(PROFILE_ORDER),
            "entries": [
                {"domain": "APP" if probe_index < 3 else "WBI",
                 "coordinate_type": "APP_FILE_OFFSET" if probe_index < 3 else "ASSUMED_WBI_DEVICE_FILE_OFFSET",
                 "offset": PROBE_OFFSETS[probe_index], "probe_index": probe_index,
                 "profile_index": profile_index,
                 "preimage_sha256": REFERENCE_HASHES[probe_index],
                 "changes": [{"position": pos, "before": 0, "after": 1}
                             for pos in LOW_BYTE_POSITIONS[probe_index]]}
                for profile_index, probe_index in enumerate(PROFILE_ORDER)]}


def profile_json():
    """Canonical public profile JSON bytes, with no newline or file output."""
    return json.dumps(profile_definition(), sort_keys=True, separators=(",", ":")).encode()


def profile_digest():
    if (type(REFERENCE_HASHES) is not tuple or len(REFERENCE_HASHES) != 6 or
            hashlib.sha256(profile_json()).hexdigest() != PROFILE_SHA256):
        raise ValueError("Counterfactual playback profile changed")
    return bytes.fromhex(PROFILE_SHA256)


def _sector_shape(sectors):
    if (type(sectors) is not tuple or len(sectors) != SECTOR_COUNT or
            any(type(sector) is not bytes or len(sector) != SECTOR_BYTES for sector in sectors)):
        raise ValueError("Exactly six immutable complete probe-order sectors are required")


def build_candidate(sectors):
    """Require all six full stock hashes; model exactly five halfwords per domain."""
    profile_digest()
    _sector_shape(sectors)
    if tuple(hashlib.sha256(sector).hexdigest() for sector in sectors) != REFERENCE_HASHES:
        raise ValueError("A complete probe sector differs from its pinned stock preimage")
    after, changes = [], []
    for i, sector in enumerate(sectors):
        changed = bytearray(sector)
        for menu_id, pos in zip(MENU_IDS[i], LOW_BYTE_POSITIONS[i]):
            if sector[pos:pos + 2] != bytes(2):
                raise ValueError("A required little-endian permission halfword is not 0000")
            changed[pos] = 1
            changes.append(Change(menu_id, "APP" if i < 3 else "WBI", i,
                                  pos, PROBE_OFFSETS[i] + pos))
        after.append(bytes(changed))
    result = Candidate(sectors, tuple(after), tuple(changes))
    differences = [(i, pos) for i in range(6) for pos in range(512)
                   if result.before[i][pos] != result.after[i][pos]]
    if differences != [(change.probe_index, change.position) for change in result.changes] or len(differences) != 10:
        raise ValueError("Candidate does not have exactly the fixed ten-byte footprint")
    return result


def validate_candidate(candidate):
    """Rebuild from pinned preimages before trusting any caller-supplied plan."""
    if type(candidate) is not Candidate or type(candidate.changes) is not tuple:
        raise ValueError("An immutable counterfactual candidate is required")
    _sector_shape(candidate.after)
    expected = build_candidate(candidate.before)
    if candidate.after != expected.after or len(candidate.changes) != 10:
        raise ValueError("Candidate output differs from the fixed ten-byte mask")
    for actual, wanted in zip(candidate.changes, expected.changes):
        if type(actual) is not Change or any(
                type(getattr(actual, field.name)) is not type(getattr(wanted, field.name)) or
                getattr(actual, field.name) != getattr(wanted, field.name)
                for field in fields(Change)):
            raise ValueError("Candidate change metadata differs from the fixed mask")


def summary(candidate):
    """Return sanitized counterfactual scope; never sector bytes or camera claims."""
    validate_candidate(candidate)
    return {"evidence_class": "offline-counterfactual", "experimental": True,
            "profile_sha256": PROFILE_SHA256, "scope": "MENU_VISIBILITY_ONLY",
            "probe_order": "APP_THREE_THEN_WBI_THREE", "core_profile_order": list(PROFILE_ORDER),
            "sector_count": 6, "bytes_in_sectors": 3072, "changed_bytes": 10,
            "unchanged_bytes": 3062, "permissions_per_domain": {"APP": 5, "WBI": 5},
            "permission_halfword_transition": "0000_TO_0001_LITTLE_ENDIAN",
            "permission_high_bytes_unchanged": True,
            "filter_parameter_0x568_modified": False, "backend_functionality": "UNVERIFIED",
            "english_network_and_historical_0x817_changes": 0,
            "physical_wbi_write_mapping": "UNVERIFIED", "failed_start_recovery": "UNVERIFIED",
            "camera_operations": 0, "live_writer": False,
            "limitations": [
                "Only ten menu-permission low bytes are modeled; menu visibility and filter operation remain unverified.",
                "Numeric coordinate and stock-byte matches do not approve physical writes or establish WBI integrity handling.",
                "The supplied nonce is checked only for format and nonzero value; freshness and pre-staging persistence belong to a separate operation.",
                "This module performs no installation, rollback, backup, camera authentication or recovery."]}


def request_bytes(candidate, nonce):
    """Serialize an in-memory A67X counterfactual for the existing bounded core.

    The core profile indices are 0..5 in increasing coordinate order: WBI three,
    then App three. This function neither dispatches nor persists the request.
    """
    validate_candidate(candidate)
    if type(nonce) is not bytes or len(nonce) != 16 or nonce == bytes(16):
        raise ValueError("A nonzero immutable 16-byte nonce is required")
    pairs = b"".join(candidate.before[i] + candidate.after[i] for i in PROFILE_ORDER)
    return HEADER.pack(b"A67X", 1, nonce, profile_digest()) + pairs
