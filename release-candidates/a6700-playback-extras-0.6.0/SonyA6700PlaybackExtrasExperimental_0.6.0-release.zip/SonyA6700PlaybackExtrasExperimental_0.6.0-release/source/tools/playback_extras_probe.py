"""One explicitly selected read of seven fixed playback and shortcut windows.

Offline protocol functions do not import a camera backend. The live entry point
reuses the original customizer's guarded service session. WBI coordinates are
read hypotheses; this module has no firmware-writing action.
"""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import re
import secrets
import stat
import struct


PROFILE = {"schema_version": 1, "sector_bytes": 512,
           "paths": ["/usr/lib/appFw.so", "/dev/nflasha5"],
           "entries": [[0, 0x04BCA200], [0, 0x04C0B400], [0, 0x04C36A00],
                       [1, 0x02514400], [1, 0x02586600], [1, 0x025C1C00],
                       [0, 0x03788E00]]}
PROFILE_SHA256 = "23ea10a96a7a7a8e479c1e2ccfebd7c9d8ff64e012d8d2c126c2adcc1190fc72"
REQUEST = struct.Struct("<4sI16s32s")
RESPONSE = struct.Struct("<4sI16sIIII")
COUNT = 7
SAVED_FILE_LIMITS = {"intent.json": 32768, "result.json": 32768,
                     "capture.json": 32768, "response.bin": 3624,
                     "transport-UNVERIFIED.bin": 3628}
# Live use remains disabled until the independently reviewed native build is pinned.
PAYLOAD_SHA256 = 'db6dfc0bfea18a5824c70df9f16f172bc932cfe7adee4836d54c859ed07efe71'
PAYLOAD_BYTES = 17720
PAYLOAD_PATH = (Path(__file__).resolve().parents[1] / ".data" /
                "playback-extras-probe-native-20261104" / "playback_extras_probe.elf")
FIELDS = (("Playback Filter Condition", 0, 0x160, 3, 0x160),
          ("FTP Transfer Status", 1, 0x112, 4, 0x112),
          ("Non-transferred", 2, 0x6A, 5, 0x6A),
          ("Failed Transfer Img.", 2, 0x10A, 5, 0x10A),
          ("Transferred status resource", 2, 0x1AA, 5, 0x1AA))


class ProbeFailure(ValueError):
    def __init__(self, status, count, failed):
        labels = {1: "Target open failed", 2: "Target read was short or failed",
                  3: "Target close failed", 4: "App type or size check failed"}
        self.details = {"status": status, "reason": labels[status],
                        "completed_reads": count, "failed_read_index": failed,
                        "path": PROFILE["paths"][PROFILE["entries"][failed][0]],
                        "offset": PROFILE["entries"][failed][1]}
        super().__init__(labels[status])


class CaptureRecordError(ValueError):
    """A selected host record cannot be adopted; no camera action is implied.

    Codes and fixed required basenames can be shown in the UI. Messages omit
    selected paths and raw filesystem/JSON exception text. A false
    service_attempted value is supplied only for a matching preflight-refusal
    report; it is metadata from that record, not a new camera observation.
    """
    def __init__(self, code, message, *, missing_files=(), service_attempted=None):
        self.code = code
        self.message = message
        self.missing_files = tuple(missing_files)
        self.service_attempted = service_attempted
        super().__init__(message)


def _profile_digest():
    raw = json.dumps(PROFILE, sort_keys=True, separators=(",", ":")).encode()
    if hashlib.sha256(raw).hexdigest() != PROFILE_SHA256:
        raise ValueError("Fixed playback extras read profile changed")
    return bytes.fromhex(PROFILE_SHA256)


def request(nonce):
    if type(nonce) is not bytes or len(nonce) != 16 or nonce == b"\0" * 16:
        raise ValueError("A fresh 16-byte nonce is required")
    return REQUEST.pack(b"A6XQ", 1, nonce, _profile_digest())


def parse(data, nonce):
    request(nonce)
    if type(data) is bytes and len(data) == RESPONSE.size:
        magic, version, echoed, status, count, failed, flags = RESPONSE.unpack(data)
        if (magic == b"A6XR" and version == 1 and echoed == nonce and flags == 0 and
                status in (1, 2, 3, 4) and 0 <= count <= COUNT and 0 <= failed < COUNT):
            raise ProbeFailure(status, count, failed)
    if type(data) is not bytes or len(data) != RESPONSE.size + COUNT * 512:
        raise ValueError("Incomplete or oversized playback response")
    if RESPONSE.unpack_from(data) != (b"A6XR", 1, nonce, 0, COUNT, 0xFFFFFFFF, 0):
        raise ValueError("Stale, failed or unexpected playback response")
    return tuple(data[RESPONSE.size + i * 512:RESPONSE.size + (i + 1) * 512]
                 for i in range(COUNT))


def analyze(sectors):
    if (type(sectors) is not tuple or len(sectors) != COUNT or
            any(type(b) is not bytes or len(b) != 512 for b in sectors)):
        raise ValueError("Exactly seven complete fixed read sectors are required")
    from tools import playback_probe as original
    result = original.analyze(sectors[:6])
    key = struct.unpack_from("<I", sectors[6], 0x18)[0]
    group = sectors[6][0x46:0x54] if key == 0x4C7 else None
    result.update({
        "sector_sha256": [hashlib.sha256(b).hexdigest() for b in sectors],
        "read_windows": COUNT,
        "third_title_rids": {
            "app": f"0x{struct.unpack_from('<I', sectors[2], 0x18C)[0]:08x}",
            "wbi_at_assumed_mapping": f"0x{struct.unpack_from('<I', sectors[5], 0x18C)[0]:08x}"},
        "shortcut_assignment": {
            "function_label": "FTP Trans. (This Img.)",
            "function_title_rid": "0x021c6868",
            "function_child_record_app_file_offset": "0x04bb1598",
            "event_on": "0x02220008", "event_off": "0x02220009",
            "roster_key_expected": "0x4c7", "roster_key_observed": hex(key),
            "row_key_matches": key == 0x4C7,
            "roster_row_app_file_offset": "0x03788e18", "roster_row_bytes": 0x90,
            "model_index": 3, "group_bytes": 14,
            "model_group_app_file_offset": "0x03788e46",
            "assignment_flags_by_menu_type": None if group is None else [
                {"menu_type": 8 + i, "app_assignment_byte": value,
                 "app_file_offset": hex(0x03788E46 + i)} for i, value in enumerate(group)],
            "playback_button_menu_types": {
                "20": {"label": "Fn/smartphone", "app_file_offset": "0x03788e52"},
                "21": {"label": "C1/C2/MOVIE", "app_file_offset": "0x03788e53"}},
            "wbi_counterpart": "NOT_QUALIFIED_NOT_READ",
            "runtime_or_cached_row": "UNOBSERVED",
            "assignment_list_visibility": "OWNER_OBSERVATION_REQUIRED",
            "changed_by_this_read": False},
    })
    return result


def _payload_pin_ready():
    if (type(PAYLOAD_SHA256) is not str or
            type(PAYLOAD_BYTES) is not int or PAYLOAD_BYTES <= 0):
        raise RuntimeError("Playback extras native build pin is pending; live use is disabled")
    if re.fullmatch(r"[0-9a-f]{64}", PAYLOAD_SHA256) is None:
        raise RuntimeError("Invalid playback extras native build pin")


def _intent():
    return {"action": "ONE_PLAYBACK_EXTRAS_READ", "profile": PROFILE,
            "profile_sha256": PROFILE_SHA256, "payload_sha256": PAYLOAD_SHA256,
            "bytes": COUNT * 512, "helper_and_temporary_camera_files": True,
            "persistent_firmware_write": False, "automatic_retry_or_driver_change": False,
            "wbi_mapping": "ORIGINAL_THREE_ASSUMED_READ_COORDINATES",
            "shortcut_wbi_counterpart": "NOT_QUALIFIED_NOT_READ", "full_backup": False,
            "body_identity": "OWNER_REPORT_NOT_AUTHENTICATED"}


def _canonical(value):
    # Unlike dict equality, canonical JSON distinguishes bool from int.
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False)


def _saved_json(raw):
    def pairs(items):
        result = {}
        for key, value in items:
            if key in result:
                raise ValueError("Duplicate saved-record JSON key")
            result[key] = value
        return result
    def bad_constant(_):
        raise ValueError("Non-finite saved-record JSON number")
    try:
        value = json.loads(raw.decode("utf-8"), object_pairs_hook=pairs,
                           parse_constant=bad_constant)
    except (UnicodeError, RecursionError) as error:
        raise ValueError("Invalid saved-record JSON") from error
    if type(value) is not dict:
        raise ValueError("Saved-record JSON object required")
    return value


def validate_saved_record(files):
    """Validate five bounded capture files without opening a camera backend.

    A persisted observation may coexist with an uncertain service STOP. That
    uncertainty is retained; it cannot be interpreted as a successful exit.
    """
    _profile_digest()
    _payload_pin_ready()
    if type(files) is not dict or set(files) != set(SAVED_FILE_LIMITS):
        raise ValueError("Exactly five playback extras capture files are required")
    for name, limit in SAVED_FILE_LIMITS.items():
        if type(files[name]) is not bytes or not 0 < len(files[name]) <= limit:
            raise ValueError("Invalid or oversized playback extras capture file")
    intent = _saved_json(files["intent.json"])
    capture = _saved_json(files["capture.json"])
    report = _saved_json(files["result.json"])
    if _canonical(intent) != _canonical(_intent()):
        raise ValueError("Saved playback extras intent/profile/payload mismatch")
    if set(capture) != {"profile_sha256", "payload_sha256", "nonce_hex",
                        "response_sha256", "analysis"}:
        raise ValueError("Unexpected saved playback extras capture metadata")
    if (capture["profile_sha256"] != PROFILE_SHA256 or
            capture["payload_sha256"] != PAYLOAD_SHA256 or
            type(capture["nonce_hex"]) is not str or
            re.fullmatch(r"[0-9a-f]{32}", capture["nonce_hex"]) is None):
        raise ValueError("Saved playback extras capture pin/nonce mismatch")
    nonce = bytes.fromhex(capture["nonce_hex"])
    response = files["response.bin"]
    if (capture["response_sha256"] != hashlib.sha256(response).hexdigest() or
            files["transport-UNVERIFIED.bin"] != bytes(4) + response):
        raise ValueError("Saved playback extras response/transport mismatch")
    sectors = parse(response, nonce)
    analysis = analyze(sectors)
    if _canonical(capture["analysis"]) != _canonical(analysis):
        raise ValueError("Saved playback extras analysis mismatch")
    required = {"status", "probe_state", "capture", "service_attempted", "service_exit",
                "stage", "stop_error", "camera_state_uncertain", "firmware_written",
                "normal_camera_and_english", "automatic_retry"}
    if (not required <= set(report) or
            set(report) - required - {"error_chain"} or
            report["status"] != "PERSISTED" or report["probe_state"] != "PERSISTED" or
            report["service_attempted"] is not True or
            report["camera_state_uncertain"] is not True or
            report["firmware_written"] is not False or
            report["automatic_retry"] is not False or
            report["normal_camera_and_english"] != "OWNER_CHECK_REQUIRED_AFTER_SERVICE" or
            report["service_exit"] not in ("NOT_SENT", "stop-sent", "unconfirmed",
                                             "WITHHELD_AFTER_ERROR") or
            type(report["stage"]) is not str or not 0 < len(report["stage"]) <= 256 or
            (report["stop_error"] is not None and type(report["stop_error"]) is not dict) or
            ("error_chain" in report and type(report["error_chain"]) is not list) or
            _canonical(report["capture"]) != _canonical(analysis)):
        raise ValueError("Saved playback extras result/status metadata mismatch")
    return sectors


def _ordinary(info, directory=False):
    return ((stat.S_ISDIR(info.st_mode) if directory else stat.S_ISREG(info.st_mode)) and
            not stat.S_ISLNK(info.st_mode) and
            not getattr(info, "st_file_attributes", 0) & 0x400)


def _saved_record(folder):
    """Read and validate one local five-file snapshot without a backend."""
    try:
        selected = Path(os.path.abspath(os.fspath(folder)))
        if str(selected).startswith(("\\\\", "//")):
            raise ValueError("A local ordinary capture directory is required")
        for parent in (*reversed(selected.parents), selected):
            try:
                info = parent.lstat()
            except FileNotFoundError:
                raise CaptureRecordError("MISSING_DIRECTORY",
                    "The selected inspection folder no longer exists. Choose a completed "
                    "seven-window inspection folder.") from None
            if not _ordinary(info, directory=True):
                raise ValueError("Capture directory traverses a link or reparse point")
        files, missing = {}, []
        for name, limit in SAVED_FILE_LIMITS.items():
            path = selected / name
            try:
                info = path.lstat()
            except FileNotFoundError:
                missing.append(name)
                continue
            if not _ordinary(info) or info.st_nlink != 1 or not 0 < info.st_size <= limit:
                raise ValueError("Capture files must be bounded ordinary private files")
            with path.open("rb") as stream:
                opened = os.fstat(stream.fileno())
                if not _ordinary(opened) or _file_identity(info) != _file_identity(opened):
                    raise ValueError("Capture file changed during opening")
                files[name] = stream.read(limit + 1)
                after = os.fstat(stream.fileno())
            if (_file_identity(opened) != _file_identity(after) or
                    _file_identity(after) != _file_identity(path.lstat()) or
                    len(files[name]) != after.st_size):
                raise ValueError("Capture file changed during reading")
        if missing:
            # This is only a diagnostic classification; incomplete records are
            # never passed to the validator or converted into usable captures.
            preflight = False
            if "result.json" in files:
                try:
                    report = _saved_json(files["result.json"])
                    expected = {"status": "STOPPED", "probe_state": "READY",
                                "capture": None, "service_attempted": False,
                                "service_exit": "NOT_SENT", "stage": "preflight",
                                "camera_state_uncertain": False, "firmware_written": False,
                                "automatic_retry": False, "stop_error": None}
                    preflight = (expected.keys() <= report.keys() and all(
                        _canonical(report[key]) == _canonical(value)
                        for key, value in expected.items()))
                except (ValueError, TypeError):
                    pass
            if preflight:
                raise CaptureRecordError("PREFLIGHT_STOPPED",
                    "The selected record reports that inspection stopped at preflight before "
                    "camera service started. It has no complete capture. Check connection, "
                    "then select Read playback state once when ready.",
                    missing_files=missing, service_attempted=False)
            raise CaptureRecordError("INCOMPLETE_CAPTURE",
                "The selected inspection is incomplete. Missing required files: " +
                ", ".join(missing) + ". Choose a completed seven-window inspection folder.",
                missing_files=missing)
        return validate_saved_record(files), _saved_json(files["result.json"])
    except CaptureRecordError:
        raise
    except (ValueError, TypeError):
        raise CaptureRecordError("INVALID_CAPTURE",
            "The selected inspection is invalid or inconsistent. Preserve its files and "
            "choose a completed seven-window inspection folder.") from None
    except OSError:
        raise CaptureRecordError("UNREADABLE_CAPTURE",
            "The selected inspection could not be read completely. Preserve its files and "
            "choose an accessible completed inspection folder.") from None


def saved_sectors(folder):
    """Return sectors from a strict local capture, or a safe CaptureRecordError."""
    return _saved_record(folder)[0]


def saved_result(folder):
    """Return result metadata from the same five-file snapshot just validated.

    This avoids a second unverified result.json read when the GUI compares a
    worker's stdout result to its complete saved record. No file is changed.
    """
    return _saved_record(folder)[1]


def _file_identity(info):
    return (info.st_dev, info.st_ino, info.st_mode, info.st_nlink,
            info.st_size, info.st_mtime_ns, info.st_ctime_ns,
            getattr(info, "st_file_attributes", 0))


def load_payload():
    _profile_digest()
    _payload_pin_ready()
    data = PAYLOAD_PATH.read_bytes()
    if len(data) != PAYLOAD_BYTES or hashlib.sha256(data).hexdigest() != PAYLOAD_SHA256:
        raise RuntimeError("Playback extras reader does not match its reviewed build")
    return data


class OneRead:
    """Never resend after staging starts, including after a missing response."""

    def __init__(self, payload, nonce, folder, persist, phase):
        _payload_pin_ready()
        if (type(payload) is not bytes or len(payload) != PAYLOAD_BYTES or
                hashlib.sha256(payload).hexdigest() != PAYLOAD_SHA256):
            raise ValueError("Unpinned playback extras reader")
        self.payload, self.nonce = payload, nonce
        self.config = request(nonce)
        self.folder, self.persist, self.phase = Path(folder), persist, phase
        self.state = "READY"
        self.analysis = None

    def execute(self, session):
        if self.state != "READY":
            raise RuntimeError("This playback read has already been attempted")
        self.state = "ATTEMPTED"
        self.phase("playback extras request staging")
        session._file(0x4010, 0, self.config)
        self.phase("playback extras helper upload; constructor may execute")
        session._file(0x4007, 2, self.payload)
        self.phase("playback extras result retrieval")
        body = session._command(0x4008, b"\0\0\0")
        if type(body) is not bytes or len(body) > 4 + RESPONSE.size + COUNT * 512:
            raise RuntimeError("Invalid or oversized playback transport response")
        self.persist(self.folder / "transport-UNVERIFIED.bin", body)
        if len(body) < 4 or body[:4] != b"\0" * 4:
            raise RuntimeError("Playback helper transport did not complete")
        sectors = parse(body[4:], self.nonce)
        self.persist(self.folder / "response.bin", body[4:])
        self.analysis = analyze(sectors)
        self.persist(self.folder / "capture.json", (json.dumps({
            "profile_sha256": PROFILE_SHA256, "payload_sha256": PAYLOAD_SHA256,
            "nonce_hex": self.nonce.hex(), "response_sha256": hashlib.sha256(body[4:]).hexdigest(),
            "analysis": self.analysis}, indent=2, sort_keys=True) + "\n").encode())
        self.state = "PERSISTED"
        return self.analysis


def main(argv=None):
    import sys
    argv = sys.argv[1:] if argv is None else argv
    if argv == ["--self-check"]:
        load_payload()
        print(json.dumps({"status": "OFFLINE_SELF_CHECK_PASSED", "profile_sha256": PROFILE_SHA256,
                          "payload_sha256": PAYLOAD_SHA256, "camera_commands": 0}))
        return 0
    if argv == ["--transport-self-check"]:
        load_payload()
        from tools import legacy_sparse_session as existing
        existing.sparse.load_reference()
        existing.guard.guard_test()  # Synthetic only; no USB handles or service session.
        print("PINNED_TRANSPORT_IMPORT_AND_GUARD_CHECK_PASSED; CAMERA_COMMANDS=0")
        return 0
    if argv != ["--inspect-playback-extras"]:
        raise SystemExit("Select --inspect-playback-extras explicitly; no installation action exists")
    payload = load_payload()  # Validate local inputs before importing any device backend.
    from tools.service_operation_lock import service_operation_lock
    from tools import legacy_sparse_session as existing
    guard, sparse = existing.guard, existing.sparse
    folder = existing._create_record_directory()
    print("RECORD_DIR:", folder, flush=True)
    existing._save_json(folder, "intent.json", _intent())
    def phase(value):
        guard.state["phase"] = value
        print("PROGRESS:", value, flush=True)
    action = OneRead(payload, secrets.token_bytes(16), folder, sparse._write_verified, phase)
    error, attempted = None, False
    try:
        with service_operation_lock():
            phase("preflight")
            existing._preflight()
            guard.install_guards()
            attempted = True
            with guard.research.ServiceSession(progress=lambda _: None) as session:
                action.execute(session)
    except BaseException as exc:
        error = exc
    status = "STOPPED" if error is not None and action.state != "PERSISTED" else action.state
    report = {"status": status, "probe_state": action.state, "capture": action.analysis,
              "service_attempted": attempted, "service_exit": guard.state["exit_status"],
              "stage": guard.state["phase"], "stop_error": guard.state["stop_error"],
              "camera_state_uncertain": attempted, "firmware_written": False,
              "normal_camera_and_english": "OWNER_CHECK_REQUIRED_AFTER_SERVICE",
              "automatic_retry": False}
    if error is not None:
        report["error_chain"] = guard.safe_error_chain(error)
        if isinstance(error, ProbeFailure):
            report["native_failure"] = error.details
        if not attempted and str(error) in (
                "Expected exactly one healthy Sony storage-mode device",
                "Expected pre-existing storage WinUSB binding"):
            report["preflight_error"] = str(error)
    existing._save_json(folder, "result.json", report)
    print("RESULT:", json.dumps(report), flush=True)
    if action.state == "PERSISTED":
        print("Read saved. No menu change was installed. Service exit must be checked separately.", flush=True)
    if attempted:
        print("When the access lamp is off, disconnect USB and verify the normal screen and English. "
              "Preserve the report. Do not automatically repeat this read.", flush=True)
    return 0 if error is None and action.state == "PERSISTED" else 2


if __name__ == "__main__":
    raise SystemExit(main())
