"""Offline-only parser for two App windows covering both playback FTP roster rows.

This module accepts already-held bytes or an ordinary complete host App file.
It has no camera session, transport, USB, service, native-helper, WBI, or write
path. Its profile is independent from the legacy seven-window reader.
"""
from __future__ import annotations

import hashlib
import json
import struct


APP_SIZE = 89_027_992
APP_REFERENCE_SHA256 = "e65fd595052be5d0e98ce8000dfcb94f90a2f8309de70ef140375052009b0ef3"
WINDOW_BYTES = 512
PROFILE = {
    "schema_version": 1,
    "profile_id": "ilce-6700-playback-general-transfer-app-pair-v1",
    "action": "general_transfer",
    "domain": "APP_FILE_OFFSET",
    "reference_app": {"size": APP_SIZE, "sha256": APP_REFERENCE_SHA256},
    "window_bytes": WINDOW_BYTES,
    "windows": [
        {"offset": 0x03788E00, "length": WINDOW_BYTES,
         "reference_sha256": "50c53b2668fe69f8066726ff9987fef721ecdc6681496962e5e462fd69189a60",
         "record_menu_id": 0x4C7, "record_relative_offset": 0x18,
         "type20_relative_offset": 0x52, "type21_relative_offset": 0x53,
         "legacy_current_image_pairs": ["0000", "0101"]},
        {"offset": 0x03788C00, "length": WINDOW_BYTES,
         "reference_sha256": "155b81577b84be7d0cca0db2c20a6dd0aabec7894ea1c8d50c72135b52ae3900",
         "record_menu_id": 0x4A8, "record_relative_offset": 0x188,
         "type20_relative_offset": 0x1C2, "type21_relative_offset": 0x1C3,
         "type20_expected": 0, "type21_allowed": [0, 1]},
    ],
}
# This digest pins only this two-window, App-only reader profile. It does not
# alter or alias the independent legacy seven-window profile digest.
PROFILE_SHA256 = "a44c6c38062d67141d2b416cfe8234b15f8acb3e67e797c4f868f3235c11415d"
MAX_PROFILE_BYTES = 8192


class ReaderProfileError(ValueError):
    """A profile or already-held two-window input does not match its pins."""


def _canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"),
                      ensure_ascii=True, allow_nan=False)


def profile_bytes():
    raw = _canonical(PROFILE).encode("ascii")
    if hashlib.sha256(raw).hexdigest() != PROFILE_SHA256:
        raise ReaderProfileError("The fixed two-window reader profile changed")
    return raw


def profile_digest():
    return hashlib.sha256(profile_bytes()).digest()


def parse_profile(raw):
    """Parse only the exact pinned profile, rejecting duplicate or loose JSON."""
    if type(raw) is not bytes or not 0 < len(raw) <= MAX_PROFILE_BYTES:
        raise ReaderProfileError("Invalid reader profile size")

    def pairs(items):
        result = {}
        for key, value in items:
            if key in result:
                raise ReaderProfileError("Duplicate reader profile key")
            result[key] = value
        return result

    def bad_constant(_value):
        raise ReaderProfileError("Invalid non-finite profile value")

    try:
        parsed = json.loads(raw.decode("ascii"), object_pairs_hook=pairs,
                            parse_constant=bad_constant)
    except (UnicodeError, json.JSONDecodeError, RecursionError) as exc:
        raise ReaderProfileError("Invalid reader profile JSON") from exc
    if type(parsed) is not dict or _canonical(parsed) != _canonical(PROFILE):
        raise ReaderProfileError("Reader profile differs from the pinned two-window profile")
    if hashlib.sha256(_canonical(parsed).encode("ascii")).hexdigest() != PROFILE_SHA256:
        raise ReaderProfileError("Reader profile digest mismatch")
    return parsed


def parse_windows(windows, profile=None):
    """Validate exactly two already-held App windows and report their key states.

    The 0x4a8 type-21 byte may be stock or enabled. The 0x4c7 legacy shortcut
    pair may be exactly 0000 or 0101. All other bytes must match the pinned
    historical window content after these exact fields are normalized.
    """
    selected_profile = parse_profile(profile_bytes() if profile is None else profile)
    specs = selected_profile["windows"]
    expected_offsets = tuple(spec["offset"] for spec in specs)
    if (type(windows) is not dict or any(type(offset) is not int for offset in windows) or
            set(windows) != set(expected_offsets)):
        raise ReaderProfileError("Exactly the two-window App profile is required")

    summaries = []
    normalized = {}
    for spec in specs:
        offset = spec["offset"]
        data = windows[offset]
        if type(data) is not bytes or len(data) != spec["length"]:
            raise ReaderProfileError("App window must be exactly 512 immutable bytes")
        if struct.unpack_from("<I", data, spec["record_relative_offset"])[0] != spec["record_menu_id"]:
            raise ReaderProfileError("Playback function roster row key mismatch")
        canonical = bytearray(data)
        if spec["record_menu_id"] == 0x4A8:
            type20 = data[spec["type20_relative_offset"]]
            type21 = data[spec["type21_relative_offset"]]
            if type20 != spec["type20_expected"] or type21 not in spec["type21_allowed"]:
                raise ReaderProfileError("General-transfer C1/C2 roster state is unknown")
            canonical[spec["type21_relative_offset"]] = 0
            summaries.append({"action": "FTP Transfer", "menu_id": "0x4a8",
                              "type20": type20, "type21": type21,
                              "type21_app_file_offset": "0x03788dc3"})
        elif spec["record_menu_id"] == 0x4C7:
            start, end = spec["type20_relative_offset"], spec["type21_relative_offset"] + 1
            pair = data[start:end]
            allowed = tuple(bytes.fromhex(value)
                            for value in spec["legacy_current_image_pairs"])
            if pair not in allowed:
                raise ReaderProfileError("Legacy current-image shortcut must be exactly 0000 or 0101")
            canonical[start:end] = bytes(2)
            summaries.append({"action": "FTP Trans. (This Img.)", "menu_id": "0x4c7",
                              "legacy_shortcut_pair": pair.hex(),
                              "type20": pair[0], "type21": pair[1]})
        else:
            raise ReaderProfileError("Unsupported playback roster row in the pinned profile")
        if hashlib.sha256(canonical).hexdigest() != spec["reference_sha256"]:
            raise ReaderProfileError("App window differs outside its exact known roster variants")
        normalized[offset] = bytes(canonical)

    return {
        "evidence_class": "offline-input",
        "profile_id": selected_profile["profile_id"],
        "profile_sha256": PROFILE_SHA256,
        "reference_app_sha256": selected_profile["reference_app"]["sha256"],
        "window_sha256": {f"0x{offset:08x}": hashlib.sha256(windows[offset]).hexdigest()
                          for offset in expected_offsets},
        "normalized_reference_match": True,
        "actions": summaries,
        "camera_access": False,
        "wbi_access": False,
        "write_capability": False,
    }


def extract_from_pinned_app(app):
    """Extract the pair from an exact historical host App snapshot, offline."""
    if (type(app) is not bytes or len(app) != APP_SIZE or
            hashlib.sha256(app).hexdigest() != APP_REFERENCE_SHA256):
        raise ReaderProfileError("Complete App reference size or SHA-256 mismatch")
    windows = {spec["offset"]: app[spec["offset"]:spec["offset"] + spec["length"]]
               for spec in PROFILE["windows"]}
    return parse_windows(windows)
