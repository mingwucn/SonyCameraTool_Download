"""Offline authored-payload build and exact historical-App recipe/inverse.

This CLI never enumerates or opens a camera. It retains private image outputs in
the selected durable directory and compiles only project-authored source in Temp.
The payload/manifest can be bundled separately; App outputs must remain private.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import stat
import struct
import subprocess
import sys
import tempfile
import uuid

if __name__ == '__main__':
    for parent in Path(__file__).resolve().parents:
        if (parent / 'camera_pipeline').is_dir():
            sys.path[:0] = [str(parent), str(Path(__file__).resolve().parents[1])]
            break

from tools.elf_static import ElfImage
from tools.playback_filter_patch import prepare, summary, KIND, HOOKS
from tools.playback_filter_patch_layout import CODE_VA, SOURCE_BYTES, SOURCE_SHA256

ROOT = Path(__file__).resolve().parents[1]
NATIVE = ROOT / 'apps/a6700_customizer/native'
ZIG_SHA256 = '2e44af5bbf7a72ef8cbdae370284687c95d65a19affa469d2ad0364d905b8e84'
SOURCES = ('playback_filter_query.cpp', 'playback_filter_sony.cpp', 'playback_filter_snapshot.cpp',
           'playback_filter_active.cpp', 'playback_filter_registry.c',
           'playback_filter_registry_aarch64.S', 'playback_filter_active_aarch64.S')
LINKER_SCRIPT = '''ENTRY(a6700_filter_active_hook)
SECTIONS {
 . = 0x148f0200;
 .text : { *(.text*) }
 .rodata : { *(.rodata*) }
 . = ALIGN(0x10000);
 .bss (NOLOAD) : { *(.bss*) *(COMMON) }
 /DISCARD/ : { *(.comment) *(.note*) *(.eh_frame*) }
}
a6700_app_link_base = 0;
a6700_original_resolver_continue = 0x351020c;
a6700_original_query73_continue = 0x352bdfc;
a6700_original_query75_continue = 0x35276f0;
a6700_original_sort_continue = 0x35282d4;
a6700_active_publish_continue = 0x34917a8;
a6700_active_error_continue = 0x3491a40;
a6700_active_cleanup_continue = 0x3491964;
a6700_model_guard_release = 0x3491294;
'''


def _sha(data):
    return hashlib.sha256(data).hexdigest()


def _run(command, scratch, environment, commands):
    result = subprocess.run(command, cwd=scratch, env=environment,
        capture_output=True, text=True, timeout=180)
    commands.append(dict(argv=command, exit_code=result.returncode,
                         stdout=result.stdout, stderr=result.stderr))
    if result.returncode:
        raise RuntimeError('Authored payload build failed: ' + result.stderr[-3000:])


def build(app_reference, output_dir, zig):
    """Build once into a new durable directory; never replace existing output."""
    app_reference = Path(app_reference).resolve(strict=True)
    zig = Path(zig).resolve(strict=True)
    if _sha(zig.read_bytes()) != ZIG_SHA256:
        raise ValueError('Pinned Zig0.13.0 compiler required')
    source = app_reference.read_bytes()
    if len(source) != SOURCE_BYTES or _sha(source) != SOURCE_SHA256:
        raise ValueError('Pinned complete historical stock App required; current modified images are not qualified')
    output = Path(output_dir).resolve()
    system = Path(tempfile.gettempdir()).resolve(strict=True)
    if output == system or system in output.parents:
        raise ValueError('Select a durable output directory outside system Temp')
    output.mkdir(parents=True, exist_ok=False)
    base = system / 'Codex'
    base.mkdir(exist_ok=True)
    if base.resolve(strict=True) != base or getattr(base.lstat(), 'st_file_attributes', 0) & 0x400:
        raise ValueError('Unsafe payload scratch parent')
    scratch = base / ('a6700-filter-build-' + uuid.uuid4().hex)
    scratch.mkdir()
    expected = scratch.resolve(strict=True)
    if ROOT == expected or ROOT in expected.parents:
        raise ValueError('Payload scratch must remain outside workbench')
    env = dict(os.environ, TEMP=str(scratch), TMP=str(scratch),
               ZIG_GLOBAL_CACHE_DIR=str(scratch / 'global'), ZIG_LOCAL_CACHE_DIR=str(scratch / 'local'))
    commands = []
    receipt = dict(state='BUILD_FAILED', camera_access_performed=False, device_install_allowed=False,
                   compiler_sha256=ZIG_SHA256, commands=commands, allocated_relocation_types=[])
    try:
        sources = [NATIVE / name for name in SOURCES]
        headers = [NATIVE / name for name in ('playback_filter_query.h', 'playback_filter_sony.h',
                   'playback_filter_snapshot.h', 'playback_filter_active.h', 'playback_filter_registry.h')]
        receipt['source_sha256'] = {p.name: _sha(p.read_bytes()) for p in sources + headers}
        objects = []
        for path in sources:
            obj = scratch / (path.name + '.o')
            cpp = path.suffix == '.cpp'
            command = [str(zig), 'c++' if cpp else 'cc', '-target', 'aarch64-linux-gnu',
                '-Oz', '-fPIC', '-ffreestanding', '-fno-builtin', '-fno-stack-protector',
                '-fno-unwind-tables', '-fno-asynchronous-unwind-tables', '-mno-outline-atomics',
                '-fvisibility=hidden', '-Wall', '-Wextra', '-Werror']
            if cpp:
                command += ['-std=c++11', '-fno-exceptions', '-fno-rtti', '-DA6700_PLAYBACK_FREESTANDING']
            command += ['-c', str(path), '-o', str(obj)]
            _run(command, scratch, env, commands)
            objects.append(obj)
            shutil.copy2(obj, output / obj.name)
            # Only these reviewed PC-page/low12/relative-call relocations occur
            # in the allocated source sections. An absolute pointer/GOT/TLS
            # would not be relocated by the original App's dynamic tables.
            compiled = ElfImage(obj.read_bytes())
            for section in compiled.sections:
                if section.type != 4 or not compiled.sections[section.info].flags & 2:
                    continue
                for _, info, _ in struct.iter_unpack('<QQq', compiled.section_data(section)):
                    kind = info & 0xffffffff
                    if kind not in (275, 277, 283, 299):
                        raise ValueError('Unreviewed allocated payload relocation: ' + str(kind))
                    if kind not in receipt['allocated_relocation_types']:
                        receipt['allocated_relocation_types'].append(kind)
        script = scratch / 'payload.ld'
        script.write_text(LINKER_SCRIPT, encoding='ascii')
        linked = scratch / 'playback_filter.elf'
        _run([str(zig), 'cc', '-target', 'aarch64-linux-gnu', '-nostdlib', '-static', '-no-pie',
              '-Wl,--no-undefined', '-Wl,--build-id=none', '-Wl,-T,' + str(script)]
              + [str(p) for p in objects] + ['-o', str(linked)], scratch, env, commands)
        linked_bytes = linked.read_bytes()
        (output / 'linked-review.elf').write_bytes(linked_bytes)
        elf = ElfImage(linked_bytes)
        if (elf.type, elf.machine) != (2, 183):
            raise ValueError('Expected linked AArch64 ET_EXEC payload')
        if any(s.section_index == 0 and s.name for s in elf.symbols()):
            raise ValueError('Linked payload retains undefined symbols')
        if any('AbsLongThunk' in s.name for s in elf.symbols()):
            raise ValueError('Linked payload contains an ASLR-incompatible absolute branch thunk')
        if any(s.type in (4, 9) and s.size for s in elf.sections):
            raise ValueError('Linked payload retains relocation records')
        sections = [s for s in elf.sections if s.flags & 2 and s.type != 8 and s.size]
        if not sections or any(s.flags & 1 or s.virtual_address < CODE_VA for s in sections):
            raise ValueError('Payload requires unsupported initialized writable allocation')
        end = max(s.virtual_address + s.size for s in sections)
        if end > CODE_VA + 1024 * 1024:
            raise ValueError('Linked payload exceeds the explicit one-MiB code extent limit')
        payload = bytearray((end - CODE_VA + 3) & -4)
        covered = set()
        for section in sections:
            span = range(section.virtual_address - CODE_VA, section.virtual_address - CODE_VA + section.size)
            if covered.intersection(span):
                raise ValueError('Overlapping linked payload sections')
            covered.update(span)
            payload[span.start:span.stop] = elf.section_data(section)
        payload = bytes(payload)
        bss = [s for s in elf.sections if s.flags & 2 and s.type == 8 and s.size]
        state_start = (end + 0xffff) & -0x10000
        if not bss or min(s.virtual_address for s in bss) != state_start:
            raise ValueError('Explicit owned BSS placement disagrees')
        state_bytes = max(s.virtual_address + s.size for s in bss) - state_start
        symbols = {s.name: s.value for s in elf.symbols() if s.section_index}
        manifest = dict(kind=KIND, device_install_allowed=False, source_bytes=SOURCE_BYTES,
            source_sha256=SOURCE_SHA256, payload_bytes=len(payload), payload_sha256=_sha(payload),
            code_link_va=CODE_VA, state_link_va=state_start, state_bytes=state_bytes,
            entries={name: symbols[name] - CODE_VA for name, _, _ in HOOKS},
            source_sha256_map=receipt['source_sha256'])
        recipe = prepare(source, payload, manifest)
        candidate = recipe.build_candidate(source)
        inverse = recipe.build_candidate(candidate, restore=True)
        if inverse != source:
            raise ValueError('Whole historical App inverse disagrees')
        if receipt['source_sha256'] != {p.name: _sha(p.read_bytes()) for p in sources + headers}:
            raise ValueError('Source changed during build; preserve the receipt and build again from a stable source')
        files = {'playback_filter_payload.bin': payload, 'playback_filter_payload.elf': linked_bytes,
                 'candidate.app': candidate, 'inverse.original.app': inverse,
                 'payload_manifest.json': (json.dumps(manifest, indent=2) + '\n').encode(),
                 'payload.ld': LINKER_SCRIPT.encode('ascii')}
        for name, data in files.items():
            (output / name).write_bytes(data)
            if (output / name).read_bytes() != data:
                raise ValueError('Retained output readback failed')
        for obj in objects:
            shutil.copy2(obj, output / obj.name)
        receipt.update(summary(recipe, manifest), state='OFFLINE_CANDIDATE_BUILT',
            files={name: dict(bytes=len(data), sha256=_sha(data)) for name, data in files.items()},
            changed_original_spans=recipe.preview()['changes'],
            payload_symbols={name: hex(value) for name, value in symbols.items()},
            linked_undefined_symbols=0, linked_relocations=0, inverse_exact=True)
    finally:
        if (scratch.resolve(strict=True) != expected or expected.parent != base
                or stat.S_ISLNK(scratch.lstat().st_mode)
                or getattr(scratch.lstat(), 'st_file_attributes', 0) & 0x400):
            raise RuntimeError('Unsafe payload scratch cleanup refused')
        for current, dirs, files in os.walk(scratch, followlinks=False):
            for name in dirs + files:
                child = Path(current) / name
                if not child.resolve().is_relative_to(expected) or getattr(child.lstat(), 'st_file_attributes', 0) & 0x400:
                    raise RuntimeError('Unsafe payload scratch child cleanup refused')
        shutil.rmtree(scratch)
        receipt['scratch_removed'] = not scratch.exists()
        (output / 'build_receipt.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf8')
    return receipt


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--app-reference', required=True)
    parser.add_argument('--output-dir', required=True, help='New durable directory; must not already exist')
    parser.add_argument('--zig', required=True, help='Pinned local Zig0.13.0 executable')
    args = parser.parse_args(argv)
    result = build(args.app_reference, args.output_dir, args.zig)
    print('RESULT: ' + json.dumps({key: result[key] for key in
        ('state', 'candidate_sha256', 'candidate_bytes', 'payload_sha256', 'payload_bytes',
         'device_install_allowed', 'camera_access_performed', 'inverse_exact', 'scratch_removed')}))
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
