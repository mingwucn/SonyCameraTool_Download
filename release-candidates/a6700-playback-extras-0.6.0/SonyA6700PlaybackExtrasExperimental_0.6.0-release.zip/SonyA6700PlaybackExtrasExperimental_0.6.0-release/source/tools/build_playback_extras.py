"""Offline Windows package; never invokes a live worker or enumerates cameras."""
import argparse
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import zipfile

# Support the existing `python -m tools...` entry from the model workbench.
if __name__ == "__main__":
    for shared_root in Path(__file__).resolve().parents:
        if (shared_root / "camera_pipeline").is_dir():
            sys.path.insert(0, str(shared_root))
            break

from tools import experimental_playback_extras as extras
from tools import playback_extras_probe as probe
from tools import playback_general_transfer_probe as general_probe
from tools import playback_extras_native_profile as native_profile
from tools import a6700_drivers
from tools import playback_filter_offline as filter_offline

ROOT = Path(__file__).resolve().parents[1]
REPOSITORY_ROOT = ROOT if (ROOT / "camera_pipeline").is_dir() else ROOT.parents[3]
NAME = "SonyA6700PlaybackExtrasExperimental"
VERSION = "0.6.0"
WHEEL_SHA = "bf9b754557af4717fe80c2b07cc2b923a9151f5c08d17bdb5345dac09d6a0430"
DLL_SHA = "62ccefaf3f99dc46f6739f803391958cf77c8bc9cb5cf44acda8512709a404db"
LGPL_SHA = "5df07007198989c622f5d41de8d703e7bef3d0e79d62e24332ee739a452af62a"
TKINTER_SHA = "cc6a7429e8f1582cd7a2b2a1d5f51f559415bef220a214e2d88a12e837e66919"
TK_DLL_SHA = {
    "tcl86t.dll": "0c172d8c3cfb524d87484d1b771cf0ba7204d7204e76ef133efad5bd92898f7f",
    "tk86t.dll": "4de6f07eb78557497a43089a9adff4f7d478db8560f0cde7b2fa3b4510df2468",
    "zlib1.dll": "955b8aedcef4546f0e9218014f4743047ab9980e882b507177c4348fbc9e0f45",
}
FROZEN_CHECKS = ("--self-check", "--writer-self-check", "--describe", "--transport-self-check",
                 "--gui-self-check", "--driver-self-check", "--usb-observer-self-check",
                 "--workflow-self-check", "--filter-payload-self-check",
                 "--general-transfer-reader-self-check")
# Narrow corresponding-source boundary: no private-reference analyzers, camera
# captures, credentials, unrelated writers or previous app entry points.
SOURCE_ALLOWLIST = (
    "tools/playback_extras_probe.py", "tools/build_playback_extras.py",
    "tools/experimental_playback_extras.py", "tools/playback_extras_candidate.py",
    "tools/playback_extras_native_profile.py", "tools/playback_writer_wait.py",
    "tools/playback_extras_workflow.py", "tools/playback_extras_pipeline.py",
    "tools/playback_extras_presentation.py",
    "tools/playback_general_transfer_reader.py", "tools/playback_general_transfer_probe.py",
    "tools/playback_filter_offline.py", "tools/playback_filter_payload.py",
    "tools/playback_filter_patch.py", "tools/playback_filter_patch_layout.py",
    "tools/build_playback_filter_patch.py", "tools/elf_static.py",
    # These support both the seven-window and two-window App readers, saved
    # capture validation and the dedicated compatibility generator.
    "tools/playback_probe.py", "tools/playback_menu_candidate.py",
    "tools/playback_menu_native_profile.py", "tools/analyze_playback_capture.py",
    "tools/legacy_sparse_session.py", "tools/legacy_sparse_wbi.py", "tools/inspect_legacy_customizer.py",
    "tools/service_operation_lock.py", "tools/usb_observer_self_check.py",
    "tools/a6700_drivers.py", "tools/driver_local_files.py",
    "apps/a6700_customizer/__init__.py", "apps/a6700_customizer/app_backend.py",
    "apps/a6700_customizer/targets.py", "apps/a6700_customizer/recovery_journal.py",
    "apps/a6700_customizer/ftp_usb_observer.py", "apps/a6700_customizer/ftp_usb_binding.py",
    "apps/a6700_customizer/native/playback_extras_probe_aarch64.c",
    "apps/a6700_customizer/native/playback_general_transfer_reader_aarch64.c",
    "apps/a6700_customizer/native/playback_general_transfer_reader.h",
    "apps/a6700_customizer/native/playback_general_transfer_probe_aarch64.c",
    "apps/a6700_customizer/native/playback_extras_write_aarch64.c",
    "apps/a6700_customizer/native/ftp_wbi_experimental_core.c",
    "apps/a6700_customizer/native/ftp_wbi_experimental_core.h",
    "apps/a6700_customizer/native/ftp_app_guard.c",
    "apps/a6700_customizer/native/ftp_app_guard.h",
    *tuple("apps/a6700_customizer/native/playback_filter_" + name for name in (
        "query.h", "query.cpp", "sony.h", "sony.cpp", "snapshot.h", "snapshot.cpp",
        "active.h", "active.cpp", "registry.h", "registry.c",
        "registry_aarch64.S", "active_aarch64.S")))


# Same canonical modules used by the working A7CR pipeline. Keep their source
# origin separate; never allow ../ traversal through the workbench allowlist.
SHARED_SOURCE_ALLOWLIST = tuple("camera_pipeline/" + name + ".py" for name in
                                ("__init__", "models", "recipes", "transactions", "pipeline", "gui",
                                 "presentation", "workbench"))


def stage_sources(destination):
    """Copy the explicit corresponding-source set, including shared imports."""
    destination = Path(destination)
    for origin, selected in ((ROOT, SOURCE_ALLOWLIST), (REPOSITORY_ROOT, SHARED_SOURCE_ALLOWLIST)):
        for relative in selected:
            path = Path(relative)
            if path.is_absolute() or ".." in path.parts:
                raise ValueError("Source inputs must stay within their declared source root")
            target = destination / path
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(origin / path, target)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def checked(path, expected):
    if not path.is_file() or digest(path) != expected:
        raise RuntimeError("Missing or altered pinned build input: " + str(path))
    return path


def native_inputs():
    """Return only the pinned artifacts and exact generated native policies."""
    probe.load_payload()
    assets = [probe.PAYLOAD_PATH.relative_to(ROOT)]
    assets.append(assets[0].parent / "BUILD.txt")
    general_probe.load_payload()
    general_payload = general_probe.PAYLOAD_PATH.relative_to(ROOT)
    assets.extend((general_payload, general_payload.parent / "BUILD.txt"))
    for action in extras.planner.CANDIDATE_ACTIONS:
        extras.load_writer(action)
        relative = extras.WRITER_PINS[action]["path"].relative_to(ROOT)
        assets.append(relative)
        for name, expected in (("playback_extras_profile.h", native_profile.profile_header(action)),
                               ("playback_extras_guard_policy.h", native_profile.guard_header(action))):
            path = relative.parent / name
            if (ROOT / path).read_text(encoding="utf-8") != expected:
                raise RuntimeError("Native profile/guard header differs from its generator: " + str(path))
            assets.append(path)
        assets.append(relative.parent / "BUILD.txt")
    if len(assets) != len(set(assets)) or any(not (ROOT / path).is_file() for path in assets):
        raise RuntimeError("Missing or duplicate native extras provenance input")
    return tuple(assets)


def filter_inputs():
    """Only authored payload and pinned sanitized metadata; no complete App."""
    return tuple(path.relative_to(ROOT) for path in filter_offline.payload_assets())


def validate_frozen_check(flag, stdout):
    """Reject a passing check from the old application or an incorrect profile."""
    if flag == "--filter-payload-self-check":
        value = json.loads(stdout)
        if (value != filter_offline.self_check() or type(value.get('camera_commands')) is not int
                or value.get('installation_enabled') is not False):
            raise RuntimeError("Frozen authored filter payload check mismatch")
    elif flag == "--self-check":
        value = json.loads(stdout)
        if (value.get("status") != "OFFLINE_SELF_CHECK_PASSED" or
                value.get("profile_sha256") != probe.PROFILE_SHA256 or
                value.get("payload_sha256") != probe.PAYLOAD_SHA256 or
                value.get("camera_commands") != 0):
            raise RuntimeError("Frozen extras reader self-check mismatch")
    elif flag == "--writer-self-check":
        if stdout.strip() != "PINNED_EXTRAS_WRITERS_AND_READER_OK; CAMERA_COMMANDS=0":
            raise RuntimeError("Frozen extras writer self-check mismatch")
    elif flag == "--general-transfer-reader-self-check":
        value = json.loads(stdout)
        if (value.get("status") != "OFFLINE_GENERAL_TRANSFER_READER_SELF_CHECK_PASSED" or
                value.get("profile_sha256") != general_probe.PROFILE_SHA256 or
                value.get("payload_sha256") != general_probe.PAYLOAD_SHA256 or
                value.get("camera_commands") != 0 or value.get("wbi_access") is not False):
            raise RuntimeError("Frozen two-window App-only reader check mismatch")
    elif flag == "--describe":
        value = json.loads(stdout)
        if value != extras.describe():
            raise RuntimeError("Frozen extras action description mismatch")
    elif flag == "--transport-self-check":
        if stdout.splitlines() != ["GUARD_SELF_TEST_PASS",
                                   "PINNED_TRANSPORT_IMPORT_AND_GUARD_CHECK_PASSED; CAMERA_COMMANDS=0"]:
            raise RuntimeError("Frozen transport self-check mismatch")
    elif flag == "--driver-self-check":
        if stdout.strip() != "PINNED_DRIVER_ASSETS_OK; CAMERA_COMMANDS=0; DRIVER_CHANGES=0":
            raise RuntimeError("Frozen driver self-check mismatch")
    elif flag == "--gui-self-check":
        if stdout.strip() != "GUI_WIDGET_SELF_CHECK_PASSED; CAMERA_COMMANDS=0":
            raise RuntimeError("Frozen GUI construction result mismatch")
    elif flag == "--workflow-self-check":
        value = json.loads(stdout)
        if (value.get("status") != "OFFLINE_PLAYBACK_WORKFLOW_SELF_CHECK_PASSED" or
                value.get("synthetic") is not True or value.get("cases") != 4 or
                type(value.get("camera_commands")) is not int or value["camera_commands"] != 0 or
                type(value.get("backend_imports")) is not int or value["backend_imports"] != 0):
            raise RuntimeError("Frozen playback workflow self-check mismatch")
    elif flag == "--usb-observer-self-check":
        value = json.loads(stdout)
        if (value.get("status") != "OFFLINE_USB_OBSERVER_DIAGNOSTICS_PASSED" or
                value.get("synthetic") is not True or
                value.get("native_contexts_created") != 0 or
                value.get("native_library_loaded") is not False or
                value.get("device_enumerations") != 0 or value.get("camera_commands") != 0):
            raise RuntimeError("Frozen USB observer synthetic result mismatch")
    else:
        raise ValueError("Unrecognized frozen check")


def audit_archive(archive, output):
    """Verify the exact member set and read every delivered member back."""
    expected = {(Path(output.name) / path.relative_to(output)).as_posix(): path
                for path in output.rglob("*") if path.is_file()}
    with zipfile.ZipFile(archive) as z:
        names = z.namelist()
        if len(names) != len(set(names)) or set(names) != set(expected) or z.testzip() is not None:
            raise RuntimeError("Archive member-set or integrity verification failed")
        for name, path in expected.items():
            if hashlib.sha256(z.read(name)).hexdigest() != digest(path):
                raise RuntimeError("Archive file readback mismatch")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--scratch", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--lgpl", type=Path, required=True)
    parser.add_argument("--original", type=Path, required=True,
                        help="path to the existing SonyA6700Customizer onedir bundle")
    args = parser.parse_args()
    scratch = args.scratch.resolve(strict=True)
    temp = Path(os.environ["TEMP"]).resolve(strict=True)
    if (scratch.parent != temp / "Codex" or ROOT in scratch.parents or any(scratch.iterdir())):
        raise SystemExit("Scratch must be a new empty system TEMP/Codex child outside the workspace")
    output = args.output.resolve()
    original = args.original.resolve(strict=True)
    archive = Path(str(output) + ".zip")
    if (scratch == output or scratch in output.parents or temp == output or temp in output.parents or
            output.exists() or archive.exists()):
        raise SystemExit("Deliverable must be new and outside system Temp/scratch")
    if (sys.platform != "win32" or sys.version_info[:3] != (3, 10, 20) or
            importlib.metadata.version("pyinstaller") != "6.22.3"):
        raise SystemExit("Requires project-local Python 3.10.20/PyInstaller 6.22.3 runtime")
    import _tkinter
    checked(Path(_tkinter.__file__), TKINTER_SHA)
    tk_binaries = [checked(Path(sys.base_prefix) / "Library/bin" / name, expected)
                   for name, expected in TK_DLL_SHA.items()]
    probe.load_payload()
    general_probe.load_payload()
    for action in extras.planner.CANDIDATE_ACTIONS:
        extras.load_writer(action)
    if len(native_profile.compatibility_targets()) != 99:
        raise SystemExit("Dedicated extras policy must retain exactly 99 fields")
    driver_rel = Path('.data/playback-driver-assets-20261104')
    driver_assets = a6700_drivers.validate_assets(ROOT / driver_rel / 'driver/libwdi')
    if not extras.LIVE_ACTION_ENABLED:
        raise SystemExit("Extras writer review has not enabled this experimental build")
    wheel = checked(ROOT / ".data/ftp-usb-identity-4a31ebba04bc/pyusb-1.3.1-py3-none-any.whl", WHEEL_SHA)
    dll = checked(original / "_internal/libusb-1.0.dll", DLL_SHA)
    lgpl = checked(args.lgpl, LGPL_SHA)
    vendor = original / "_internal/third_party/a6700_unlock"
    commit = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip()
    dirty = bool(subprocess.check_output(["git", "diff", "HEAD", "--name-only"], cwd=ROOT, text=True).strip())
    tree_dirty = bool(subprocess.check_output(["git", "status", "--porcelain"], cwd=ROOT, text=True).strip())
    source = scratch / "source"
    source.mkdir()
    ignore = shutil.ignore_patterns("__pycache__", "*.pyc")
    # Only the explicit runtime, planner, native generator and capture auditor.
    # Private-reference analysis tools and unrelated writers are not included.
    stage_sources(source)
    shutil.copytree(ROOT / "apps/a6700_customizer/a6700win", source / "apps/a6700_customizer/a6700win", ignore=ignore)
    shutil.copy2(ROOT / "run_playback_extras_gui.py", source)
    shutil.copytree(vendor, source / "a6700_unlock", ignore=ignore)
    native_assets = native_inputs() + filter_inputs()
    for relative in native_assets:
        target = source / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(ROOT / relative, target)
    shutil.copytree(ROOT / driver_rel / 'driver/libwdi', source / driver_rel / 'driver/libwdi')
    a6700_drivers.validate_assets(source / driver_rel / 'driver/libwdi')
    native_source_assets = tuple(path for path in native_assets if path.suffix != '.elf') + (
        driver_rel / 'SOURCE_PROVENANCE.json',)
    for relative in native_source_assets:
        target = source / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(ROOT / relative, target)
    shutil.copy2(dll, source)
    package = scratch / "pyusb"
    with zipfile.ZipFile(wheel) as z:
        for entry in z.infolist():
            if package.resolve() not in (package / entry.filename).resolve().parents:
                raise RuntimeError("Unsafe dependency archive path")
        z.extractall(package)
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1", PYTHONIOENCODING="utf-8",
               PYINSTALLER_CONFIG_DIR=str(scratch / "config"), TEMP=str(scratch), TMP=str(scratch))
    command = [sys.executable, "-m", "PyInstaller", "--noconfirm", "--clean", "--onedir", "--name", NAME,
               "--distpath", str(scratch / "dist"), "--workpath", str(scratch / "work"), "--specpath", str(scratch),
               "--paths", str(source), "--paths", str(source / "apps/a6700_customizer"), "--paths", str(package),
               "--hidden-import", "usb.backend.libusb1", "--add-data", f"{source / 'a6700_unlock'};third_party/a6700_unlock",
               "--add-data", f"{source / 'a6700_unlock'};a6700_unlock",
               *[item for relative in native_assets for item in (
                   "--add-data", f"{source / relative};{relative.parent.as_posix()}")],
               "--add-data", f"{source / driver_rel / 'driver/libwdi'};{(driver_rel / 'driver/libwdi').as_posix()}",
               "--add-binary", f"{source / dll.name};.",
               *[item for library in tk_binaries for item in ("--add-binary", f"{library};.")],
               str(source / "run_playback_extras_gui.py")]
    with (scratch / "build.log").open("w", encoding="utf-8") as log:
        subprocess.run(command, cwd=source, env=env, stdout=log, stderr=subprocess.STDOUT, check=True)
    built = scratch / "dist" / NAME
    shutil.copy2(ROOT / "PLAYBACK_EXTRAS_EXPERIMENTAL_GUIDE.md", built / "USER_GUIDE.md")
    shutil.copy2(probe.PAYLOAD_PATH.parent / "BUILD.txt", built / "PLAYBACK_EXTRAS_PROBE_NATIVE_BUILD.txt")
    shutil.copy2(general_probe.PAYLOAD_PATH.parent / "BUILD.txt",
                 built / "PLAYBACK_GENERAL_TRANSFER_PROBE_NATIVE_BUILD.txt")
    for action in extras.planner.CANDIDATE_ACTIONS:
        shutil.copy2(extras.WRITER_PINS[action]['path'].parent / "BUILD.txt",
                     built / ("PLAYBACK_EXTRAS_" + action.upper() + "_NATIVE_BUILD.txt"))
    licenses = built / "licenses"
    licenses.mkdir()
    for name in ("LICENSE", "NOTICE", "THIRD_PARTY_NOTICES.md"):
        shutil.copy2(vendor / name, licenses / ("a6700_unlock-" + name))
    shutil.copy2(lgpl, licenses / "libusb-LGPL-2.1.txt")
    shutil.copy2(package / "pyusb-1.3.1.dist-info/LICENSE", licenses / "PyUSB-LICENSE.txt")
    # Corresponding source only; no private firmware, captures or credentials.
    delivery = built / "source"
    for path in source.rglob("*"):
        if (path.is_file() and "a6700_unlock" not in path.parts and
                (path.suffix in (".py", ".c", ".h", ".cpp", ".S") or path.relative_to(source) in native_source_assets)):
            target = delivery / path.relative_to(source)
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(path, target)
    tests = []
    check_env = dict(env, PATH=os.pathsep.join((str(Path(os.environ["SystemRoot"]) / "System32"),
                                               os.environ["SystemRoot"])))
    for flag in FROZEN_CHECKS:
        result = subprocess.run([str(built / (NAME + ".exe")), flag], env=check_env, capture_output=True,
                                text=True, encoding="utf-8", timeout=30, check=True)
        validate_frozen_check(flag, result.stdout)
        tests.append({"action": flag, "exit_code": result.returncode, "stdout": result.stdout.strip()})
    manifest = {"tool": NAME, "version": VERSION, "source_commit": commit,
                "native_build_record_source_commit_role": "PRE_IMPLEMENTATION_BASELINE_WITH_EXACT_SOURCE_HASHES",
                "implementation_source_commit": commit,
                "python_version": sys.version.split()[0], "pyinstaller_version": importlib.metadata.version('pyinstaller'),
                "tkinter_extension_sha256": TKINTER_SHA, "gui_dll_sha256": TK_DLL_SHA,
                "libusb_lgpl_license_source": "cameras/sony/english_unlock/native/libusb-LGPL-2.1.txt",
                "libusb_lgpl_license_sha256": LGPL_SHA,
                "frozen_checks_path": "WINDOWS_SYSTEM_DIRECTORIES_ONLY",
                "experimental": True, "tracked_source_dirty": dirty, "source_tree_dirty": tree_dirty,
                "same_window_followup": True, "automatic_validated_capture_selection": True,
                "post_service_camera_acknowledgement": True,
                "automatic_camera_followup": False, "incomplete_capture_input_refused": True,
                "driver_manifest_sha256": driver_assets['manifest_sha256'],
                "driver_helper_sha256": driver_assets['helper_sha256'],
                "driver_install_allowlist": {"vendor": "054C", "model": "ILCE-6700", "normal_pid": "0E76"},
                "connection_check_action": "WINDOWS_METADATA_ONLY_EXPLICIT_SELECTION",
                "windows_driver_install_action": "SEPARATE_EXACT_TARGET_REVIEW_AND_UAC_IF_NEEDED",
                "shared_service_0336_driver_install": False,
                "connection_check_or_driver_install_exercised_on_hardware": False,
                "usb_observer_diagnostics": "SANITIZED_OPEN_OR_CONTROL_CALL_SITE_AND_OBSERVED_NATIVE_ERROR_CODE",
                "usb_observer_failure_repaired_on_hardware": False,
                "reader_native_sha256": probe.PAYLOAD_SHA256,
                "reader_native_bytes": probe.PAYLOAD_BYTES,
                "reader_profile_sha256": probe.PROFILE_SHA256,
                "general_transfer_reader_native_sha256": general_probe.PAYLOAD_SHA256,
                "general_transfer_reader_native_bytes": general_probe.PAYLOAD_BYTES,
                "general_transfer_reader_profile_sha256": general_probe.PROFILE_SHA256,
                "writer_actions": {action: {
                    "native_sha256": extras.WRITER_PINS[action]['sha256'],
                    "native_bytes": extras.WRITER_PINS[action]['bytes'],
                    "profile_sha256": extras.planner.PROFILE_SHA256[action],
                    "logical_byte_changes": {'shortcut': 2, 'label': 4, 'general_transfer': 1}[action],
                    "software_transaction_targets": len(extras.planner.TARGET_INDICES[action]),
                    "writable_wbi_target": action == 'label',
                    "independent_complete_readback_windows": 2 if action == 'general_transfer' else 7,
                    "physical_tested": False} for action in extras.planner.CANDIDATE_ACTIONS},
                "source_file_sha256": {str(path.relative_to(delivery).as_posix()): digest(path)
                                       for path in sorted(delivery.rglob("*")) if path.is_file()},
                "exe_sha256": digest(built / (NAME + ".exe")), "offline_checks": tests,
                "camera_tested": False, "firmware_writing_action": True,
                "independent_complete_readback_windows_by_action": {
                    action: (2 if action == "general_transfer" else 7)
                    for action in extras.planner.CANDIDATE_ACTIONS},
                "independent_complete_readback_bytes_by_action": {
                    action: (1024 if action == "general_transfer" else 3584)
                    for action in extras.planner.CANDIDATE_ACTIONS},
                "dedicated_app_guard_fields_by_action": {
                    action: (100 if action == "general_transfer" else 99)
                    for action in extras.planner.CANDIDATE_ACTIONS},
                "full_normalized_app_guard": "ACTION_SPECIFIC_BEFORE_AND_AFTER_WITH_STABLE_METADATA_AND_ENGLISH",
                "filter_parameter_0x568_modified": False,
                "filter_execution_repair": False,
                "filter_offline_prototype": filter_offline.self_check(),
                "filter_offline_candidate_action": "EXPLICIT_ORDINARY_FILES_ONLY",
                "filter_camera_installation_enabled": False,
                "shared_workbench_origin": "f991a96ca0720f50048b81ff0bfbe46dbe9c528e",
                "transfer_handler_instructions_modified": False,
                "uxc_files_modified": False,
                "existing_button_assignments_modified": False,
                "scope": "Playback current-image and general FTP shortcuts, title action, plus offline native FTP filter candidate preparation",
                "limits": ["Each action needs separate explicit selection and owner confirmation",
                           "Physical shortcut assignment/transfer and title rendering remain owner-check pending",
                           "General FTP Transfer has not been tested on this camera",
                           "Native filtering candidate is offline only; target loader and installation remain unqualified",
                           "Active FTP-only prototype refuses other enabled criteria; preview count unchanged",
                           "Partial backups only; failed-start recovery unproven",
                           "Physical WBI geometry and integrity handling unproven",
                           "Logical byte counts do not bound physical write extent"]}
    (built / "BUILD.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    output.parent.mkdir(parents=True, exist_ok=True)
    shutil.copytree(built, output)
    if digest(output / (NAME + ".exe")) != manifest["exe_sha256"]:
        raise RuntimeError("Delivered EXE hash mismatch")
    with zipfile.ZipFile(archive, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for path in sorted(output.rglob("*")):
            if path.is_file():
                z.write(path, Path(output.name) / path.relative_to(output))
    audit_archive(archive, output)
    print(json.dumps({**manifest, "zip_sha256": digest(archive), "output": str(output)}, indent=2))


if __name__ == "__main__":
    main()
