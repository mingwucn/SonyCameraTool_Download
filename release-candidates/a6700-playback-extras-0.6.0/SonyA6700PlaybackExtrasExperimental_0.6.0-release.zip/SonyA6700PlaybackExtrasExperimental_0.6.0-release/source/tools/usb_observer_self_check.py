"""Offline diagnostic check using PyUSB and invented devices, without native I/O."""
import json
import struct
from types import SimpleNamespace

from apps.a6700_customizer.ftp_usb_observer import ObservationError, UsbDescriptorObservation


def run():
    """Exercise the real pinned adapter/error mapping without loading a library."""
    import usb
    from usb import core, util
    from usb.backend import libusb1

    if usb.__version__ != '1.3.1' or libusb1._lib is not None:
        raise RuntimeError('Offline observer check requires unloaded pinned PyUSB 1.3.1')
    names = ('bLength', 'bDescriptorType', 'bcdUSB', 'bDeviceClass', 'bDeviceSubClass',
             'bDeviceProtocol', 'bMaxPacketSize0', 'idVendor', 'idProduct', 'bcdDevice',
             'iManufacturer', 'iProduct', 'iSerialNumber', 'bNumConfigurations')
    raw = struct.pack('<BBHBBBBHHHBBBB', 18, 1, 0x0200, 0, 0, 0, 64,
                      0x054c, 0x0336, 0x0200, 1, 2, 0, 1)
    descriptor = dict(zip(names, struct.unpack('<BBHBBBBHHHBBBB', raw)))
    descriptor.update(address=7, bus=1, port_number=3, port_numbers=(2, 3), speed=3)
    results = []

    for failure in ('open_native', 'transfer_native', 'transfer_generic'):
        class InventedLibrary:
            def libusb_control_transfer(self, *args):
                backend.transfers += 1
                if failure == 'transfer_generic':
                    raise NotImplementedError('PRIVATE-INVENTED-ERROR')
                return -12

        class InventedBackend(libusb1._LibUSB):
            def __init__(self):
                # Deliberately omit the native superclass initializer/context.
                self.lib = InventedLibrary()
                self.opens = self.closes = self.transfers = 0

            def _finalize_object(self):
                pass

            def get_device_descriptor(self, device):
                return SimpleNamespace(**descriptor)

            def open_device(self, device):
                self.opens += 1
                if failure == 'open_native':
                    libusb1._check(-12)
                return SimpleNamespace(handle=object())

            def close_device(self, handle):
                self.closes += 1

            def enumerate_devices(self):
                raise AssertionError('Offline check must never enumerate devices')

        backend = InventedBackend()
        device = core.Device(object(), backend)
        attempt = UsbDescriptorObservation(device, 0x0336)
        try:
            try:
                attempt.read(3000)
            except ObservationError as error:
                expected = {'type': 'NotImplementedError',
                            'operation': 'open_device' if failure == 'open_native' else 'ctrl_transfer'}
                if failure != 'transfer_generic':
                    expected['native_error_code'] = -12
                if error.observation_step != 'device_descriptor' or error.backend_diagnostic != expected:
                    raise RuntimeError('Offline observer diagnostic did not match its invented failure')
            else:
                raise RuntimeError('Offline observer accepted an invented failed operation')
            try:
                attempt.read(3000)
            except ObservationError:
                pass
            else:
                raise RuntimeError('Offline observer retried an invented failed operation')
        finally:
            util.dispose_resources(device)
        if backend.opens != 1 or backend.transfers != (0 if failure == 'open_native' else 1):
            raise RuntimeError('Offline observer repeated its invented backend operation')
        results.append({'failure': failure, 'opens': backend.opens, 'transfers': backend.transfers,
                        'closes': backend.closes})
    if libusb1._lib is not None:
        raise RuntimeError('Offline check unexpectedly loaded a native library')
    return {'status': 'OFFLINE_USB_OBSERVER_DIAGNOSTICS_PASSED', 'synthetic': True,
            'cases': results, 'native_contexts_created': 0, 'native_library_loaded': False,
            'device_enumerations': 0, 'camera_commands': 0}


if __name__ == '__main__':
    print(json.dumps(run(), sort_keys=True))
