"""Offline GUI state for sequential, separately selected playback operations.

No process, USB, camera or driver API is imported here. A terminal worker result
can select an independently validated inspection; it never starts an operation.
"""
import json

from tools import playback_extras_probe as probe
from tools import playback_general_transfer_probe as general_probe


OPERATIONS = ('inspect', 'inspect_general', 'shortcut', 'label', 'general_transfer')
SERVICE_EXITS = ('NOT_SENT', 'stop-sent', 'unconfirmed', 'WITHHELD_AFTER_ERROR')
MAX_RESULT_BYTES = 32768


def _same(left, right):
    return probe._canonical(left) == probe._canonical(right)


def _inspection_report(report):
    return (type(report) is dict and report.get('status') == 'PERSISTED' and
            report.get('probe_state') == 'PERSISTED' and
            report.get('service_attempted') is True and
            report.get('camera_state_uncertain') is True and
            report.get('firmware_written') is False and
            report.get('automatic_retry') is False and
            report.get('service_exit') in SERVICE_EXITS)


def _no_session(report, operation):
    inspection = operation.startswith('inspect')
    attempted = 'service_attempted' if inspection else 'session_attempted'
    other = 'session_attempted' if inspection else 'service_attempted'
    return (report.get(attempted) is False and
            (other not in report or report[other] is False) and
            report.get('camera_state_uncertain') is False and
            report.get('service_exit') == 'NOT_SENT' and
            report.get('automatic_retry') is False and
            report.get('writer_may_have_executed', False) is False and
            report.get('firmware_written', False) is False)


def _verified_writer(report, operation):
    native = report.get('native_writer_result')
    count = 2 if operation == 'label' else 1
    expected = {'status_code': 0, 'status': 'VERIFIED', 'failed_window': 0xffffffff,
                'attempted_windows': count, 'verified_windows': count, 'uncertain': False}
    return (report.get('state') == 'READBACK_VERIFIED' and
            report.get('action') == operation and
            report.get('session_attempted') is True and
            report.get('writer_may_have_executed') is True and
            report.get('camera_state_uncertain') is True and
            report.get('automatic_retry') is False and
            report.get('service_exit') in SERVICE_EXITS and
            type(native) is dict and set(native) == set(expected) and
            all(type(native[key]) is type(value) and native[key] == value
                for key, value in expected.items()))


class Workflow:
    """One terminal worker at a time, followed by an explicit physical check."""

    def __init__(self, validate_inspection=None):
        self._validate_legacy = probe.saved_result if validate_inspection is None else validate_inspection
        self._validate_general = general_probe.saved_result if validate_inspection is None else validate_inspection
        self.state = 'READY'
        self.selected_folder = ''
        self.selected_inspection = None
        self.message = 'Select Read playback state or choose a completed saved inspection.'
        self.run_id = 0
        self._operation = None
        self._folder = None
        self._result = None
        self._invalid_output = False

    @property
    def can_service(self):
        return self.state == 'READY'

    def adopt(self, folder, operation=None):
        """Validate an explicitly chosen record without changing camera state."""
        if self.state in ('RUNNING', 'NEEDS_REVIEW'):
            raise RuntimeError('A running or uncertain operation prevents record selection')
        self.selected_folder = ''
        if type(folder) is not str or not folder.strip():
            raise ValueError('Choose a completed playback inspection folder.')
        candidates = ((operation, self._validate_general),) if operation == 'inspect_general' else (
            ((operation, self._validate_legacy),) if operation == 'inspect' else
            (('inspect', self._validate_legacy), ('inspect_general', self._validate_general)))
        report = None
        errors = []
        selected = None
        for kind, validator in candidates:
            try:
                candidate = validator(folder)
                if _inspection_report(candidate):
                    report, selected = candidate, kind
                    break
            except Exception as error:
                errors.append(error)
        if report is None:
            detail = str(errors[-1]) if errors else 'Choose a complete valid seven-window or two-window App record.'
            self.message = 'Inspection not selected: ' + detail
            raise ValueError(self.message) from (errors[-1] if errors else None)
        self.selected_folder = folder
        self.selected_inspection = selected
        self.message = 'Completed inspection selected. Review one change separately when ready.'
        return report

    def begin(self, operation):
        if not self.can_service:
            raise RuntimeError('Finish the running operation or required camera check first')
        if operation not in OPERATIONS:
            raise ValueError('Select a playback inspection or one playback FTP action explicitly')
        if not operation.startswith('inspect') and not self.selected_folder:
            raise ValueError('A completed inspection must be selected before a change')
        if operation == 'general_transfer' and self.selected_inspection != 'inspect_general':
            raise ValueError('FTP Transfer requires a complete two-window App inspection')
        if operation in ('shortcut', 'label') and self.selected_inspection != 'inspect':
            raise ValueError('This action requires a complete seven-window inspection')
        self.run_id += 1
        self._operation = operation
        self._folder, self._result, self._invalid_output = None, None, False
        if operation.startswith('inspect'):
            self.selected_inspection = None
        self.selected_folder = ''
        self.state = 'RUNNING'
        self.message = 'One operation is running. Keep camera power and USB connected.'
        return self.run_id

    def _current(self, run_id):
        return type(run_id) is int and run_id == self.run_id and self.state == 'RUNNING'

    def feed(self, run_id, line):
        """Collect worker evidence only; malformed or stale output dispatches nothing."""
        if not self._current(run_id):
            return
        if type(line) is not str:
            self._invalid_output = True
            return
        if line.startswith('RECORD_DIR:'):
            folder = line[len('RECORD_DIR:'):].strip()
            if self._folder is not None or not folder or len(folder) > 4096:
                self._invalid_output = True
            else:
                self._folder = folder
        elif line.startswith('RESULT:'):
            raw = line[len('RESULT:'):].strip()
            try:
                encoded = raw.encode('utf-8')
                if self._result is not None or not 0 < len(encoded) <= MAX_RESULT_BYTES:
                    raise ValueError('Missing, oversized or duplicate result')
                self._result = probe._saved_json(encoded)
            except (ValueError, TypeError, UnicodeError, RecursionError):
                self._invalid_output = True

    def _review(self, detail):
        self.state = 'NEEDS_REVIEW'
        self.selected_folder = ''
        self.message = (detail + ' Preserve the records and follow the report. If execution is '
                        'uncertain, keep camera power and USB connected. No further camera '
                        'operation is enabled and nothing is retried automatically.')

    def finish(self, run_id, exit_code):
        """Call only after the worker process is confirmed terminal."""
        if not self._current(run_id):
            return
        report, operation = self._result, self._operation
        if (self._invalid_output or type(report) is not dict or
                type(exit_code) is not int or exit_code not in (0, 2)):
            self._review('The worker ended without a complete, recognized result.')
            return
        if operation.startswith('inspect') and _inspection_report(report):
            try:
                if not self._folder:
                    raise ValueError('No inspection record directory was reported.')
                saved = (self._validate_general if operation == 'inspect_general'
                         else self._validate_legacy)(self._folder)
                if not _inspection_report(saved) or not _same(saved, report):
                    raise ValueError('Printed and saved inspection results do not agree.')
            except Exception as error:
                self._review('The reported inspection could not be selected: ' + str(error))
                return
            self.selected_folder = self._folder
            self.selected_inspection = operation
            self.state = 'ACK_REQUIRED'
            self.message = ('Inspection saved and selected automatically. Follow its disconnect '
                            'instructions, verify the normal screen and English, reconnect in '
                            'Mass Storage mode, then check the camera-conditions box to review '
                            'a change. Service exit remains a separate check.')
            return
        if operation != 'inspect' and self._folder and _verified_writer(report, operation):
            self.state = 'ACK_REQUIRED'
            self.message = ('The selected change has complete readback. Follow its disconnect '
                            'instructions and check the normal screen, English, Network FTP and '
                            'the selected change. Reconnect in Mass Storage mode and confirm '
                            'the camera conditions. Read playback state again before another change.')
            return
        no_session = _no_session(report, operation)
        state = report.get('state', report.get('status'))
        expected_action = operation.startswith('inspect') or report.get('action') == operation
        allowed = ('INPUT_REFUSED', 'STOPPED') if operation.startswith('inspect') else (
            'INPUT_REFUSED', 'READY', 'STOPPED', 'ALREADY_APPLIED')
        if no_session and expected_action and state in allowed:
            self.state = 'READY'
            if state == 'ALREADY_APPLIED':
                self.message = ('The saved inspection already contains that change. No camera '
                                'operation was sent. Read current playback state before another change.')
            elif state == 'INPUT_REFUSED':
                self.message = ('The selected input was refused before camera service started. '
                                'Choose a completed inspection or select Read playback state when ready.')
            else:
                self.message = ('The operation stopped before camera service started; no complete '
                                'inspection was selected. Check connection and select Read playback '
                                'state once when ready. Nothing is retried automatically.')
            return
        self._review('The operation stopped or its service execution remains uncertain.')

    def acknowledge(self):
        if self.state != 'ACK_REQUIRED':
            raise RuntimeError('No completed operation is awaiting the camera check')
        self.state = 'READY'
        if not self.selected_folder:
            self.selected_inspection = None
        self.message = ('Camera check acknowledged. Review one selected change separately.'
                        if self.selected_folder else
                        'Camera check acknowledged. Select Read playback state before another change.')


def self_check():
    """Exercise transitions with invented reports; no files or backend are used."""
    import sys
    before = set(sys.modules)
    inspection = {'status': 'PERSISTED', 'probe_state': 'PERSISTED', 'capture': {},
                  'service_attempted': True, 'camera_state_uncertain': True,
                  'firmware_written': False, 'automatic_retry': False,
                  'service_exit': 'unconfirmed'}
    flow = Workflow(validate_inspection=lambda _: inspection)
    run = flow.begin('inspect')
    flow.feed(run, 'RECORD_DIR: synthetic-inspection')
    flow.feed(run, 'RESULT: ' + json.dumps(inspection))
    flow.finish(run, 2)
    if flow.state != 'ACK_REQUIRED' or flow.selected_folder != 'synthetic-inspection':
        raise RuntimeError('Inspection adoption or acknowledgement gate failed')
    flow.acknowledge()
    run = flow.begin('label')
    verified = {'state': 'READBACK_VERIFIED', 'action': 'label', 'session_attempted': True,
                'writer_may_have_executed': True, 'camera_state_uncertain': True,
                'automatic_retry': False, 'service_exit': 'unconfirmed',
                'native_writer_result': {'status_code': 0, 'status': 'VERIFIED',
                    'failed_window': 0xffffffff, 'attempted_windows': 2,
                    'verified_windows': 2, 'uncertain': False}}
    flow.feed(run, 'RECORD_DIR: synthetic-write')
    flow.feed(run, 'RESULT: ' + json.dumps(verified))
    flow.finish(run, 2)
    if flow.state != 'ACK_REQUIRED' or flow.selected_folder:
        raise RuntimeError('Writer completion or capture invalidation failed')
    flow.acknowledge()
    try:
        flow.begin('shortcut')
    except ValueError:
        pass
    else:
        raise RuntimeError('A second write used the prior inspection')
    run = flow.begin('inspect')
    refused = {'status': 'STOPPED', 'service_attempted': False,
               'camera_state_uncertain': False, 'service_exit': 'NOT_SENT',
               'automatic_retry': False, 'firmware_written': False}
    flow.feed(run, 'RESULT: ' + json.dumps(refused))
    flow.finish(run, 2)
    if not flow.can_service or flow.selected_folder:
        raise RuntimeError('No-service preflight handling failed')
    flow.adopt('synthetic-inspection')
    run = flow.begin('shortcut')
    uncertain = dict(verified, state='ATTEMPTED', action='shortcut')
    flow.feed(run, 'RESULT: ' + json.dumps(uncertain))
    flow.finish(run, 2)
    if flow.state != 'NEEDS_REVIEW' or flow.can_service:
        raise RuntimeError('Uncertain writer was not blocked')
    backend_prefixes = ('usb', 'a6700win', 'app_backend', 'a6700_unlock',
                        'tools.legacy_sparse_session', 'tools.inspect_legacy_customizer',
                        'apps.a6700_customizer.app_backend')
    imported = {name for name in set(sys.modules) - before
                if any(name == prefix or name.startswith(prefix + '.')
                       for prefix in backend_prefixes)}
    if imported:
        raise RuntimeError('Offline workflow imported a backend')
    return {'status': 'OFFLINE_PLAYBACK_WORKFLOW_SELF_CHECK_PASSED', 'synthetic': True,
            'cases': 4, 'camera_commands': 0, 'backend_imports': 0}
