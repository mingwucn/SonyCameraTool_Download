"""Non-waiting Windows mutex for cooperating camera service operations."""
from contextlib import contextmanager
import ctypes
from ctypes import wintypes
import sys

MUTEX_NAME = r'Local\SonyA6700ResearchServiceOperation'
ERROR_ALREADY_EXISTS = 183


class ServiceOperationBusy(RuntimeError):
    """Another cooperating process already holds the service-operation mutex."""


@contextmanager
def service_operation_lock():
    """Acquire once, or fail immediately; release and close even on errors.

    This protects cooperating processes in the same Windows logon session only.
    It does not prevent unrelated tools from opening or changing the camera.
    """
    if sys.platform != 'win32':
        raise RuntimeError('The service-operation lock requires Windows')
    kernel = ctypes.WinDLL('kernel32', use_last_error=True)
    kernel.CreateMutexW.argtypes = [ctypes.c_void_p, wintypes.BOOL, wintypes.LPCWSTR]
    kernel.CreateMutexW.restype = wintypes.HANDLE
    kernel.ReleaseMutex.argtypes = [wintypes.HANDLE]
    kernel.ReleaseMutex.restype = wintypes.BOOL
    kernel.CloseHandle.argtypes = [wintypes.HANDLE]
    kernel.CloseHandle.restype = wintypes.BOOL
    ctypes.set_last_error(0)
    handle = kernel.CreateMutexW(None, True, MUTEX_NAME)
    error = ctypes.get_last_error()
    if not handle:
        raise ctypes.WinError(error)
    if error == ERROR_ALREADY_EXISTS:
        kernel.CloseHandle(handle)
        raise ServiceOperationBusy('Another cooperating camera service operation is running')
    try:
        yield
    finally:
        try:
            if not kernel.ReleaseMutex(handle):
                raise ctypes.WinError(ctypes.get_last_error())
        finally:
            if not kernel.CloseHandle(handle):
                raise ctypes.WinError(ctypes.get_last_error())
