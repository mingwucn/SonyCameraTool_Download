"""Pure alpha6700 projection for the shared A7CR Camera Workbench shell.

This adapter describes the existing extras workflow. It never qualifies a
patch, opens a camera, changes workflow state or interprets a byte write as a
working playback filter.
"""
from camera_pipeline.presentation import (
    Action, CameraPresentationAdapter, Profile, WorkbenchSnapshot,
)


FILTER_REASON = (
    "An offline FTP filtering prototype can be prepared in Advanced. Camera "
    "installation is unavailable while App, loader and write-profile qualification is pending."
)


class PlaybackExtrasPresentation(CameraPresentationAdapter):
    def present(self, context, *, language="en"):
        state = context["state"]
        busy = context["busy"]
        conditions = context["conditions"]
        selected = context["selected_folder"]
        if (state not in ("READY", "RUNNING", "ACK_REQUIRED", "NEEDS_REVIEW")
                or type(busy) is not bool or type(conditions) is not bool
                or type(selected) is not str):
            raise ValueError("An existing extras workflow state is required")
        idle = not busy and state == "READY"
        if busy or state == "RUNNING":
            heading, tone = "One operation is running", "info"
            next_action = Action("activity", "View activity")
        elif state == "NEEDS_REVIEW":
            heading, tone = "Review required", "warning"
            next_action = Action("activity", "View activity")
        elif state == "ACK_REQUIRED":
            heading, tone = "Check the camera after the operation", "warning"
            next_action = Action("features", "View camera conditions")
        elif not conditions:
            heading, tone = "Confirm the camera conditions", "neutral"
            next_action = Action("features", "View camera conditions")
        elif selected:
            heading, tone = "Completed inspection selected", "info"
            next_action = Action("features", "Review one change")
        else:
            heading, tone = "Ready for an explicit inspection", "neutral"
            next_action = Action("inspect", "Read playback state", idle)
        connection = context.get("connection")
        reason = connection.get("reason", "Host check completed") if type(connection) is dict else "Not checked"
        observations = (
            ("Profile", "ILCE-6700 / Body 2.00 (selected profile)"),
            ("Windows USB check", reason),
            ("Camera conditions", "Owner confirmed" if conditions else "Not confirmed"),
            ("Saved inspection", "Selected" if selected else "None selected"),
        )
        return WorkbenchSnapshot(
            state=state, heading=heading, message=context["message"],
            profiles=(Profile("a6700", "Sony α6700 · Body 2.00"),),
            selected_profile="a6700", observations=observations,
            next_action=next_action, feature_title="Playback FTP extras",
            feature_message=("Shortcut and label are separate experimental changes. "
                             "A readback verifies bytes; camera behavior needs a physical check."),
            feature_actions=(Action("filter", "Playback FTP filtering", False, FILTER_REASON),),
            activity=tuple(context.get("activity", ())),
            technical_result=context.get("technical_result", ""),
            busy=busy, status=context["message"], tone=tone, language=language,
        )
