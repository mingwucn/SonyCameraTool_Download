"""Generate fixed playback extras profiles and action-specific App policies."""
from apps.a6700_customizer.targets import APPFW_SHA256, APPFW_SIZE, TargetWindow
from tools import playback_extras_candidate as candidate
from tools import playback_menu_native_profile as existing


def profile_header(action):
    candidate.profile_digest(action)
    definition = candidate.profile_definition(action)
    rows, changes = [], []
    for entry in definition["entries"]:
        rows.append((entry["offset"], entry["profile_index"], len(changes), len(entry["changes"])))
        changes.extend((item["position"], item["before"], item["after"]) for item in entry["changes"])
    expected = {"shortcut": (1, 2), "label": (2, 4), "general_transfer": (1, 1)}[action]
    if (len(rows), len(changes)) != expected:
        raise ValueError("Unexpected playback extras profile dimensions")
    return ("/* Fixed independent playback extras profile; not physical geometry proof. */\n"
            '#include "ftp_wbi_experimental_core.h"\n'
            f"#define EXTRAS_ACTION {candidate.ACTION_IDS[action]}u\n"
            f"#define EXTRAS_TARGET_COUNT {len(rows)}u\n"
            f"#define EXTRAS_CHANGE_COUNT {len(changes)}u\n"
            f"#define EXTRAS_REQUEST_BYTES (56u+{len(rows)}u*1024u)\n"
            "static const uint8_t PROFILE_DIGEST[32]={" +
            ",".join(str(value) for value in candidate.profile_digest(action)) + "};\n"
            "static const struct ftp_wbi_target TARGETS[]={\n" +
            "".join(f" {{{offset}ULL,{index}u,{first}u,{count}u}},\n"
                    for offset, index, first, count in rows) +
            "};\nstatic const struct ftp_wbi_change CHANGES[]={\n" +
            "".join(f" {{{position}u,{old}u,{new}u}},\n" for position, old, new in changes) +
            "};\nstatic const struct ftp_wbi_profile FTP_PROFILE={TARGETS,CHANGES,PROFILE_DIGEST," +
            f"{len(rows)}u,{len(changes)}u" + "};\n")


def compatibility_targets(action="shortcut"):
    candidate.profile_digest(action)
    added = [
        TargetWindow(0x03788E52, b"\0\0", b"\1\1", "Playback FTP shortcut assignment categories", "ftp"),
        TargetWindow(0x04C36B8C, candidate.OLD_TITLE_RID.to_bytes(4, "little"),
                     candidate.NEW_TITLE_RID.to_bytes(4, "little"), "FTP transferred-image title RID", "ftp")]
    if action == "general_transfer":
        added.append(TargetWindow(0x03788DC3, b"\0", b"\1",
                                  "FTP Transfer C1/C2 category 21", "ftp"))
    elif action not in candidate.LEGACY_ACTIONS:
        raise ValueError("Unknown playback extras App policy")
    fields = tuple(sorted((*existing.compatibility_targets(), *added),
        key=lambda item: item.offset))
    expected_count = 100 if action == "general_transfer" else 99
    if len(fields) != expected_count:
        raise ValueError("The dedicated playback extras App policy has an unexpected field count")
    previous = 0
    for item in fields:
        if (not 1 <= len(item.preimage) <= 4 or len(item.preimage) != len(item.patched) or
                item.offset < previous or item.offset + len(item.preimage) > APPFW_SIZE):
            raise ValueError("Invalid or overlapping playback extras App fields")
        previous = item.offset + len(item.preimage)
    return fields


def guard_header(action="shortcut"):
    def values(raw):
        return "{" + ",".join(str(value) for value in raw) + "}"
    fields = compatibility_targets(action)
    return (f"/* Dedicated {len(fields)}-field normalization; English and unrelated bytes are never rewritten. */\n"
            '#include "ftp_app_guard.h"\n'
            f"#define FTP_GUARD_APP_SIZE {APPFW_SIZE}ULL\n"
            "static const struct ftp_guard_field ftp_guard_fields[]={\n" +
            "".join(f" {{{item.offset}ULL,{len(item.preimage)}u,{values(item.preimage)},{values(item.patched)}}},\n"
                    for item in fields) +
            "};\nstatic const uint8_t ftp_guard_expected[32]=" +
            values(bytes.fromhex(APPFW_SHA256)) + ";\n")
