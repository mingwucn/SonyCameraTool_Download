"""Explicit A6700 Windows connection diagnostics and one-shot WinUSB setup.

Importing this module has no device, process or filesystem side effects. PnP
diagnostics run only on explicit calls. Driver installation is a separate action
with a durable private job, owner approval, fresh target checks and optional UAC
handoff. The inherited alpha6700 driver module is never imported.
"""
from __future__ import annotations

from datetime import datetime, timezone
import ctypes
from ctypes import wintypes
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import stat
import subprocess
import sys
import tempfile
import time
import uuid

from tools import driver_local_files as core
from tools.service_operation_lock import ServiceOperationBusy, service_operation_lock

MODEL = "ILCE-6700"
VENDOR = 0x054C
NORMAL_PID = 0x0E76
SERVICE_PID = 0x0336
PINNED_WDI_SHA256 = "27b6d9847d874674b7c412af124acf64b0b1efa397e3bbea8eab9950a6a08ee0"
PINNED_MANIFEST_SHA256 = "48c0300998dfdfb6fab00228773404fe1df237efe3a3379227d9c5fc79d06149"
_HEX = re.compile(r"^[a-f0-9]{64}$")


class DriverError(RuntimeError):
    """Refused or uncertain driver action; retained job needs review."""


def _now():
    return datetime.now(timezone.utc).isoformat()


def _sha(data):
    return hashlib.sha256(data).hexdigest()


def _read(path, limit=1024 * 1024):
    _, _, digest, data = core._consume(Path(path), limit, retain=True)
    return data, digest


def _directory(path, durable=False):
    path = Path(os.path.abspath(path))
    core._local_name(path)
    for part in (path, *path.parents):
        st = part.lstat()
        if not stat.S_ISDIR(st.st_mode) or stat.S_ISLNK(st.st_mode) or getattr(st, "st_file_attributes", 0) & 0x400:
            raise DriverError("Use existing ordinary local directories")
    if durable:
        temporary = Path(tempfile.gettempdir()).resolve()
        if path == temporary or temporary in path.parents:
            raise DriverError("Driver jobs must be retained outside Temp")
    return path


def _json_new(path, data):
    try:
        path = core._destination(Path(path))
    except (OSError, ValueError) as exc:
        raise DriverError("Retained driver record already exists or cannot be created") from exc
    raw = (json.dumps(data, sort_keys=True, indent=2) + "\n").encode("utf-8")
    with path.open("xb") as stream:
        stream.write(raw); stream.flush(); os.fsync(stream.fileno())
    if _read(path, max(1024 * 1024, len(raw)))[0] != raw:
        raise DriverError("Retained driver record readback disagrees")
    return _sha(raw)


def _event(job, event, **fields):
    path = job / "audit.jsonl"
    if path.exists():
        core._ordinary(path)
    with path.open("a", encoding="utf-8", newline="\n") as stream:
        stream.write(json.dumps(dict(utc=_now(), event=event, **fields), sort_keys=True) + "\n")
        stream.flush(); os.fsync(stream.fileno())


def _status(job, request, state, **fields):
    data = dict(schema_version=1, job_id=request["job_id"], state=state, utc=_now(), **fields)
    path = job / "progress.json"
    if path.exists():
        core._ordinary(path)
    temporary = job / ("progress-" + uuid.uuid4().hex + ".json")
    _json_new(temporary, data)
    os.replace(temporary, path)


def validate_assets(libwdi_root):
    """Validate project-local libwdi bytes without running them or opening USB."""
    root = _directory(libwdi_root)
    raw, manifest_sha = _read(root / "manifest.json")
    if manifest_sha != PINNED_MANIFEST_SHA256:
        raise DriverError("Driver manifest differs from its trusted source pin")
    manifest = json.loads(raw)
    files = manifest.get("files") if isinstance(manifest, dict) else None
    if not isinstance(manifest, dict) or manifest.get("schema_version") != 1 or not isinstance(files, dict) or not files or len(files) > 256:
        raise DriverError("Invalid pinned libwdi inventory")
    entries = list(root.rglob("*"))
    for path in entries:
        if path.is_symlink() or getattr(path.lstat(), "st_file_attributes", 0) & 0x400:
            raise DriverError("Driver assets cannot contain links or reparse paths")
    observed = {p.relative_to(root).as_posix(): p for p in entries if p.is_file() and p != root / "manifest.json"}
    if observed.keys() != files.keys():
        raise DriverError("Project-local libwdi inventory differs from its manifest")
    for name, digest in files.items():
        relative = Path(name)
        if (not isinstance(name, str) or relative.is_absolute() or ".." in relative.parts
                or "\\" in name or ":" in name or not isinstance(digest, str) or not _HEX.fullmatch(digest)):
            raise DriverError("Invalid libwdi manifest path or digest")
        if _read(root / relative, 64 * 1024 * 1024)[1] != digest:
            raise DriverError("Pinned libwdi component changed")
    if files.get("wdi-simple.exe") != PINNED_WDI_SHA256:
        raise DriverError("Unrecognized libwdi executable")
    helper, _ = _read(root / "wdi-simple.exe", 16 * 1024 * 1024)
    if helper[:2] != b"MZ":
        raise DriverError("Driver helper is not a Windows executable")
    return dict(root=str(root), manifest_sha256=manifest_sha, files=files,
                helper_sha256=PINNED_WDI_SHA256, verified=True)


# Present PnP devnodes are OS metadata. This query does not open a camera USB
# interface, authenticate service mode, install a driver or change properties.
_PNP_SCRIPT = r"""
$ErrorActionPreference='Stop'
[Console]::OutputEncoding=[System.Text.UTF8Encoding]::new($false)
function ReadProp($id,$key) {
    try { return (Get-PnpDeviceProperty -InstanceId $id -KeyName $key -ErrorAction Stop).Data }
    catch { return $null }
}
$rows=@(Get-PnpDevice -PresentOnly -ErrorAction Stop | Where-Object {
    $_.InstanceId -match '^USB\\VID_054C&PID_[0-9A-F]{4}\\' -and $_.InstanceId -notmatch '&MI_'
} | ForEach-Object {
    $id=$_.InstanceId
    $loc=@(ReadProp $id 'DEVPKEY_Device_LocationPaths')
    [pscustomobject]@{instance_id=$id; present=$true;
       service=[string](ReadProp $id 'DEVPKEY_Device_Service');
       inf=[string](ReadProp $id 'DEVPKEY_Device_DriverInfPath');
       bus_description=[string](ReadProp $id 'DEVPKEY_Device_BusReportedDeviceDesc');
       friendly_name=[string]$_.FriendlyName;
       location_path=if($loc.Count){[string]$loc[0]}else{''}; status=[string]$_.Status}
})
ConvertTo-Json -InputObject @{available=$true;devices=$rows} -Depth 4 -Compress
"""


def windows_snapshot():
    if sys.platform != "win32":
        return dict(available=False, devices=[], reason="Windows PnP diagnostics are unavailable")
    shell = Path(os.environ["SystemRoot"]) / "System32/WindowsPowerShell/v1.0/powershell.exe"
    result = subprocess.run([str(shell), "-NoProfile", "-NonInteractive", "-Command", _PNP_SCRIPT],
                            capture_output=True, timeout=30, creationflags=0x08000000)
    if result.returncode or len(result.stdout) > 1024 * 1024:
        raise DriverError("Windows PnP query failed; no driver action was attempted")
    raw = result.stdout
    if raw.startswith(b"\xff\xfe"):
        text = raw.decode("utf-16")
    else:
        text = raw.decode("utf-8-sig")
    result = json.loads(text)
    if not isinstance(result, dict) or not isinstance(result.get("devices"), list):
        raise DriverError("Unexpected PnP diagnostic response")
    return result


def _snapshot(provider):
    value = (provider or windows_snapshot)()
    if not isinstance(value, dict) or value.get("available") is not True or not isinstance(value.get("devices"), list):
        raise DriverError("Present PnP inventory is unavailable")
    rows = []
    for row in value["devices"]:
        if not isinstance(row, dict) or row.get("present") is not True:
            continue
        identity = row.get("instance_id", "")
        match = re.fullmatch(r"USB\\VID_054C&PID_([0-9A-F]{4})\\[^\\]+", identity, re.I)
        if not match:
            continue
        item = {key: str(row.get(key, "")) for key in
                ("instance_id", "service", "inf", "bus_description", "friendly_name", "location_path", "status")}
        item["pid"] = int(match.group(1), 16)
        item["device_token"] = _sha((identity.upper() + "|" + item["location_path"]).encode("utf-8"))
        item["location_token"] = _sha(item["location_path"].encode("utf-8"))
        rows.append(item)
    return rows


def _target(rows, pid, service_binding=None):
    if pid != NORMAL_PID:
        raise DriverError("Only A6700 normal storage PID 0E76 is supported; shared service PID 0336 is not qualified")
    if len(rows) != 1 or rows[0]["pid"] != pid:
        raise DriverError("Connect exactly one qualifying Sony camera in the selected mode")
    row = rows[0]
    if row["status"].casefold() != "ok":
        raise DriverError("Selected Windows PnP device is not healthy (status OK is required)")
    if not row["location_path"]:
        raise DriverError("Stable USB location metadata is required")
    if not re.fullmatch(r"[A-Za-z0-9_.-]+\.inf", row["inf"]):
        raise DriverError("Original Windows INF identity is unavailable")
    if pid == NORMAL_PID and row["bus_description"].strip() != MODEL:
        raise DriverError("PnP bus-reported model is not the exact A6700")
    return row


def _public(row):
    return dict(hardware_id="USB\\VID_054C&PID_%04X" % row["pid"], pid=row["pid"],
                model=MODEL if row["pid"] == NORMAL_PID and row["bus_description"].strip() == MODEL
                      else "ILCE-7CR (not a driver target)" if row["pid"] == 0x0E86 and row["bus_description"].strip() == "ILCE-7CR"
                      else "unverified shared service interface" if row["pid"] == SERVICE_PID else "unverified Sony model",
                current_service=row["service"], current_inf=row["inf"], device_token=row["device_token"],
                location_token=row["location_token"])


def check_connection(*, snapshot_provider=None, service_binding=None):
    """Read present Windows metadata; return no raw device-instance identifiers."""
    try:
        rows = _snapshot(snapshot_provider)
    except (OSError, ValueError, DriverError, subprocess.SubprocessError) as exc:
        return dict(status="unavailable", available=False, driver_install_available=False,
                    service_access_ready=False, devices=[], reason=str(exc))
    base = dict(available=True, driver_install_available=False, service_access_ready=False,
                devices=[_public(row) for row in rows])
    if not rows:
        return dict(base, status="no_camera", reason="No present Sony USB camera was found")
    if len(rows) != 1:
        return dict(base, status="ambiguous", reason="More than one Sony USB device is present")
    row = rows[0]
    base.update(device_token=row["device_token"], target=_public(row))
    try:
        _target(rows, row["pid"], service_binding)
    except DriverError as exc:
        return dict(base, status="unsupported_service" if row["pid"] == SERVICE_PID else "device_model_unverified", reason=str(exc))
    ready = row["service"].casefold() == "winusb"
    base.update(driver_install_available=not ready, service_access_ready=ready)
    return dict(base, status="ready" if ready else "driver_required",
                reason="WinUSB is already bound" if ready else "The selected camera needs an explicitly selected WinUSB binding")


def prepare_driver(check, dependency_root, state_root, *, target_pid=NORMAL_PID,
                   snapshot_provider=None, service_binding=None):
    """Prepare a concrete retained private plan; performs no driver installation."""
    state = _directory(state_root, durable=True)
    if (state / "a6700-driver.lock").exists():
        raise DriverError("An uncertain driver job is locked; review retained state before another action")
    if not isinstance(check, dict) or check.get("driver_install_available") is not True:
        raise DriverError("A fresh connection check must show this driver change is needed")
    target = _target(_snapshot(snapshot_provider), target_pid, service_binding)
    if target["device_token"] != check.get("device_token"):
        raise DriverError("Camera identity changed since the displayed connection check")
    if target["service"].casefold() == "winusb":
        raise DriverError("WinUSB is already bound; refresh the connection check")
    assets = validate_assets(Path(dependency_root) / "driver/libwdi")
    job = state / ("driver-" + uuid.uuid4().hex)
    job.mkdir()
    copy = job / "libwdi"
    shutil.copytree(assets["root"], copy)
    if validate_assets(copy)["manifest_sha256"] != assets["manifest_sha256"]:
        raise DriverError("Private driver payload copy disagrees")
    restore = dict(original_service=target["service"], original_inf=target["inf"],
                   device_instance_id=target["instance_id"], hardware_id=_public(target)["hardware_id"],
                   automatic_restore=False,
                   procedure="For normal USBSTOR, use Windows Device Manager's explicit driver selection to restore USB Mass Storage Device / usbstor.inf for this exact devnode. No driver removal is automated.",
                   limitations="This retained metadata is not a driver-store export or proof that Windows can restore the binding.")
    _json_new(job / "original-driver.json", restore)
    request = dict(schema_version=1, job_id=job.name, created_utc=_now(), target=target,
                   target_pid=target_pid, service_binding=service_binding,
                   manifest_sha256=assets["manifest_sha256"], model=MODEL,
                   state_root=str(state), action="bind_winusb", automatic_retry=False)
    request_sha = _json_new(job / "request.json", request)
    _event(job, "PLAN_PREPARED", request_sha256=request_sha, target=_public(target))
    return dict(status="prepared", job_id=job.name, request_path=str(job / "request.json"),
                request_sha256=request_sha, target=_public(target), audit_path=str(job / "audit.jsonl"),
                original_driver_record=str(job / "original-driver.json"), driver_changed=False)


def _request(request_path):
    path = Path(os.path.abspath(request_path))
    if path.name != "request.json":
        raise DriverError("Use an exact retained driver request")
    job = _directory(path.parent, durable=True)
    raw, digest = _read(path)
    request = json.loads(raw)
    if (not isinstance(request, dict) or request.get("schema_version") != 1
            or request.get("job_id") != job.name or request.get("model") != MODEL
            or request.get("action") != "bind_winusb" or request.get("automatic_retry") is not False
            or Path(request.get("state_root", "")).absolute() != job.parent
            or request.get("target_pid") != NORMAL_PID):
        raise DriverError("Driver request binding is invalid")
    assets = validate_assets(job / "libwdi")
    if assets["manifest_sha256"] != request.get("manifest_sha256"):
        raise DriverError("Approved driver payload identity changed")
    return job, request, digest


def is_admin():
    return sys.platform == "win32" and bool(ctypes.windll.shell32.IsUserAnAdmin())


def driver_arguments(helper, pid, destination):
    if pid != NORMAL_PID:
        raise DriverError("Driver target PID is outside the A6700 allowlist")
    return [str(helper), "--vid", "0x054C", "--pid", "0x%04X" % pid, "--type", "0",
            "--name", "Sony A6700 - Storage",
            "--dest", str(destination), "--log", "0"]


def _run_helper(command, *, cwd, timeout, output_path):
    with Path(output_path).open("xb") as output:
        process = subprocess.Popen(command, cwd=cwd, stdout=output, stderr=subprocess.STDOUT,
                                   creationflags=0x08000000 if sys.platform == "win32" else 0)
        try:
            return dict(returncode=process.wait(timeout=timeout), timed_out=False)
        except subprocess.TimeoutExpired:
            # Keep the service mutex while the helper remains alive; never kill
            # it or launch another one. The eventual result remains uncertain.
            eventual = process.wait()
            return dict(returncode=None, timed_out=True, process_id=process.pid,
                        eventual_returncode=eventual)


def install_driver(plan, owner_approval_text, progress=lambda _s: None, *,
                   snapshot_provider=None, runner=None, admin_check=None, timeout=300):
    """Record explicit approval, then execute or return a separate UAC handoff."""
    if not isinstance(plan, dict) or not isinstance(owner_approval_text, str) or not owner_approval_text.strip():
        raise DriverError("Review the exact driver plan and supply explicit owner approval")
    job, request, digest = _request(plan.get("request_path", ""))
    if digest != plan.get("request_sha256") or request["job_id"] != plan.get("job_id"):
        raise DriverError("Displayed driver plan no longer matches its retained request")
    target = _target(_snapshot(snapshot_provider), request["target_pid"], request.get("service_binding"))
    if target["device_token"] != request["target"]["device_token"]:
        raise DriverError("Camera changed before driver approval")
    _json_new(job / "approval.json", dict(job_id=request["job_id"], request_sha256=digest,
              owner_approval_text=owner_approval_text, approved_utc=_now()))
    _event(job, "OWNER_APPROVAL_RECORDED", request_sha256=digest)
    if not (admin_check or is_admin)():
        progress("Administrator approval is required; use the separate UAC handoff action")
        return dict(status="requires_elevation", request_path=str(job / "request.json"),
                    job_id=job.name, driver_changed=False, automatic_retry=False)
    return execute_job(job / "request.json", snapshot_provider=snapshot_provider,
                       runner=runner, admin_check=admin_check, timeout=timeout, progress=progress)


def execute_job(request_path, dependency_root=None, *, snapshot_provider=None,
                runner=None, admin_check=None, timeout=300, progress=lambda _s: None):
    """Hold the shared service mutex in the actual elevated worker process."""
    entered = False
    try:
        with service_operation_lock():
            entered = True
            return _execute_job_locked(request_path, dependency_root, snapshot_provider=snapshot_provider,
                                       runner=runner, admin_check=admin_check, timeout=timeout, progress=progress)
    except ServiceOperationBusy:
        if entered:
            raise
        # The waiter requires a request-bound terminal record. Never replace an
        # existing result or interfere with a job whose execution has started.
        job, request, digest = _request(request_path)
        if not any((job / name).exists() for name in
                   ("execution-attempt.json", "failure.json", "result.json", "completion.json")):
            _json_new(job / "failure.json", dict(
                status="needs_review", ok=False, verified=False, job_id=request["job_id"],
                request_sha256=digest, driver_change_may_have_executed=False,
                reason="Another cooperating camera service operation is running",
                automatic_retry=False, audit_path=str(job / "audit.jsonl")))
        raise


def _execute_job_locked(request_path, dependency_root=None, *, snapshot_provider=None,
                        runner=None, admin_check=None, timeout=300, progress=lambda _s: None):
    """Admin-worker entry. At most one helper launch; no install during import."""
    if type(timeout) not in (int, float) or not 1 <= timeout <= 600:
        raise DriverError("Invalid bounded driver-install timeout")
    job, request, digest = _request(request_path)
    if (job / "failure.json").exists() or (job / "result.json").exists() or (job / "completion.json").exists():
        raise DriverError("This driver job already has a terminal record; no execution is permitted")
    if dependency_root is not None:
        if validate_assets(Path(dependency_root) / "driver/libwdi")["manifest_sha256"] != request["manifest_sha256"]:
            raise DriverError("Project-local driver assets changed since plan preparation")
    approval = json.loads(_read(job / "approval.json")[0])
    if (approval.get("request_sha256") != digest or approval.get("job_id") != job.name
            or not isinstance(approval.get("owner_approval_text"), str) or not approval["owner_approval_text"].strip()):
        raise DriverError("Exact owner approval is missing")
    if not (admin_check or is_admin)():
        raise DriverError("Administrator worker is required; no helper was launched")
    _json_new(job / "execution-attempt.json", dict(job_id=job.name, request_sha256=digest, utc=_now()))
    lock = job.parent / "a6700-driver.lock"
    lock_record = dict(job_id=job.name, request_sha256=digest)
    _json_new(lock, lock_record)
    may_have_changed = False
    try:
        _status(job, request, "checking_exact_target")
        target = _target(_snapshot(snapshot_provider), request["target_pid"], request.get("service_binding"))
        if target["device_token"] != request["target"]["device_token"]:
            raise DriverError("Camera changed immediately before driver installation")
        if target["service"].casefold() == "winusb":
            result = dict(status="already_ready", ok=True, driver_changed=False, verified=True)
        else:
            if (target["service"] != request["target"]["service"] or target["inf"] != request["target"]["inf"]):
                raise DriverError("Original driver binding changed before installation")
            output = job / "generated-driver"
            output.mkdir()
            command = driver_arguments(job / "libwdi/wdi-simple.exe", request["target_pid"], output)
            _event(job, "HELPER_EXECUTION_INTENT", target=_public(target), command_pid=request["target_pid"])
            _status(job, request, "installing_winusb")
            progress("Installing the exact selected A6700 WinUSB driver once")
            may_have_changed = True
            completed = (runner or _run_helper)(command, cwd=job / "libwdi", timeout=timeout,
                                                output_path=job / "helper-output.log")
            _event(job, "HELPER_RETURNED", result=completed)
            if (not isinstance(completed, dict) or completed.get("timed_out") is not False
                    or completed.get("returncode") != 0):
                raise DriverError("Driver helper result is failed or uncertain; no retry or termination was performed")
            after = _target(_snapshot(snapshot_provider), request["target_pid"], request.get("service_binding"))
            if after["device_token"] != target["device_token"] or after["service"].casefold() != "winusb":
                raise DriverError("Fresh PnP readback did not confirm WinUSB on the exact target")
            result = dict(status="driver_verified", ok=True, driver_changed=True, verified=True,
                          target=_public(after))
        result.update(job_id=job.name, request_sha256=digest, automatic_retry=False,
                      audit_path=str(job / "audit.jsonl"), original_driver_record=str(job / "original-driver.json"))
        result_sha = _json_new(job / "result.json", result)
        _status(job, request, result["status"])
        _event(job, "JOB_COMPLETE", status=result["status"])
        _json_new(job / "completion.json", dict(job_id=job.name, request_sha256=digest,
                  result_sha256=result_sha, utc=_now()))
        if json.loads(_read(lock)[0]) != lock_record:
            raise DriverError("Driver lock changed; preserve all job state")
        lock.unlink()
        return result
    except Exception as exc:
        _event(job, "NEEDS_REVIEW", reason=str(exc), driver_change_may_have_executed=may_have_changed,
               retry_performed=False, rollback_performed=False)
        result = dict(status="needs_review", ok=False, verified=False, job_id=job.name,
                      request_sha256=digest, driver_change_may_have_executed=may_have_changed,
                      reason=str(exc), automatic_retry=False, audit_path=str(job / "audit.jsonl"))
        if not (job / "result.json").exists():
            _json_new(job / "result.json", result)
        # A success candidate can predate an audit/readback/finalization error.
        # This terminal failure takes precedence; waiters also require the
        # completion binding and release of this job's uncertainty lock.
        _json_new(job / "failure.json", result)
        _status(job, request, "needs_review")
        raise DriverError("Stopped; driver state and lock retained at " + str(job) + ": " + str(exc)) from exc


def request_elevation(request_path, entrypoint=None):
    """Explicit owner UAC handoff; does not accept or automate the UAC prompt."""
    job, request, digest = _request(request_path)
    approval = json.loads(_read(job / "approval.json")[0])
    if approval.get("request_sha256") != digest:
        raise DriverError("Approve the exact plan before requesting elevation")
    if sys.platform != "win32":
        raise DriverError("UAC handoff is Windows-only")
    _json_new(job / "elevation-attempt.json", dict(job_id=job.name, request_sha256=digest, utc=_now()))
    if getattr(sys, "frozen", False):
        command = [sys.executable, "--driver-worker", str(job / "request.json")]
    else:
        source = Path(entrypoint) if entrypoint is not None else Path(__file__).resolve().parents[1] / "run_playback_probe_gui.py"
        core._ordinary(source)
        command = [sys.executable, str(source), "--driver-worker", str(job / "request.json")]
    class Info(ctypes.Structure):
        _fields_ = [("cbSize", wintypes.DWORD), ("fMask", wintypes.ULONG), ("hwnd", wintypes.HWND),
                    ("lpVerb", wintypes.LPCWSTR), ("lpFile", wintypes.LPCWSTR),
                    ("lpParameters", wintypes.LPCWSTR), ("lpDirectory", wintypes.LPCWSTR),
                    ("nShow", ctypes.c_int), ("hInstApp", wintypes.HINSTANCE), ("lpIDList", ctypes.c_void_p),
                    ("lpClass", wintypes.LPCWSTR), ("hkeyClass", wintypes.HKEY), ("dwHotKey", wintypes.DWORD),
                    ("hIcon", wintypes.HANDLE), ("hProcess", wintypes.HANDLE)]
    info = Info(); info.cbSize = ctypes.sizeof(info); info.fMask = 0x40
    info.lpVerb = "runas"; info.lpFile = command[0]
    info.lpParameters = subprocess.list2cmdline(command[1:]); info.lpDirectory = str(job); info.nShow = 0
    _event(job, "OWNER_UAC_HANDOFF_INTENT")
    shell = ctypes.WinDLL("shell32", use_last_error=True)
    shell.ShellExecuteExW.argtypes = [ctypes.POINTER(Info)]
    shell.ShellExecuteExW.restype = wintypes.BOOL
    if not shell.ShellExecuteExW(ctypes.byref(info)):
        _event(job, "UAC_HANDOFF_NOT_CONFIRMED", windows_error=ctypes.get_last_error())
        raise DriverError("Administrator handoff was cancelled or failed; no automatic retry")
    if info.hProcess:
        kernel = ctypes.WinDLL("kernel32", use_last_error=True)
        kernel.CloseHandle.argtypes = [wintypes.HANDLE]
        kernel.CloseHandle.restype = wintypes.BOOL
        kernel.CloseHandle(info.hProcess)
    return dict(status="administrator_handoff_started", job_id=job.name,
                request_path=str(job / "request.json"), user_must_handle_uac=True, automatic_retry=False)


def wait_for_job(request_path, progress=lambda _s: None, timeout=330):
    """Poll this retained job only; never relaunch, terminate or retry a helper."""
    if type(timeout) not in (int, float) or not 1 <= timeout <= 660:
        raise DriverError("Invalid driver-worker wait timeout")
    job, request, digest = _request(request_path)
    deadline = time.monotonic() + timeout
    previous = None
    while time.monotonic() < deadline:
        failure_path = job / "failure.json"
        if failure_path.exists():
            failure = json.loads(_read(failure_path)[0])
            if failure.get("job_id") != job.name or failure.get("request_sha256") != digest:
                raise DriverError("Worker failure is not bound to this reviewed request")
            raise DriverError("Driver job needs review at " + str(job))
        result_path = job / "result.json"
        if result_path.exists():
            raw, result_sha = _read(result_path)
            result = json.loads(raw)
            if result.get("job_id") != job.name or result.get("request_sha256") != digest:
                raise DriverError("Worker result is not bound to this reviewed request")
            if result.get("ok") is not True:
                raise DriverError("Driver job needs review at " + str(job))
            completion_path = job / "completion.json"
            if completion_path.exists():
                completion = json.loads(_read(completion_path)[0])
                if (completion.get("job_id") != job.name or completion.get("request_sha256") != digest
                        or completion.get("result_sha256") != result_sha):
                    raise DriverError("Worker completion does not match its verified result")
                lock = job.parent / "a6700-driver.lock"
                retained = lock.exists() and json.loads(_read(lock)[0]).get("job_id") == job.name
                if not retained:
                    return result
        progress_path = job / "progress.json"
        if progress_path.exists():
            state = json.loads(_read(progress_path)[0])
            if state.get("job_id") != job.name:
                raise DriverError("Unexpected driver progress binding")
            if state.get("state") != previous:
                previous = state.get("state"); progress(str(previous))
        time.sleep(0.25)
    raise DriverError("Administrator job outcome is not confirmed; retain this job and do not retry")
