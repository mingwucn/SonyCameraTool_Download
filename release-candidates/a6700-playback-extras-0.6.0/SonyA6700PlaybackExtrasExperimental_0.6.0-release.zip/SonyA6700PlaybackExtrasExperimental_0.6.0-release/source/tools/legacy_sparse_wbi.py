"""Offline adapter for the original customizer's fixed-profile sparse reader.

This module does not discover devices, send USB commands or install drivers.
Its persistence functions write to a caller-selected path; the caller must
verify that destination is private local storage, not a camera-mounted volume.
A caller must separately own and authorize the service session. A capture is
private, sparse evidence, not a WBI backup.
The upstream profile's device-to-decoded-WBI offset equality is an assumption.
The bundled reader opens all three configured devices, including CP at index 2,
and its sparse response contains all 260 profile sectors, not only WBI fields.
"""
from collections import Counter
from dataclasses import dataclass
import hashlib
from importlib.resources import files
import json
import os
from pathlib import Path
import secrets


PROFILE_SHA256 = 'c20d1b9ba7114ef1bc3cff3ae1787b5334ac899cc8f3aa806ec3bea3039db82f'
CATALOG_SHA256 = 'b17070239cd2829d0db2ac3d9e243429ce12bc124a6e08e8573e29d97329c39c'
SOURCE_SHA256 = '53cd3393c07dfdb7a219cf73906862ac389df9d853a90d762deec777c0e37e82'
READER_SHA256 = '88491c37c20fa4324023613e1980fd970adf79dd44ad4d7771afa43b9c9e4ece'
READER_BYTES = 26992
SECTOR_COUNT = 260
SECTOR_BYTES = 512
WBI_FTP_FIELDS = 152


@dataclass(frozen=True)
class SparseReadIntent:
    profile: object
    reader: bytes
    nonce: bytes
    request: bytes


def _validate_profile(profile):
    from a6700_unlock.catalog import Catalog
    from a6700_unlock.device_profile import DeviceProfile

    def canonical_hash(value):
        return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'),
                                         ensure_ascii=False).encode()).hexdigest()
    if (type(profile) is not DeviceProfile or type(profile.catalog) is not Catalog
            or profile.catalog.digest != CATALOG_SHA256 or canonical_hash(profile.catalog.data) != CATALOG_SHA256
            or profile.digest != PROFILE_SHA256 or canonical_hash(profile.data) != PROFILE_SHA256
            or len(profile.entries) != SECTOR_COUNT
            or profile.data['devices'] != ['/dev/nflasha15', '/dev/nflasha5', '/dev/nflasha8']
            or sum(e.image == 'wbi' and e.feature == 'ftp' for e in profile.catalog.edits) != WBI_FTP_FIELDS):
        raise ValueError('Unexpected sparse profile or catalog')
    # Frozen dataclasses still permit a forged `edits` tuple paired with valid
    # catalog.data. Reconstruct from the canonical data before trusting it.
    rebuilt_catalog = Catalog.from_dict(profile.catalog.data)
    if rebuilt_catalog.digest != CATALOG_SHA256 or rebuilt_catalog.edits != profile.catalog.edits:
        raise ValueError('Catalog fields do not match canonical catalog data')
    rebuilt_profile = DeviceProfile.from_dict(profile.data, rebuilt_catalog)
    if rebuilt_profile.digest != PROFILE_SHA256 or rebuilt_profile.data != profile.data:
        raise ValueError('Device profile does not match canonical profile data')


def load_reference():
    """Load and pin the exact existing bundle; source equivalence is not ELF proof."""
    from a6700_unlock.catalog import load_catalog
    from a6700_unlock.device_profile import load_device_profile

    catalog = load_catalog()
    profile = load_device_profile(catalog)
    _validate_profile(profile)
    root = files('a6700_unlock')
    manifest = json.loads(root.joinpath('data/native/manifest.json').read_text(encoding='utf-8'))
    source = root.joinpath('native/transaction.c').read_bytes().replace(b'\r\n', b'\n')
    reader = root.joinpath('data/native/reader.elf').read_bytes()
    if (manifest.get('profile_sha256') != PROFILE_SHA256 or manifest.get('source_sha256') != SOURCE_SHA256
            or hashlib.sha256(source).hexdigest() != SOURCE_SHA256
            or manifest.get('payloads', {}).get('reader', {}).get('sha256') != READER_SHA256
            or manifest.get('payloads', {}).get('reader', {}).get('bytes') != READER_BYTES
            or len(reader) != READER_BYTES or hashlib.sha256(reader).hexdigest() != READER_SHA256):
        raise ValueError('Sparse reader source, manifest or binary does not match the pinned bundle')
    return profile, reader


def prepare(profile, reader, *, nonce=None):
    """Build only the upstream A67Q read request; no I/O to camera occurs."""
    from a6700_unlock.device_protocol import REQUEST, request

    _validate_profile(profile)
    if (type(reader) is not bytes or len(reader) != READER_BYTES
            or hashlib.sha256(reader).hexdigest() != READER_SHA256):
        raise ValueError('Unpinned profile or reader')
    nonce = secrets.token_bytes(16) if nonce is None else nonce
    if type(nonce) is not bytes or len(nonce) != 16:
        raise ValueError('A 16-byte nonce is required')
    data = request(profile, nonce)
    if REQUEST.unpack(data) != (b'A67Q', 1, nonce, bytes.fromhex(PROFILE_SHA256)):
        raise ValueError('Unexpected non-read request')
    return SparseReadIntent(profile, reader, nonce, data)


def parse(intent, data):
    """Use the original parser, adding strict read-only completion checks."""
    from a6700_unlock.device_protocol import RESPONSE, response

    _validate_profile(intent.profile)
    if type(data) is not bytes or len(data) < RESPONSE.size:
        raise ValueError('Incomplete sparse reader response')
    magic, version, nonce, status, count, failed, touched, flags = RESPONSE.unpack_from(data)
    if (magic != b'A67R' or version != 1 or nonce != intent.nonce or status != 0
            or count != SECTOR_COUNT or failed != 0xffffffff or touched != 0 or flags != 0
            or len(data) != RESPONSE.size + SECTOR_COUNT * SECTOR_BYTES):
        raise ValueError('Unexpected, stale, failed or incomplete sparse reader response')
    parsed = response(data, intent.nonce, SECTOR_COUNT)
    sectors = tuple(parsed['sectors'])
    if len(sectors) != SECTOR_COUNT or any(type(s) is not bytes or len(s) != SECTOR_BYTES for s in sectors):
        raise ValueError('Incomplete sparse sectors')
    return sectors


def _write_verified(path, data):
    with path.open('xb') as output:
        if output.write(data) != len(data):
            raise OSError('Incomplete local capture write')
        output.flush()
        os.fsync(output.fileno())
    if path.read_bytes() != data:
        raise OSError('Local capture readback mismatch')


def persist(record_dir, intent, data):
    """Retain a complete validated response and metadata before service exit.

    The caller must ensure record_dir is a private, durable local directory and
    cannot resolve to a camera-mounted volume. This function does not verify it.
    Exclusive files are never overwritten or deleted. A failed or interrupted
    write must stop the session; callers retain any partial files for review.
    """
    parse(intent, data)
    record_dir = Path(record_dir)
    metadata = {'scope': 'SPARSE_READER_RESPONSE_NOT_FULL_BACKUP', 'profile_sha256': PROFILE_SHA256,
                'reader_sha256': READER_SHA256, 'nonce_hex': intent.nonce.hex(),
                'sector_count': SECTOR_COUNT, 'response_bytes': len(data),
                'response_sha256': hashlib.sha256(data).hexdigest(),
                'wbi_offset_mapping': 'UNVERIFIED_UPSTREAM_ASSUMPTION'}
    _write_verified(record_dir / 'sparse-response.bin', data)
    _write_verified(record_dir / 'sparse-response.json',
                    (json.dumps(metadata, sort_keys=True, indent=2) + '\n').encode('utf-8'))
    return metadata


def load_persisted(record_dir, profile, reader):
    """Revalidate a locally saved capture; consistency is not origin proof."""
    record_dir = Path(record_dir)
    metadata = json.loads((record_dir / 'sparse-response.json').read_bytes())
    data = (record_dir / 'sparse-response.bin').read_bytes()
    if not isinstance(metadata, dict):
        raise ValueError('Invalid capture metadata')
    try:
        nonce = bytes.fromhex(metadata['nonce_hex'])
    except (KeyError, TypeError, ValueError) as exc:
        raise ValueError('Invalid stored capture nonce') from exc
    expected = {'scope': 'SPARSE_READER_RESPONSE_NOT_FULL_BACKUP', 'profile_sha256': PROFILE_SHA256,
                'reader_sha256': READER_SHA256, 'nonce_hex': nonce.hex(),
                'sector_count': SECTOR_COUNT, 'response_bytes': len(data),
                'response_sha256': hashlib.sha256(data).hexdigest(),
                'wbi_offset_mapping': 'UNVERIFIED_UPSTREAM_ASSUMPTION'}
    if metadata != expected:
        raise ValueError('Sparse capture metadata or hash mismatch')
    intent = prepare(profile, reader, nonce=nonce)
    parse(intent, data)
    return intent, data


def classify(intent, data):
    """Count FTP values at assumed WBI positions; never infer a physical write."""
    from a6700_unlock import device_profile

    sectors = parse(intent, data)
    profile = intent.profile
    # The Windows customizer replaces this function with a timestamp-tolerant
    # wrapper. Keep this diagnostic strict and identify that choice explicitly.
    inspect_sectors = getattr(device_profile.inspect_sectors, '_a6700win_original',
                              device_profile.inspect_sectors)
    plan, unchanged = inspect_sectors(profile, list(sectors), action='inspect')
    if tuple(unchanged) != sectors:
        raise ValueError('Inspection unexpectedly proposed changes')
    rows = {(row['image'], row['file_offset']): row for row in profile.entries
            if row['role'] == 'target'}
    fields = [e for e in profile.catalog.edits if e.image == 'wbi' and e.feature == 'ftp']
    if len(fields) != WBI_FTP_FIELDS:
        raise ValueError('Unexpected WBI FTP field count')
    states = Counter()
    for edit in fields:
        try:
            actual = bytes(sectors[rows[('wbi', at // SECTOR_BYTES * SECTOR_BYTES)]['index']]
                           [at % SECTOR_BYTES] for at in range(edit.offset, edit.end))
        except (KeyError, IndexError) as exc:
            raise ValueError('WBI FTP field coverage is incomplete') from exc
        states[edit.state(actual)] += 1
    issue_types = Counter(issue['kind'] for issue in plan['issues'])
    return {'evidence': 'SPARSE_VALUES_AT_ASSUMED_WBI_MAPPING_NOT_IDENTITY_PROOF',
            'reference_profile_guard_compatible_assumed_mapping': plan['compatible'],
            'profile_issue_counts': dict(issue_types),
            'guard_policy': 'UPSTREAM_STRICT_NO_VOLATILE_EXCLUSIONS',
            'wbi_ftp_values_at_assumed_offsets': dict(states), 'wbi_ftp_fields': len(fields),
            'wbi_mapping': 'UNVERIFIED_UPSTREAM_ASSUMPTION', 'full_backup': False,
            'failed_start_recovery': 'UNVERIFIED', 'ftp_transfer': 'UNVERIFIED'}
