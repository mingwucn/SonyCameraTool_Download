"""A6700 selections over the shared workflow and existing CLI worker.

This adapter adds no camera engine. Preparation is pure; execution invokes the
injected runner once. The GUI retains its existing inspection/uncertainty state.
"""
import subprocess

from camera_pipeline.gui import WorkflowAdapter, WorkflowCommand


def _arguments(action, arguments):
    if (type(action) is not str or type(arguments) is not tuple
            or any(type(value) is not str for value in arguments)):
        raise ValueError("An immutable CLI argument tuple is required")
    if action == "inspect" and arguments == ("--inspect-playback-extras",):
        return arguments
    if action == "inspect_general" and arguments == ("--inspect-general-transfer",):
        return arguments
    if (action in ("shortcut", "label", "general_transfer") and len(arguments) == 5
            and arguments[:3] == ("--apply-playback-extras", action, "--inspection-record")
            and arguments[3] and not arguments[3].startswith("--")
            and arguments[4] == "--confirm-experimental-playback-extras"):
        return arguments
    raise ValueError("Select one exact playback inspection or reviewed extras command")


class PlaybackExtrasPipeline(WorkflowAdapter):
    def __init__(self, runner):
        if not callable(runner):
            raise TypeError("Inject the existing CLI runner")
        self._runner = runner

    def prepare(self, action, values):
        return WorkflowCommand(action, _arguments(action, values.get("arguments")))

    def execute(self, command, progress):
        if type(command) is not WorkflowCommand or command.state_dir is not None:
            raise ValueError("An exact playback workflow command is required")
        return self._runner(_arguments(command.action, command.arguments), progress)


def run_cli_worker(arguments, progress, *, command_prefix, popen=None):
    """Run the same CLI subprocess and confirm termination before completion."""
    process = None
    try:
        process = (subprocess.Popen if popen is None else popen)(
            list(command_prefix) + list(arguments), stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT, text=True, encoding="utf-8", errors="replace",
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        for line in process.stdout:
            progress(line)
        code = process.wait()
    except Exception as exc:
        progress("Worker failed: " + type(exc).__name__ + "\n")
        if process is not None:
            try:
                process.wait()
            except Exception as wait_error:
                return {"state": "worker_unconfirmed", "error_type": type(wait_error).__name__}
        return {"state": "worker_failed", "error_type": type(exc).__name__}
    return {"state": "done", "exit_code": code}


def workflow_event(event):
    """Keep the existing GUI's run IDs and stop/completion event semantics."""
    kind, run_id, value = event
    if kind == "progress":
        return "line", (run_id, value)
    if kind == "result" and type(value) is dict:
        if value.get("state") == "done" and type(value.get("exit_code")) is int:
            return "done", (run_id, value["exit_code"])
        if value.get("state") in ("worker_unconfirmed", "worker_failed"):
            return value["state"], (run_id, value.get("error_type", "WorkerError"))
    return "worker_failed", (run_id, value if kind == "error" else "InvalidWorkerResult")
