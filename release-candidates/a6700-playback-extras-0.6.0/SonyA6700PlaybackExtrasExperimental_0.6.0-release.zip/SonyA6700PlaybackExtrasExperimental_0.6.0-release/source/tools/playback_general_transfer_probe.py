"""Read-only service capture for the two App windows used by FTP Transfer.

The fixed profile is independent of the legacy seven-window/WBI probe. Every
capture reads exactly the 0x4c7 and 0x4a8 App windows; it never opens WBI and
never writes camera firmware or saved settings.
"""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import re
import secrets
import struct
import sys

if __name__ == "__main__":
    for shared_root in Path(__file__).resolve().parents:
        if (shared_root / "camera_pipeline").is_dir():
            sys.path.insert(0, str(shared_root))
            break

from tools import playback_extras_probe as legacy_probe
from tools import playback_general_transfer_reader as offline_reader

PROFILE = offline_reader.PROFILE
PROFILE_SHA256 = offline_reader.PROFILE_SHA256
REQUEST = struct.Struct("<4sI16s32s")
RESPONSE = struct.Struct("<4sI16sIIII")
WINDOW_BYTES = offline_reader.WINDOW_BYTES
WINDOW_COUNT = len(PROFILE["windows"])
SAVED_FILE_LIMITS = {"intent.json": 32768, "result.json": 32768,
                     "capture.json": 32768, "response.bin": RESPONSE.size + WINDOW_COUNT * WINDOW_BYTES,
                     "transport-UNVERIFIED.bin": 4 + RESPONSE.size + WINDOW_COUNT * WINDOW_BYTES}
PAYLOAD_SHA256 = "1248741c20ab76991d19c29c230b24924003e28c6197586b827841193ba8a642"
PAYLOAD_BYTES = 17544
PAYLOAD_PATH = (Path(__file__).resolve().parents[1] / ".data" /
                "playback-general-transfer-probe-native-20261111" /
                "playback_general_transfer_probe.elf")
STATUS_NAMES = {1: "STAGE_OPEN_FAILED", 2: "APP_READ_FAILED",
                3: "APP_CLOSE_FAILED", 4: "APP_PROFILE_FAILED"}


class ProbeFailure(ValueError):
    def __init__(self, status, count, failed):
        if status not in STATUS_NAMES:
            raise ValueError("Unknown general-transfer reader status")
        self.details = {"status": status, "reason": STATUS_NAMES[status],
                        # The helper's error response intentionally does not
                        # encode per-window progress, so do not guess an offset.
                        "completed_reads": None, "failed_read_index": None,
                        "path": "/usr/lib/appFw.so", "offset": None}
        super().__init__(STATUS_NAMES[status])


class CaptureRecordError(ValueError):
    def __init__(self, message):
        super().__init__(message)


def request(nonce):
    offline_reader.profile_bytes()
    if type(nonce) is not bytes or len(nonce) != 16 or nonce == bytes(16):
        raise ValueError("A fresh nonzero sixteen-byte nonce is required")
    return REQUEST.pack(b"A6XQ", 1, nonce, bytes.fromhex(PROFILE_SHA256))


def parse(data, nonce):
    request(nonce)
    if type(data) is bytes and len(data) == RESPONSE.size:
        magic, version, echoed, status, count, failed, flags = RESPONSE.unpack(data)
        if (magic == b"A6XR" and version == 1 and echoed == nonce and flags == 0 and
                status in STATUS_NAMES and count == 0 and failed == 0):
            raise ProbeFailure(status, count, failed)
    expected_length = RESPONSE.size + WINDOW_COUNT * WINDOW_BYTES
    if type(data) is not bytes or len(data) != expected_length:
        raise ValueError("Incomplete or oversized two-window App response")
    if RESPONSE.unpack_from(data) != (b"A6XR", 1, nonce, 0, WINDOW_COUNT, 0xFFFFFFFF, 0):
        raise ValueError("Stale, failed or unexpected two-window App response")
    body = data[RESPONSE.size:]
    return tuple(body[i * WINDOW_BYTES:(i + 1) * WINDOW_BYTES]
                 for i in range(WINDOW_COUNT))


def analyze(windows):
    if (type(windows) is not tuple or len(windows) != WINDOW_COUNT or
            any(type(item) is not bytes or len(item) != WINDOW_BYTES for item in windows)):
        raise ValueError("Exactly two complete App windows are required")
    by_offset = {spec["offset"]: windows[index]
                 for index, spec in enumerate(PROFILE["windows"])}
    analysis = offline_reader.parse_windows(by_offset)
    analysis["capture_method"] = "service_native_helper_read_only"
    analysis["window_sha256"] = [hashlib.sha256(item).hexdigest() for item in windows]
    analysis["read_windows"] = WINDOW_COUNT
    analysis["read_bytes"] = WINDOW_COUNT * WINDOW_BYTES
    return analysis


def _payload_pin_ready():
    if (type(PAYLOAD_SHA256) is not str or re.fullmatch(r"[0-9a-f]{64}", PAYLOAD_SHA256) is None or
            type(PAYLOAD_BYTES) is not int or PAYLOAD_BYTES <= 0):
        raise RuntimeError("General-transfer reader build pin is pending; no camera action started")


def load_payload():
    offline_reader.profile_bytes()
    _payload_pin_ready()
    data = PAYLOAD_PATH.read_bytes()
    if len(data) != PAYLOAD_BYTES or hashlib.sha256(data).hexdigest() != PAYLOAD_SHA256:
        raise RuntimeError("General-transfer reader differs from its pinned native build")
    return data


def _intent():
    return {"action": "ONE_GENERAL_TRANSFER_APP_READ", "profile": PROFILE,
            "profile_sha256": PROFILE_SHA256, "payload_sha256": PAYLOAD_SHA256,
            "bytes": WINDOW_COUNT * WINDOW_BYTES, "paths": ["/usr/lib/appFw.so"],
            "wbi_access": False, "persistent_firmware_write": False,
            "automatic_retry_or_driver_change": False, "full_backup": False,
            "body_identity": "OWNER_REPORT_NOT_AUTHENTICATED"}


def validate_saved_record(files):
    _payload_pin_ready()
    if type(files) is not dict or set(files) != set(SAVED_FILE_LIMITS):
        raise ValueError("Exactly five general-transfer capture files are required")
    for name, limit in SAVED_FILE_LIMITS.items():
        if type(files[name]) is not bytes or not 0 < len(files[name]) <= limit:
            raise ValueError("Invalid or oversized general-transfer capture file")
    intent = legacy_probe._saved_json(files["intent.json"])
    capture = legacy_probe._saved_json(files["capture.json"])
    report = legacy_probe._saved_json(files["result.json"])
    if legacy_probe._canonical(intent) != legacy_probe._canonical(_intent()):
        raise ValueError("Saved general-transfer intent/profile/payload mismatch")
    if set(capture) != {"profile_sha256", "payload_sha256", "nonce_hex",
                        "response_sha256", "analysis"}:
        raise ValueError("Unexpected saved general-transfer capture metadata")
    if (capture["profile_sha256"] != PROFILE_SHA256 or
            capture["payload_sha256"] != PAYLOAD_SHA256 or
            type(capture["nonce_hex"]) is not str or
            re.fullmatch(r"[0-9a-f]{32}", capture["nonce_hex"]) is None):
        raise ValueError("Saved general-transfer profile or nonce mismatch")
    nonce = bytes.fromhex(capture["nonce_hex"])
    raw = files["response.bin"]
    if (capture["response_sha256"] != hashlib.sha256(raw).hexdigest() or
            files["transport-UNVERIFIED.bin"] != bytes(4) + raw):
        raise ValueError("Saved general-transfer response/transport mismatch")
    windows = parse(raw, nonce)
    summary = analyze(windows)
    if legacy_probe._canonical(capture["analysis"]) != legacy_probe._canonical(summary):
        raise ValueError("Saved general-transfer analysis mismatch")
    required = {"status", "probe_state", "capture", "service_attempted", "service_exit",
                "stage", "stop_error", "camera_state_uncertain", "firmware_written",
                "normal_camera_and_english", "automatic_retry"}
    if (not required <= set(report) or set(report) - required - {"error_chain", "native_failure"} or
            report["status"] != "PERSISTED" or report["probe_state"] != "PERSISTED" or
            report["service_attempted"] is not True or report["camera_state_uncertain"] is not True or
            report["firmware_written"] is not False or report["automatic_retry"] is not False or
            report["normal_camera_and_english"] != "OWNER_CHECK_REQUIRED_AFTER_SERVICE" or
            report["service_exit"] not in ("NOT_SENT", "stop-sent", "unconfirmed", "WITHHELD_AFTER_ERROR") or
            type(report["stage"]) is not str or not 0 < len(report["stage"]) <= 256 or
            (report["stop_error"] is not None and type(report["stop_error"]) is not dict) or
            ("error_chain" in report and type(report["error_chain"]) is not list) or
            ("native_failure" in report and type(report["native_failure"]) is not dict) or
            legacy_probe._canonical(report["capture"]) != legacy_probe._canonical(summary)):
        raise ValueError("Saved general-transfer result/status metadata mismatch")
    return windows, report


def _saved_record(folder):
    try:
        selected = Path(os.path.abspath(os.fspath(folder)))
        if str(selected).startswith(("\\\\", "//")):
            raise ValueError("A local ordinary capture directory is required")
        for parent in (*reversed(selected.parents), selected):
            info = parent.lstat()
            if not legacy_probe._ordinary(info, directory=True):
                raise ValueError("Capture directory traverses a link or reparse point")
        files = {}
        for name, limit in SAVED_FILE_LIMITS.items():
            path = selected / name
            info = path.lstat()
            if (not legacy_probe._ordinary(info) or info.st_nlink != 1 or
                    not 0 < info.st_size <= limit):
                raise ValueError("Capture file is not an ordinary bounded file")
            with path.open("rb") as stream:
                opened = os.fstat(stream.fileno())
                if (not legacy_probe._ordinary(opened) or
                        legacy_probe._file_identity(info) != legacy_probe._file_identity(opened)):
                    raise ValueError("Capture file changed while opening")
                raw = stream.read(limit + 1)
                after = os.fstat(stream.fileno())
            if (legacy_probe._file_identity(opened) != legacy_probe._file_identity(after) or
                    legacy_probe._file_identity(after) != legacy_probe._file_identity(path.lstat()) or
                    len(raw) != after.st_size):
                raise ValueError("Capture file changed while being read")
            files[name] = raw
        return validate_saved_record(files)
    except Exception as error:
        raise CaptureRecordError("Select a complete valid two-window FTP Transfer inspection record") from error


def saved_windows(folder):
    return _saved_record(folder)[0]


def saved_result(folder):
    return _saved_record(folder)[1]


class OneRead:
    """One service attempt. Never resend after helper upload begins."""
    def __init__(self, payload, nonce, folder, persist, phase):
        _payload_pin_ready()
        if (type(payload) is not bytes or len(payload) != PAYLOAD_BYTES or
                hashlib.sha256(payload).hexdigest() != PAYLOAD_SHA256):
            raise ValueError("Unpinned general-transfer reader")
        self.payload, self.nonce = payload, nonce
        self.config = request(nonce)
        self.folder, self.persist, self.phase = Path(folder), persist, phase
        self.state = "READY"
        self.analysis = None
        self.native_failure = None

    def execute(self, session):
        if self.state != "READY":
            raise RuntimeError("This general-transfer read has already been attempted")
        self.state = "ATTEMPTED"
        self.phase("general FTP Transfer request staging")
        session._file(0x4010, 0, self.config)
        self.phase("general FTP Transfer read-only helper upload; constructor may execute")
        session._file(0x4007, 2, self.payload)
        self.phase("general FTP Transfer result retrieval")
        body = session._command(0x4008, b"\0\0\0")
        if type(body) is not bytes or len(body) > 4 + RESPONSE.size + WINDOW_COUNT * WINDOW_BYTES:
            raise RuntimeError("Invalid or oversized general-transfer transport response")
        self.persist(self.folder / "transport-UNVERIFIED.bin", body)
        if len(body) < 4 or body[:4] != bytes(4):
            raise RuntimeError("General-transfer helper transport did not complete")
        try:
            windows = parse(body[4:], self.nonce)
        except ProbeFailure as error:
            self.native_failure = error.details
            raise
        self.persist(self.folder / "response.bin", body[4:])
        self.analysis = analyze(windows)
        self.persist(self.folder / "capture.json", (json.dumps({
            "profile_sha256": PROFILE_SHA256, "payload_sha256": PAYLOAD_SHA256,
            "nonce_hex": self.nonce.hex(), "response_sha256": hashlib.sha256(body[4:]).hexdigest(),
            "analysis": self.analysis}, indent=2, sort_keys=True) + "\n").encode())
        self.state = "PERSISTED"
        return self.analysis


def main(argv=None):
    argv = sys.argv[1:] if argv is None else argv
    if argv in (["--self-check"], ["--general-transfer-reader-self-check"]):
        load_payload()
        print(json.dumps({"status": "OFFLINE_GENERAL_TRANSFER_READER_SELF_CHECK_PASSED",
                          "profile_sha256": PROFILE_SHA256, "payload_sha256": PAYLOAD_SHA256,
                          "camera_commands": 0, "wbi_access": False}))
        return 0
    if argv != ["--inspect-general-transfer"]:
        raise SystemExit("Select --inspect-general-transfer explicitly; no write action exists")
    payload = load_payload()
    from tools.service_operation_lock import service_operation_lock
    from tools import legacy_sparse_session as existing
    guard, sparse = existing.guard, existing.sparse
    folder = existing._create_record_directory()
    print("RECORD_DIR:", folder, flush=True)
    existing._save_json(folder, "intent.json", _intent())
    def phase(value):
        guard.state["phase"] = value
        print("PROGRESS:", value, flush=True)
    action = OneRead(payload, secrets.token_bytes(16), folder, sparse._write_verified, phase)
    error, attempted = None, False
    try:
        with service_operation_lock():
            phase("preflight")
            existing._preflight()
            guard.install_guards()
            attempted = True
            with guard.research.ServiceSession(progress=lambda _: None) as session:
                action.execute(session)
    except BaseException as exc:
        error = exc
    status = "STOPPED" if error is not None and action.state != "PERSISTED" else action.state
    report = {"status": status, "probe_state": action.state, "capture": action.analysis,
              "service_attempted": attempted, "service_exit": guard.state["exit_status"],
              "stage": guard.state["phase"], "stop_error": guard.state["stop_error"],
              "camera_state_uncertain": attempted, "firmware_written": False,
              "normal_camera_and_english": "OWNER_CHECK_REQUIRED_AFTER_SERVICE",
              "automatic_retry": False}
    if error is not None:
        report["error_chain"] = guard.safe_error_chain(error)
        if action.native_failure:
            report["native_failure"] = action.native_failure
        if not attempted and str(error) in (
                "Expected exactly one healthy Sony storage-mode device",
                "Expected pre-existing storage WinUSB binding"):
            report["preflight_error"] = str(error)
    existing._save_json(folder, "result.json", report)
    print("RESULT:", json.dumps(report), flush=True)
    if action.state == "PERSISTED":
        print("Two-window App state saved. No menu change was installed. Service exit requires a separate check.", flush=True)
    if attempted:
        print("When the access lamp is off, disconnect USB and verify the normal screen and English. "
              "Preserve the report. Do not automatically repeat this read.", flush=True)
    return 0 if error is None and action.state == "PERSISTED" else 2


if __name__ == "__main__":
    raise SystemExit(main())
