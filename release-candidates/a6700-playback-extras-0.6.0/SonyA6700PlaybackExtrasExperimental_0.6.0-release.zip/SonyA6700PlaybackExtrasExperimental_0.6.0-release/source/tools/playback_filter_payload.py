"""Immutable authored offline payload profile; never a device write allowlist.

Rebuild with tools.build_playback_filter_patch and the exact private reference.
Only authored payload/metadata are bundled. Complete App images stay private.
"""
ASSET_DIRECTORY = '.data/playback-filter-payload-20261105'
PAYLOAD_SHA256 = 'e7b30353eab724f4a2bedac7a58cde32042218a6508c493b36276ce383c856ed'
MANIFEST_SHA256 = 'dcbf8fe86fd17311af6b4c15b0153eaa0e8559eddd876b40cea16867cf4f6625'
