"""Pure offline preparation using the existing application recipe pipeline.

The bundled payload is authored code. The historical App remains a private input.
No device writer, USB library, subprocess or file API is imported by this module.
"""
from dataclasses import replace
import hashlib

from camera_pipeline.models import ByteChange
from camera_pipeline.recipes import ApplicationRecipe, ByteRecipe
from tools import playback_filter_patch_layout as placement
from tools.playback_extras_native_profile import compatibility_targets

KIND = 'a6700-playback-filter-offline-v1'
HOOKS = (
    ('a6700_filter_resolve_hook', 0x3510208, '1f640071'),
    ('a6700_filter_query73_hook', 0x352bdf8, 'ffc32dd1'),
    ('a6700_filter_query75_hook', 0x35276ec, 'fd7ba8a9'),
    ('a6700_filter_sort_hook', 0x35282d0, 'fd7bb5a9'),
    ('a6700_filter_active_hook', 0x34917a4, 'bf3300f9'),
    ('a6700_filter_active_cleanup_hook', 0x3491960, '4dfeff97'),
)
# ELF file offsets, equal to link VAs in the pinned original RX mapping.
FRAME_EDITS = ((0x34915c0, 'ffc315d1', 'ff0316d1'),
               (0x3491a54, 'ffc31591', 'ff031691'))


class PlaybackFilterRecipe(ApplicationRecipe):
    """Historical-source offline recipe; deliberately not a live target profile."""
    def __init__(self, target):
        self._target = target

    @property
    def target(self):
        return self._target


def canonical_source(source):
    """Reuse the existing 99-field guard, canonicalizing only hash input.

    Every unmanaged byte remains covered by the complete historical hash. This
    returns a separate canonical image, never a replacement for observed English
    or FTP fields. The resulting recipe pins the actual complete source hash.
    """
    if type(source) is not bytes or len(source) != placement.SOURCE_BYTES:
        raise ValueError('Complete exact-build App required')
    normalized = bytearray(source)
    fields = compatibility_targets()
    for field in fields:
        end = field.offset + len(field.preimage)
        if source[field.offset:end] not in (field.preimage, field.patched):
            raise ValueError('App contains an unknown managed-field value')
        normalized[field.offset:end] = field.preimage
    result = bytes(normalized)
    if hashlib.sha256(result).hexdigest() != placement.SOURCE_SHA256:
        raise ValueError('Complete normalized App identity disagrees')
    return result, fields


def prepare(source, payload, manifest):
    """Validate authored payload metadata and produce an exact reversible recipe.

    A self-consistent manifest is build provenance, not installed-body evidence or
    an authorization token. No caller may turn this recipe into a device allowlist.
    """
    if (type(manifest) is not dict or manifest.get('kind') != KIND
            or manifest.get('device_install_allowed') is not False
            or manifest.get('source_bytes') != placement.SOURCE_BYTES
            or manifest.get('source_sha256') != placement.SOURCE_SHA256
            or manifest.get('code_link_va') != placement.CODE_VA
            or type(payload) is not bytes or manifest.get('payload_bytes') != len(payload)
            or manifest.get('payload_sha256') != hashlib.sha256(payload).hexdigest()):
        raise ValueError('Exact offline payload manifest disagrees')
    entries = manifest.get('entries')
    if type(entries) is not dict or set(entries) != {name for name, _, _ in HOOKS}:
        raise ValueError('All six reviewed payload hook entries are required')
    canonical, fields = canonical_source(source)
    plan = placement.build_layout(canonical, payload, state_bytes=manifest.get('state_bytes'),
        hooks=tuple(placement.Hook(va, bytes.fromhex(before), entries[name]) for name, va, before in HOOKS),
        extra_changes=tuple(ByteChange(va, bytes.fromhex(before), bytes.fromhex(after), 4)
                            for va, before, after in FRAME_EDITS))
    if manifest.get('state_link_va') != plan.state_link_va:
        raise ValueError('Owned BSS link address disagrees with payload layout')
    # No filter edit may normalize or replace a managed English/FTP byte.
    for change in plan.target.changes:
        if any(max(change.offset, f.offset) < min(change.offset + len(change.before),
                                                f.offset + len(f.preimage)) for f in fields):
            raise ValueError('Filter patch intersects a preserved managed field')
    candidate = ByteRecipe(plan.target.changes).modify(source) + plan.target.appended
    target = replace(plan.target, stock_sha256=hashlib.sha256(source).hexdigest(),
                     candidate_sha256=hashlib.sha256(candidate).hexdigest(),
                     firmware='CN1 Body 2.00 offline prototype; known fields preserved')
    recipe = PlaybackFilterRecipe(target)
    recipe.verify_source(source)
    return recipe


def summary(recipe, manifest):
    """Small serializable GUI/CLI result without private App bytes or file paths."""
    plan = recipe.preview()
    return dict(state='OFFLINE_CANDIDATE', kind=KIND, model='ILCE-6700',
        source_bytes=plan['application_bytes'], source_sha256=plan['source_sha256'],
        candidate_bytes=plan['target_application_bytes'], candidate_sha256=plan['target_sha256'],
        payload_sha256=manifest['payload_sha256'], payload_bytes=manifest['payload_bytes'],
        hook_count=len(HOOKS), registry_capacity=64, device_install_allowed=False,
        canonical_source_sha256=placement.SOURCE_SHA256, preserved_managed_fields=99,
        camera_access_performed=False, filtering_physically_verified=False,
        limitations=['Exact normalized historical App only; current camera bytes have not been acquired',
                    'Native allocation, recursive lock behavior and target loader remain unqualified',
                    'Active FTP filtering only; enabled unsupported criteria stop explicitly',
                    'Preview count operation remains unchanged'])
