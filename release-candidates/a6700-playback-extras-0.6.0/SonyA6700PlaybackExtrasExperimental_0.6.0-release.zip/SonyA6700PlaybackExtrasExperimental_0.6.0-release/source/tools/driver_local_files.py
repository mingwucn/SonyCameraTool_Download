"""Local file-safety helpers adapted from the Sony English research core."""
import hashlib
import os
from pathlib import Path
import stat


def _local_name(path: Path) -> None:
    if str(path).startswith(("\\\\", "//")):
        raise ValueError("Use an ordinary local file, not a network or device path")
    reserved = {"CON", "PRN", "AUX", "NUL", "CONIN$", "CONOUT$"}
    reserved.update(prefix + digit for prefix in ("COM", "LPT") for digit in "123456789¹²³")
    for part in path.parts:
        if part == path.anchor:
            continue
        if (":" in part or part.endswith((".", " ")) or part.split(".", 1)[0].upper() in reserved):
            raise ValueError("Device names, alternate streams and Windows path aliases are refused")


def _ordinary(path: Path) -> None:
    _local_name(path)
    for part in (path, *path.parents):
        info = part.lstat()
        if stat.S_ISLNK(info.st_mode) or getattr(info, "st_file_attributes", 0) & 0x400:
            raise ValueError("Linked or reparse paths are not accepted")
    if not path.is_file():
        raise ValueError("Input must be an ordinary regular file")


def _stamp(info):
    return (info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns, info.st_ctime_ns)


def _consume(path, limit, retain=False):
    _local_name(Path(path))
    path = Path(os.path.abspath(path))
    _ordinary(path)
    before = path.stat()
    if not 8 <= before.st_size <= limit:
        raise ValueError("Input size is outside the supported bounds")
    digest = hashlib.sha256()
    data = bytearray() if retain else None
    with path.open("rb") as stream:
        if _stamp(os.fstat(stream.fileno())) != _stamp(before):
            raise ValueError("Input changed before reading")
        total = 0
        while True:
            chunk = stream.read(1024 * 1024)
            if not chunk:
                break
            total += len(chunk)
            if total > limit:
                raise ValueError("Input exceeded its size limit")
            digest.update(chunk)
            if retain:
                data.extend(chunk)
        if total != before.st_size or _stamp(os.fstat(stream.fileno())) != _stamp(before):
            raise ValueError("Input changed during reading")
    _ordinary(path)
    if _stamp(path.stat()) != _stamp(before):
        raise ValueError("Input was replaced during reading")
    return path, before.st_size, digest.hexdigest(), bytes(data) if retain else None


def _destination(path):
    _local_name(Path(path))
    path = Path(os.path.abspath(path))
    _local_name(path)
    if path.exists() or path.is_symlink():
        raise ValueError("Output already exists; choose a new file")
    for part in (path.parent, *path.parent.parents):
        info = part.lstat()
        if not stat.S_ISDIR(info.st_mode) or getattr(info, "st_file_attributes", 0) & 0x400:
            raise ValueError("Output parents must be existing ordinary local directories")
    return path
