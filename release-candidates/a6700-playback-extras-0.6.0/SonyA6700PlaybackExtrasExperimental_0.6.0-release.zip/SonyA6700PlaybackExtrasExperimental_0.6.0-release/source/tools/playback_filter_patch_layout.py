"""Inert ELF placement, not an installer or an operational filter allowlist.

Only the pinned historical App is accepted. Payload link/ABI, hook semantics and
target loader require independent qualification. Addresses are ELF link VAs.
"""
from dataclasses import dataclass
import hashlib
import struct

from camera_pipeline.models import ApplicationTarget, ByteChange
from camera_pipeline.recipes import ByteRecipe
from tools.elf_static import ElfImage

SOURCE_BYTES = 89_027_992
SOURCE_SHA256 = 'e65fd595052be5d0e98ce8000dfcb94f90a2f8309de70ef140375052009b0ef3'
ALIGNMENT = 0x10000
PHDR_COUNT = 9
CODE_OFFSET = 0x200
CODE_VA = 0x148F0200

def align(value, alignment):
    return (value + alignment - 1) & -alignment

def branch(source_va, destination_va):
    """B tail veneer preserves the original caller's LR."""
    if (type(source_va) is not int or type(destination_va) is not int
            or min(source_va, destination_va) < 0 or (source_va | destination_va) & 3):
        raise ValueError('Aligned nonnegative link VAs required')
    delta = destination_va - source_va
    if not -(1 << 27) <= delta < 1 << 27:
        raise ValueError('B destination outside signed range')
    return struct.pack('<I', 0x14000000 | ((delta // 4) & 0x3ffffff))

def veneer(source_va, destination_va):
    """ADRP x16; ADD x16,x16,#lo12; BR x16; page-aligned ASLR invariant."""
    if (type(source_va) is not int or type(destination_va) is not int
            or min(source_va, destination_va) < 0 or (source_va | destination_va) & 3):
        raise ValueError('Aligned nonnegative link VAs required')
    pages = (destination_va >> 12) - (source_va >> 12)
    if not -(1 << 20) <= pages < 1 << 20:
        raise ValueError('ADRP destination outside signed range')
    imm = pages & 0x1fffff
    return struct.pack('<III', 0x90000010 | ((imm & 3) << 29) | ((imm >> 2) << 5),
                       0x91000210 | ((destination_va & 0xfff) << 10), 0xd61f0200)

@dataclass(frozen=True)
class Hook:
    """One reviewed instruction replacement and linked payload entry offset."""
    link_va: int
    before: bytes
    entry_offset: int

    def __post_init__(self):
        if (type(self.link_va) is not int or self.link_va < 0 or self.link_va & 3
                or type(self.before) is not bytes or len(self.before) != 4
                or type(self.entry_offset) is not int or self.entry_offset < 0
                or self.entry_offset & 3):
            raise ValueError('Exact aligned instruction and payload entry required')

@dataclass(frozen=True)
class Layout:
    target: ApplicationTarget
    program_header_file_offset: int
    code_file_offset: int
    code_link_va: int
    state_file_offset: int
    state_link_va: int
    state_bytes: int
    veneer_link_vas: tuple

def _phdr(kind, flags, offset, va, file_bytes, memory_bytes, alignment):
    return struct.pack('<IIQQQQQQ', kind, flags, offset, va, va,
                       file_bytes, memory_bytes, alignment)

def build_layout(source, executable, *, state_bytes, hooks=(), extra_changes=()):
    """Produce shared-pipeline recipe data; no filesystem/process/device I/O.

    PHDRs plus RX code are appended. Separate RW/NX BSS owns new state. All old
    section positions and LOAD coordinates are preserved. With hooks=(), this
    is an inert layout exercise, never an operational filtering repair.
    """
    if (type(source) is not bytes or len(source) != SOURCE_BYTES
            or hashlib.sha256(source).hexdigest() != SOURCE_SHA256):
        raise ValueError('Pinned complete historical App required')
    if (type(executable) is not bytes or not 4 <= len(executable) <= 1024 * 1024
            or len(executable) & 3 or type(state_bytes) is not int
            or not 1 <= state_bytes <= 16 * 1024 * 1024 or type(hooks) is not tuple
            or any(type(hook) is not Hook for hook in hooks)
            or type(extra_changes) is not tuple
            or any(type(change) is not ByteChange for change in extra_changes)):
        raise ValueError('Bounded linked code, state extent and immutable hooks required')
    elf = ElfImage(source)
    header = struct.unpack_from('<16sHHIQQQIHHHHHH', source)
    if (elf.type != 3 or elf.machine != 183 or len(elf.segments) != 6
            or header[5] != 64 or header[9:11] != (56, 6)):
        raise ValueError('Qualified ET_DYN AArch64 header shape required')
    if [s.type for s in elf.segments] != [1, 1, 2, 0x6474e550, 0x6474e551, 0x6474e552]:
        raise ValueError('Original program-header kinds disagree')
    rx, rw = elf.segments[:2]
    if (rx.flags != 5 or rx.offset != 0 or rx.virtual_address != 0
            or rx.file_size != rx.memory_size or rw.flags != 6
            or rw.virtual_address <= rx.memory_size):
        raise ValueError('Original RX/RW mappings disagree')
    new_rx_va = align(max(s.virtual_address + s.memory_size for s in elf.segments if s.type == 1), ALIGNMENT)
    code_va = new_rx_va + CODE_OFFSET
    if code_va != CODE_VA:
        raise ValueError('Payload link address disagrees with pinned image')
    gap_start, gap_end = rx.file_size, rw.offset
    stub_start = align(gap_start, 4)
    stub_end = stub_start + 12 * len(hooks)
    if stub_end > gap_end:
        raise ValueError('Veneers exceed explicitly allocated gap')
    if hooks:
        if any(source[gap_start:stub_end]):
            raise ValueError('Explicit veneer allocation contains nonzero source bytes')
        if any(s.type != 8 and s.size and max(gap_start, s.offset) < min(stub_end, s.offset + s.size)
               for s in elf.sections):
            raise ValueError('Explicit veneer allocation overlaps original section')
        for section in elf.sections:
            if section.type == 4:
                if section.entry_size != 24:
                    raise ValueError('Unsupported relocation entry extent')
                for offset, info, addend in struct.iter_unpack('<QQq', elf.section_data(section)):
                    if gap_start <= offset < stub_end or (info & 0xffffffff == 1027 and gap_start <= addend < stub_end):
                        raise ValueError('Veneer allocation intersects relocation')
    phoff = align(len(source), ALIGNMENT)
    code_file = phoff + CODE_OFFSET
    rx_size = CODE_OFFSET + len(executable)
    state_file = align(phoff + rx_size, ALIGNMENT)
    state_va = align(new_rx_va + rx_size, ALIGNMENT)
    phdr_size = PHDR_COUNT * 56
    old_headers = [source[64 + i * 56:64 + (i + 1) * 56] for i in range(6)]
    changes = list(extra_changes) + [ByteChange(32, source[32:40], struct.pack('<Q', phoff), 8),
               ByteChange(56, source[56:58], struct.pack('<H', PHDR_COUNT), 2)]
    stubs = []
    if hooks:
        old_headers[0] = _phdr(1, 5, 0, 0, stub_end, stub_end, rx.alignment)
        changes.append(ByteChange(96, source[96:112], struct.pack('<QQ', stub_end, stub_end), 8))
        stub_code = bytearray(source[stub_start:stub_end])
        for i, hook in enumerate(hooks):
            if hook.entry_offset >= len(executable):
                raise ValueError('Hook payload entry exceeds executable extent')
            offset = elf.va_to_offset(hook.link_va, 4)
            if offset is None or not any(s.type == 1 and s.flags == 5 and s.virtual_address <= hook.link_va
                                        and hook.link_va + 4 <= s.virtual_address + s.file_size for s in elf.segments):
                raise ValueError('Hook must replace original file-backed RX instruction')
            stub = stub_start + i * 12
            changes.append(ByteChange(offset, hook.before, branch(hook.link_va, stub), 4))
            stub_code[i * 12:(i + 1) * 12] = veneer(stub, code_va + hook.entry_offset)
            stubs.append(stub)
        changes.append(ByteChange(stub_start, source[stub_start:stub_end], bytes(stub_code), 4))
    table = (_phdr(6, 4, phoff, new_rx_va, phdr_size, phdr_size, 8) + b''.join(old_headers)
             + _phdr(1, 5, phoff, new_rx_va, rx_size, rx_size, ALIGNMENT)
             + _phdr(1, 6, state_file, state_va, 0, state_bytes, ALIGNMENT))
    if len(table) != phdr_size or phdr_size > CODE_OFFSET:
        raise ValueError('Appended PHDR table exceeds reserved extent')
    suffix = (bytes(phoff - len(source)) + table + bytes(CODE_OFFSET - len(table))
              + executable + bytes(state_file - code_file - len(executable)))
    changes = tuple(sorted(changes, key=lambda c: c.offset))
    candidate = ByteRecipe(changes).modify(source) + suffix
    mapped = ElfImage(candidate)
    if mapped.va_to_offset(code_va, len(executable)) != code_file or mapped.va_to_offset(state_va, 1) is not None:
        raise ValueError('Appended code/state mapping disagrees with layout')
    loads = [s for s in mapped.segments if s.type == 1]
    if [s.virtual_address for s in loads] != sorted(s.virtual_address for s in loads):
        raise ValueError('LOAD entries must be in ascending link-VA order')
    # An ELF segment/page interval model, not execution of the camera's loader.
    for page in (0x1000, 0x10000):
        previous_end = 0
        for segment in loads:
            if (segment.offset - segment.virtual_address) % page:
                raise ValueError('LOAD is not congruent for supported page model')
            start = segment.virtual_address & -page
            end = align(segment.virtual_address + segment.memory_size, page)
            if start < previous_end:
                raise ValueError('Rounded LOAD mappings overlap in page model')
            previous_end = end
    target = ApplicationTarget('ILCE-6700', 'CN1 Body 2.00 historical offline layout', '/usr/lib/appFw.so',
        len(source), SOURCE_SHA256, hashlib.sha256(candidate).hexdigest(), changes, appended=suffix)
    return Layout(target, phoff, code_file, code_va, state_file, state_va, state_bytes, tuple(stubs))
