"""Pure, fixed-profile planners for independent playback FTP changes.

No files, devices, process, network or camera backend are used. Legacy shortcut
and label actions retain their seven-window profile. General FTP Transfer uses
exactly two App-only observation windows and changes only the C1/C2 type-21
byte; it does not observe WBI or label state. WBI coordinates retain their
existing label-only mapping assumption.
"""
from dataclasses import dataclass, fields
import hashlib
import json
import struct

from camera_pipeline import ByteChange, ByteRecipe


LEGACY_ACTIONS = ("shortcut", "label")
ACTIONS = LEGACY_ACTIONS
CANDIDATE_ACTIONS = LEGACY_ACTIONS + ("general_transfer",)
ACTION_IDS = {"shortcut": 1, "label": 2, "general_transfer": 3}
SECTOR_BYTES = 512
LEGACY_SECTOR_COUNT = 7
SECTOR_COUNT = 8
GENERAL_OBSERVATION_COUNT = 2
HEADER = struct.Struct("<4sI16s32s")
PROBE_OFFSETS = (0x04BCA200, 0x04C0B400, 0x04C36A00,
                 0x02514400, 0x02586600, 0x025C1C00, 0x03788E00,
                 0x03788C00)
DOMAINS = ("APP", "APP", "APP", "WBI", "WBI", "WBI", "APP", "APP")
CANONICAL_HASHES = (
    "3bd01f7228e0c2bda17f7a84173a3f9555da6b8c44d98dc25a74863d54ad7b01",
    "3fb4e6dad9eb072a2fb661db45cf7852927bd2060732c202afa11780dfccf6a5",
    "23a668df96d2da91d27c7a079afad8a69dd30d957b47ba67bfb832bae22f88c0",
    "dd4ca6087fd30d3dcd445430780616c01fc6ab9b049c3ae6e3c70b38931d1d46",
    "79bc843b1056ec7bc858dbbd51c3d809173a3d245519e73c5c457fe7e3418208",
    "9cf3e0be501b0d85805a9844aa95b7e88722fcd5da60d8a5f96152749e8d6cd8",
    "50c53b2668fe69f8066726ff9987fef721ecdc6681496962e5e462fd69189a60",
    "155b81577b84be7d0cca0db2c20a6dd0aabec7894ea1c8d50c72135b52ae3900",
)
PERMISSION_POSITIONS = ((0x160,), (0x112,), (0x6A, 0x10A, 0x1AA),
                        (0x160,), (0x112,), (0x6A, 0x10A, 0x1AA))
OLD_TITLE_RID = 0x020080CE
NEW_TITLE_RID = 0x02006077
TITLE_POSITION = 0x18C
SHORTCUT_POSITION = 0x52
TARGET_INDICES = {"shortcut": (6,), "label": (5, 2), "general_transfer": (1,)}
OBSERVATION_INDICES = {
    "shortcut": tuple(range(LEGACY_SECTOR_COUNT)),
    "label": tuple(range(LEGACY_SECTOR_COUNT)),
    # This action reads the existing 0x4c7 window and the aligned 0x4a8 window only.
    "general_transfer": (6, 7),
}
CHANGE_MASKS = {
    "shortcut": ((6, 0x52, 0, 1), (6, 0x53, 0, 1)),
    "label": ((2, 0x18C, 0xCE, 0x77), (2, 0x18D, 0x80, 0x60),
              (5, 0x18C, 0xCE, 0x77), (5, 0x18D, 0x80, 0x60)),
    # C1/C2 map to playback menu type 21. Type 20 and row 0x4c7 stay intact.
    "general_transfer": ((1, 0x1C3, 0, 1),),
}
PROFILE_SHA256 = {
    "shortcut": "c053e31a3af874b17e7f9f3a398d38e9892cf0f6834e91000faf782930c0bafc",
    "label": "d1b04b185f9508bd6d278bce688cfaed2441fd8e45a4704a9e6658415f3e7358",
    "general_transfer": "1c1e55dfdedcd19c39e01d89d08bf9561aadb12e70f009e1e44a4fdbe5c5381a",
}


class NeedsReview(ValueError):
    """The observations are not an accepted complete known state."""


class AlreadyApplied(ValueError):
    """The selected action is already present; do not stage a writer."""
    def __init__(self, action):
        self.action = action
        super().__init__("Selected playback " + action + " change is already applied; no writer is needed")


@dataclass(frozen=True)
class Change:
    domain: str
    probe_index: int
    position: int
    coordinate: int
    before: int
    after: int


@dataclass(frozen=True)
class Candidate:
    action: str
    before: tuple
    after: tuple
    changes: tuple

    @property
    def target_indices(self):
        return TARGET_INDICES[self.action]

    @property
    def changed_bytes(self):
        return len(self.changes)


def _action(action):
    if type(action) is not str or action not in CANDIDATE_ACTIONS:
        raise ValueError("Select exactly one playback extras action: shortcut, label or general_transfer")
    return action


def profile_definition(action):
    """Return fresh public profile metadata, never observation bytes."""
    action = _action(action)
    observation_indices = OBSERVATION_INDICES[action]
    result = {
        "schema_version": 1, "action": action, "sector_bytes": SECTOR_BYTES,
        "request_magic": "A67X", "request_version": 1,
        "observation_offsets": [PROBE_OFFSETS[index] for index in observation_indices],
        "canonical_observation_sha256": [CANONICAL_HASHES[index] for index in observation_indices],
        "profile_order": list(TARGET_INDICES[action]),
        "entries": [
            {"domain": DOMAINS[observation_indices[index]],
             "coordinate_type": ("APP_FILE_OFFSET" if DOMAINS[observation_indices[index]] == "APP"
                                 else "ASSUMED_WBI_DEVICE_FILE_OFFSET"),
             "offset": PROBE_OFFSETS[observation_indices[index]], "probe_index": index,
             "profile_index": profile_index,
             "preimage_sha256": CANONICAL_HASHES[observation_indices[index]],
             "changes": [{"position": pos, "before": old, "after": new}
                         for i, pos, old, new in CHANGE_MASKS[action] if i == index]}
            for profile_index, index in enumerate(TARGET_INDICES[action])],
    }
    if action == "general_transfer":
        result["observation_domains"] = ["APP", "APP"]
        result["current_image_variant_values"] = ["0000", "0101"]
        result["general_transfer_variant_values"] = ["00", "01"]
        result["playback_category"] = 21
    else:
        result["required_permission_halfword"] = 1
        result["shortcut_variant_values"] = ["0000", "0101"]
        result["label_rid_values"] = [OLD_TITLE_RID, NEW_TITLE_RID]
        result["consistent_app_wbi_label"] = True
    return result


def profile_json(action):
    return json.dumps(profile_definition(action), sort_keys=True, separators=(",", ":")).encode()


def profile_digest(action):
    action = _action(action)
    required_count = SECTOR_COUNT if action == "general_transfer" else LEGACY_SECTOR_COUNT
    if (type(CANONICAL_HASHES) is not tuple or len(CANONICAL_HASHES) < required_count or
            any(type(digest) is not str or len(digest) != 64
                for digest in CANONICAL_HASHES[:required_count]) or
            hashlib.sha256(profile_json(action)).hexdigest() != PROFILE_SHA256[action]):
        raise ValueError("Fixed playback extras profile changed")
    return bytes.fromhex(PROFILE_SHA256[action])


def _sector_shape(sectors):
    if (type(sectors) is not tuple or len(sectors) not in (GENERAL_OBSERVATION_COUNT, LEGACY_SECTOR_COUNT) or
            any(type(sector) is not bytes or len(sector) != SECTOR_BYTES for sector in sectors)):
        raise NeedsReview("Exactly two App-only general-action or seven legacy observation windows are required")


def inspect_state(sectors):
    """Validate complete observations and return only known installed variants."""
    _sector_shape(sectors)
    if len(sectors) == GENERAL_OBSERVATION_COUNT:
        profile_digest("general_transfer")
        current_image, general_window = sectors
        if struct.unpack_from("<I", current_image, 0x18)[0] != 0x4C7:
            raise NeedsReview("The first App-only window does not contain the 0x4c7 current-image row")
        shortcut = current_image[SHORTCUT_POSITION:SHORTCUT_POSITION + 2]
        if shortcut not in (b"\0\0", b"\1\1"):
            raise NeedsReview("The 0x4c7 C1/C2 bytes must be exactly 0000 or 0101")
        if struct.unpack_from("<I", general_window, 0x188)[0] != 0x4A8:
            raise NeedsReview("The aligned App window does not contain the 0x4a8 roster row")
        general_flag = general_window[0x1C3]
        if general_flag not in (0, 1):
            raise NeedsReview("The C1/C2 FTP Transfer category byte is not a known 00/01 state")
        canonical_current = bytearray(current_image)
        canonical_current[SHORTCUT_POSITION:SHORTCUT_POSITION + 2] = bytes(2)
        canonical_general = bytearray(general_window)
        canonical_general[0x1C3] = 0
        if (hashlib.sha256(canonical_current).hexdigest() != CANONICAL_HASHES[6] or
                hashlib.sha256(canonical_general).hexdigest() != CANONICAL_HASHES[7]):
            raise NeedsReview("One of the two App-only windows differs outside its known action byte variants")
        return {"shortcut": shortcut == b"\1\1", "general_transfer": general_flag == 1}
    for action in LEGACY_ACTIONS:
        profile_digest(action)
    for index, positions in enumerate(PERMISSION_POSITIONS):
        for position in positions:
            if struct.unpack_from("<H", sectors[index], position)[0] != 1:
                raise NeedsReview("All ten existing playback permission halfwords must remain 0001")
    titles = tuple(struct.unpack_from("<I", sectors[index], TITLE_POSITION)[0] for index in (2, 5))
    if titles[0] not in (OLD_TITLE_RID, NEW_TITLE_RID) or titles[0] != titles[1]:
        raise NeedsReview("App and assumed WBI title RIDs must be the same exact old or new variant")
    shortcut = sectors[6][SHORTCUT_POSITION:SHORTCUT_POSITION + 2]
    if shortcut not in (b"\0\0", b"\1\1"):
        raise NeedsReview("The shortcut pair must be exactly 0000 or 0101; partial states need review")
    if struct.unpack_from("<I", sectors[6], 0x18)[0] != 0x4C7:
        raise NeedsReview("The observed shortcut roster key is not 0x4c7")
    canonical = list(sectors)
    for index in (2, 5):
        changed = bytearray(canonical[index])
        struct.pack_into("<I", changed, TITLE_POSITION, OLD_TITLE_RID)
        canonical[index] = bytes(changed)
    changed = bytearray(canonical[6])
    changed[SHORTCUT_POSITION:SHORTCUT_POSITION + 2] = bytes(2)
    canonical[6] = bytes(changed)
    state = {"shortcut": shortcut == b"\1\1", "label": titles[0] == NEW_TITLE_RID}
    if tuple(hashlib.sha256(sector).hexdigest() for sector in canonical) != CANONICAL_HASHES[:len(sectors)]:
        raise NeedsReview("A complete observation window differs from its pinned known variants")
    return state


def build_candidate(action, sectors):
    """Preserve every supplied window except the selected independent mask."""
    action = _action(action)
    if action == "general_transfer" and (type(sectors) is not tuple or len(sectors) != GENERAL_OBSERVATION_COUNT):
        raise NeedsReview("The general FTP Transfer candidate requires its exact two-window App-only observation")
    if action in LEGACY_ACTIONS and (type(sectors) is not tuple or len(sectors) != LEGACY_SECTOR_COUNT):
        raise NeedsReview("Legacy shortcut and label actions require their seven-window capture")
    state = inspect_state(sectors)
    if state[action]:
        raise AlreadyApplied(action)
    after, changes = list(sectors), []
    for index in range(len(sectors)):
        edits = tuple(ByteChange(position, bytes([old]), bytes([new]))
                      for i, position, old, new in CHANGE_MASKS[action] if i == index)
        if edits:
            try:
                after[index] = ByteRecipe(edits).modify(sectors[index])
            except ValueError as exc:
                raise NeedsReview("A selected byte differs from its exact preimage") from exc
    for index, position, old, new in CHANGE_MASKS[action]:
        global_index = OBSERVATION_INDICES[action][index]
        changes.append(Change(DOMAINS[global_index], index, position,
                              PROBE_OFFSETS[global_index] + position, old, new))
    result = Candidate(action, sectors, tuple(after), tuple(changes))
    actual = [(i, pos) for i in range(len(sectors)) for pos in range(SECTOR_BYTES)
              if result.before[i][pos] != result.after[i][pos]]
    if actual != [(change.probe_index, change.position) for change in result.changes]:
        raise ValueError("Playback extras candidate exceeds its fixed change mask")
    new_state = inspect_state(result.after)
    if (not new_state[action] or
            any(new_state[a] != state[a] for a in state if a != action)):
        raise ValueError("Playback extras candidate changed the other action's state")
    return result


def validate_candidate(candidate):
    if type(candidate) is not Candidate or type(candidate.changes) is not tuple:
        raise ValueError("An immutable playback extras candidate is required")
    _sector_shape(candidate.after)
    expected = build_candidate(candidate.action, candidate.before)
    if candidate.after != expected.after or len(candidate.changes) != len(expected.changes):
        raise ValueError("Candidate output differs from its fixed independent action")
    for actual, wanted in zip(candidate.changes, expected.changes):
        if type(actual) is not Change or any(
                type(getattr(actual, field.name)) is not type(getattr(wanted, field.name)) or
                getattr(actual, field.name) != getattr(wanted, field.name)
                for field in fields(Change)):
            raise ValueError("Candidate change metadata differs from the fixed action mask")


def inverse(candidate):
    """Return an exact private in-memory inverse; never execute or persist it."""
    validate_candidate(candidate)
    result = list(candidate.after)
    for index in range(len(candidate.after)):
        edits = tuple(ByteChange(change.position, bytes([change.before]), bytes([change.after]))
                      for change in candidate.changes if change.probe_index == index)
        if edits:
            result[index] = ByteRecipe(edits).reverse(result[index])
    if tuple(result) != candidate.before:
        raise ValueError("Candidate inverse did not restore every observation byte")
    return tuple(result)


def request_bytes(candidate, nonce):
    validate_candidate(candidate)
    if type(nonce) is not bytes or len(nonce) != 16 or nonce == bytes(16):
        raise ValueError("A nonzero immutable 16-byte nonce is required")
    pairs = b"".join(candidate.before[index] + candidate.after[index]
                     for index in candidate.target_indices)
    return HEADER.pack(b"A67X", 1, nonce, profile_digest(candidate.action)) + pairs


def summary(candidate):
    """Sanitized scope only; no observation bytes, nonce or device claims."""
    validate_candidate(candidate)
    result = {"evidence_class": "offline-counterfactual", "experimental": True,
            "action": candidate.action, "profile_sha256": PROFILE_SHA256[candidate.action],
            "target_indices": list(candidate.target_indices),
            "transaction_targets": len(candidate.target_indices),
            "observed_windows": len(candidate.after), "observed_bytes": len(candidate.after) * SECTOR_BYTES,
            "changed_bytes": candidate.changed_bytes,
            "logical_write_window_bytes": len(candidate.target_indices) * SECTOR_BYTES,
            "unchanged_bytes": len(candidate.after) * SECTOR_BYTES - candidate.changed_bytes,
            "full_window_inverse_exact": inverse(candidate) == candidate.before,
            "all_ten_permission_halfwords_preserved": (None if candidate.action == "general_transfer" else True),
            "filter_parameter_0x568_changed": False,
            "english_and_network_changes": 0, "uxc_files_changed": 0,
            "reads_wbi": candidate.action != "general_transfer",
            "observed_wbi_windows": 0 if candidate.action == "general_transfer" else 3,
            "writes_wbi": candidate.action == "label",
            "shortcut_wbi_target": None, "physical_wbi_mapping": "UNVERIFIED",
            "physical_write_extent_geometry": "UNVERIFIED",
            "type20_unchanged": candidate.action == "general_transfer",
            "current_image_row_0x4c7_unchanged": candidate.action == "general_transfer",
            "current_image_action_preserved": candidate.action == "general_transfer",
            "label_state_observed": candidate.action != "general_transfer",
            "wbi_state_observed": candidate.action != "general_transfer",
            "filtering": "KNOWN_OWNER_REPORTED_FAILURE_NOT_REPAIRED_BY_THESE_ACTIONS",
            "failed_start_recovery": "UNVERIFIED", "camera_operations": 0,
            "live_writer": False}
    if candidate.action == "general_transfer":
        result["label_state"] = "NOT_OBSERVED"
    else:
        result["other_action_preserved"] = True
    return result
