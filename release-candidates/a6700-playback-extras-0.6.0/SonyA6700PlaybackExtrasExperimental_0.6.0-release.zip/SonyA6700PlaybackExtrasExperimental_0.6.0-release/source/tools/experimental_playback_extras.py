"""Offline profiles for the playback FTP shortcuts and title repair.

Pure validation imports no camera backend. Seven complete observation windows
are retained for the legacy shortcut and label actions. General FTP Transfer
has a separate two-window App-only observation profile. No automatic retry,
rollback, cleanup or firmware operation is performed by import or description.
"""
import hashlib
import json
import os
from pathlib import Path
import secrets
import struct

# Support the existing `python -m tools...` entry from the model workbench.
if __name__ == "__main__":
    import sys
    for shared_root in Path(__file__).resolve().parents:
        if (shared_root / "camera_pipeline").is_dir():
            sys.path.insert(0, str(shared_root))
            break

from tools import playback_extras_candidate as planner
from tools import playback_extras_probe as probe
from tools import playback_general_transfer_probe as general_probe
from tools import analyze_playback_capture as audit
from tools.playback_writer_wait import helper_response_wait

LIVE_ACTION_ENABLED = True
LIVE_ACTIONS = planner.CANDIDATE_ACTIONS
NATIVE_ROOT = Path(__file__).resolve().parents[1] / '.data/playback-extras-native-20261104'
GENERAL_WRITER_ROOT = Path(__file__).resolve().parents[1] / '.data/playback-extras-native-general-transfer-20261111-649029cada42'
WRITER_PINS = {
    'shortcut': {'path': NATIVE_ROOT / 'shortcut/playback_extras_write.elf', 'bytes': 62168, 'sha256': '9456ccb9ca663073784d695cd3635a223d931e7836c2388359ed2f7fdf460902'},
    'label': {'path': NATIVE_ROOT / 'label/playback_extras_write.elf', 'bytes': 64792, 'sha256': '8d20b761632555d00200c6abada4e1fb4fb41c67826367e09ecade6423727e4d'},
    'general_transfer': {'path': GENERAL_WRITER_ROOT / 'playback_extras_general_transfer_write.elf', 'bytes': 62184, 'sha256': '09496c57bb533ef05bd75122230fe3708ec80e00527b9fd88d26d647128498e2'},
}
RESPONSE = struct.Struct('<4sI16sIIIII')
STATUS_NAMES = ('VERIFIED', 'BAD_REQUEST', 'OPEN_FAILED', 'READ_FAILED', 'PREIMAGE_MISMATCH',
                'WRITE_FAILED', 'SYNC_FAILED', 'READBACK_FAILED', 'READBACK_MISMATCH',
                'CLOSE_FAILED', 'APP_PRE_GUARD_FAILED', 'APP_POST_GUARD_OR_ENGLISH_FAILED',
                'DESCRIPTOR_CLOSE_FAILED', 'READ_ONLY_REMOUNT_FAILED', 'CLOCK_OR_DEADLINE_FAILED')
SECONDARY_ROOT_ENV = 'SONY_A6700_PLAYBACK_EXTRAS_SECONDARY_BACKUP'


def _action(action):
    if type(action) is not str or action not in planner.CANDIDATE_ACTIONS:
        raise ValueError('Select one known playback extras action explicitly')
    return action


def load_writer(action):
    _action(action)
    planner.profile_digest(action)
    pin = WRITER_PINS.get(action)
    if pin is None:
        raise RuntimeError('No pinned native writer exists for the selected action; no camera action started')
    if (type(pin['bytes']) is not int or pin['bytes'] <= 0 or
            type(pin['sha256']) is not str or len(pin['sha256']) != 64):
        raise RuntimeError('Native extras writer is not built and pinned; no camera action started')
    raw = audit._read_metadata(pin['path'], pin['bytes'])
    if len(raw) != pin['bytes'] or hashlib.sha256(raw).hexdigest() != pin['sha256']:
        raise RuntimeError('Experimental extras writer differs from its reviewed build')
    return raw


def saved_sectors(action, folder):
    sectors = (general_probe.saved_windows(folder) if action == 'general_transfer'
               else probe.saved_sectors(folder))
    planner.build_candidate(_action(action), sectors)
    return sectors


def describe(action=None):
    if action is None:
        return {'actions': {name: describe(name) for name in planner.CANDIDATE_ACTIONS},
                'live_action_enabled': LIVE_ACTION_ENABLED, 'read_windows': 7,
                'filter_execution_repair': False}
    _action(action)
    observed_windows = 2 if action == 'general_transfer' else 7
    logical_changes = {'shortcut': 2, 'label': 4, 'general_transfer': 1}[action]
    targets = {'shortcut': 1, 'label': 2, 'general_transfer': 1}[action]
    scopes = {
        'shortcut': 'FTP Trans. (This Img.): current displayed image; existing key categories',
        'label': 'FTP leaf 7bf title only: Success. Trans. Img.',
        'general_transfer': ('FTP Transfer (0x4a8): general selection/progress; exactly two App windows; '
                             'C1/C2 type 21 only; no WBI reads or writes'),
    }
    limitations = ['Partial backups do not establish failed-start recovery.',
                   'Physical flash geometry and WBI integrity handling remain unproven.',
                   'Logical byte count is not a physical flash-write bound.',
                   'UI visibility, assignment, transfer and title rendering require owner checks.']
    if action == 'general_transfer':
        limitations.append('General Transfer uses a separate two-window App-only reader and writer. Physical write extent and failed-start recovery remain unverified; the action is experimental and still needs physical acceptance.')
    return {'action': action, 'profile_sha256': planner.PROFILE_SHA256[action],
            'profile': planner.profile_definition(action),
            'logical_byte_changes': logical_changes,
            'logical_write_window_bytes': targets * planner.SECTOR_BYTES,
            'software_transaction_targets': targets,
            'observed_windows': observed_windows, 'observed_bytes': observed_windows * 512,
            'scope': scopes[action],
            'reads_wbi': action != 'general_transfer',
            'observed_wbi_windows': 0 if action == 'general_transfer' else 3,
            'writes_wbi': action == 'label', 'changes_uxc': False,
            'current_image_row_0x4c7_preserved': action == 'general_transfer',
            'label_state_observed': action != 'general_transfer',
            'wbi_state_observed': action != 'general_transfer',
            'physical_write_extent_geometry': 'UNVERIFIED',
            'changes_existing_button_assignments': False, 'filter_execution_repair': False,
            'live_action_enabled': action in LIVE_ACTIONS and LIVE_ACTION_ENABLED,
            'limitations': limitations}


def writer_result(body, nonce, action):
    _action(action)
    count = 2 if action == 'label' else 1
    if type(body) is not bytes or len(body) != 4 + RESPONSE.size or body[:4] != bytes(4):
        raise RuntimeError('Incomplete or unexpected writer response; stop without retry')
    fields = RESPONSE.unpack(body[4:])
    if (fields[:3] != (b'A6EY', 1, nonce) or fields[3] >= len(STATUS_NAMES) or
            fields[4] not in (*range(count), 0xFFFFFFFF) or
            not 0 <= fields[6] <= fields[5] <= count or fields[7] not in (0, 1)):
        raise RuntimeError('Unrecognized writer response; preserve the transport and stop')
    return {'status_code': fields[3], 'status': STATUS_NAMES[fields[3]],
            'failed_window': fields[4], 'attempted_windows': fields[5],
            'verified_windows': fields[6], 'uncertain': bool(fields[7])}


def validate_writer_response(body, nonce, action):
    detail = writer_result(body, nonce, action)
    count = 2 if action == 'label' else 1
    if RESPONSE.unpack(body[4:]) != (b'A6EY', 1, nonce, 0, 0xFFFFFFFF, count, count, 0):
        raise RuntimeError('Writer stopped: %s; retain the response and stop' % detail['status'])


class ExtrasAction:
    """Journal before constructor upload. Every instance permits one attempt."""

    def __init__(self, action, writer, adopted_sectors, io):
        self.action = _action(action)
        pin = WRITER_PINS.get(action)
        if pin is None:
            raise ValueError('General FTP Transfer has no pinned native writer')
        if (type(writer) is not bytes or type(pin['bytes']) is not int or pin['bytes'] <= 0 or
                len(writer) != pin['bytes'] or hashlib.sha256(writer).hexdigest() != pin['sha256']):
            raise ValueError('Unpinned extras writer')
        planner.build_candidate(action, adopted_sectors)
        self.writer, self.adopted, self.io = writer, adopted_sectors, io
        self.state = 'READY'
        self.writer_may_have_executed = False
        self.native_result = None

    def execute(self, session):
        if self.state != 'READY':
            raise RuntimeError('This extras action has already been attempted')
        self.state = 'ATTEMPTED'
        first_nonce, before = self.io.capture(session, 'before', self.action)
        if before != self.adopted:
            raise RuntimeError('Fresh capture differs from selected inspection; no writer sent')
        candidate = planner.build_candidate(self.action, before)
        nonce = secrets.token_bytes(16)
        if nonce == first_nonce:
            raise RuntimeError('Writer nonce unexpectedly repeated')
        request = planner.request_bytes(candidate, nonce)
        pre, post = b''.join(candidate.before), b''.join(candidate.after)
        self.io.persist('planned-before.bin', pre)
        self.io.persist('planned-after.bin', post)
        self.io.persist('planned-request.bin', request)
        backup = self.io.secondary(pre)
        if backup is not True:
            raise RuntimeError('Secondary preimage backup was not verified; no writer sent')
        self.io.save('journal-prepared.json', {
            'state': 'PREPARED', 'action': self.action,
            'profile_sha256': planner.PROFILE_SHA256[self.action],
            'nonce_hex': nonce.hex(), 'before_capture_nonce_hex': first_nonce.hex(),
            'before_sha256': hashlib.sha256(pre).hexdigest(),
            'after_sha256': hashlib.sha256(post).hexdigest(),
            'request_sha256': hashlib.sha256(request).hexdigest(),
            'writer_sha256': WRITER_PINS[self.action]['sha256'],
            'secondary_preimage_verified': backup, 'full_backup': False,
            'failed_start_recovery': 'UNVERIFIED',
            'guard_fields': 100 if self.action == 'general_transfer' else 99,
            'observed_windows': len(candidate.before), 'transaction_targets': len(candidate.target_indices),
            'firmware_identity': 'GUARDED_BY_NATIVE_FULL_APP_NORMALIZATION',
            'body_identity': 'OWNER_REPORT_NOT_AUTHENTICATED'})
        self.io.save('journal-writer-starting.json', {
            'state': 'CAMERA_MAY_HAVE_CHANGED', 'action': self.action, 'nonce_hex': nonce.hex(),
            'automatic_retry_rollback_or_delete': False})
        self.io.phase('extras writer request staging')
        session._file(0x4010, 0, request)
        with helper_response_wait(session):
            self.io.phase('extras writer upload; constructor may execute')
            self.writer_may_have_executed = True
            session._file(0x4007, 2, self.writer)
            self.io.phase('extras writer result retrieval')
            body = session._command(0x4008, bytes(3))
        self.io.persist('writer-transport-UNVERIFIED.bin', body)
        self.native_result = writer_result(body, nonce, self.action)
        self.io.save('journal-writer-reported.json', self.native_result)
        validate_writer_response(body, nonce, self.action)
        after_nonce, after = self.io.capture(session, 'after', self.action)
        if after_nonce in (first_nonce, nonce):
            raise RuntimeError('Readback nonce repeated; preserve results without retry')
        if after != candidate.after:
            raise RuntimeError('Independent complete-window readback differs; preserve results without retry')
        self.io.save('journal-readback-verified.json', {
            'state': 'READBACK_VERIFIED', 'action': self.action,
            'profile_sha256': planner.PROFILE_SHA256[self.action],
            'logical_byte_changes': candidate.changed_bytes,
            'transaction_targets': len(candidate.target_indices), 'observed_windows': len(candidate.after),
            'independent_readback_bytes': len(candidate.after) * 512,
            'shortcut_visible_and_usable': 'OWNER_CHECK_REQUIRED',
            'third_title_rendering': 'OWNER_CHECK_REQUIRED',
            'normal_camera_and_english': 'OWNER_CHECK_REQUIRED',
            'filter_execution': 'NOT_CHANGED'})
        self.state = 'READBACK_VERIFIED'


class RuntimeIO:
    def __init__(self, root, existing):
        self.root, self.existing = Path(root), existing

    def phase(self, value):
        self.existing.guard.state['phase'] = value
        print('PROGRESS:', value, flush=True)

    def persist(self, name, value):
        self.existing.sparse._write_verified(self.root / name, value)

    def save(self, name, value):
        self.existing._save_json(self.root, name, value)

    def capture(self, session, label, selected_action):
        if label not in ('before', 'after'):
            raise ValueError('Unexpected capture phase')
        folder = self.root / label
        folder.mkdir(mode=0o700)
        self.existing._assert_non_reparse(folder)
        self.existing._acl_operation(folder, 'set')
        self.existing._acl_operation(folder, 'verify')
        selected_probe = general_probe if selected_action == 'general_transfer' else probe
        nonce = secrets.token_bytes(16)
        self.existing._save_json(folder, 'request-intent.json', {
            'profile_sha256': selected_probe.PROFILE_SHA256, 'nonce_hex': nonce.hex(),
            'request_sha256': hashlib.sha256(selected_probe.request(nonce)).hexdigest()})
        reader = selected_probe.OneRead(selected_probe.load_payload(), nonce, folder,
                                        self.existing.sparse._write_verified, self.phase)
        reader.execute(session)
        raw = (folder / 'response.bin').read_bytes()
        metadata = json.loads((folder / 'capture.json').read_bytes())
        if (metadata['nonce_hex'] != nonce.hex() or
                metadata['response_sha256'] != hashlib.sha256(raw).hexdigest() or
                metadata['profile_sha256'] != selected_probe.PROFILE_SHA256 or
                metadata['payload_sha256'] != selected_probe.PAYLOAD_SHA256):
            raise RuntimeError('Persisted capture metadata changed')
        sectors = selected_probe.parse(raw, nonce)
        if metadata['analysis'] != selected_probe.analyze(sectors):
            raise RuntimeError('Persisted capture analysis changed')
        return nonce, sectors

    def secondary(self, preimage):
        """Second read-back-verified host copy on a separately selected fixed volume."""
        import ctypes
        from ctypes import wintypes
        configured_root = os.environ.get(SECONDARY_ROOT_ENV)
        if not configured_root:
            raise RuntimeError(f'Set {SECONDARY_ROOT_ENV} to a directory on a separate local fixed drive')
        target = Path(configured_root).expanduser()
        if not target.is_absolute():
            raise RuntimeError(f'{SECONDARY_ROOT_ENV} must be an absolute path on a separate local fixed drive')
        target = target.resolve()
        kernel = ctypes.WinDLL('kernel32', use_last_error=True)
        kernel.GetDriveTypeW.argtypes = [wintypes.LPCWSTR]
        kernel.GetDriveTypeW.restype = wintypes.UINT
        if kernel.GetDriveTypeW(target.anchor) != 3:
            raise RuntimeError('Secondary backup volume is not a local fixed drive')
        if self.root.drive.casefold() == target.drive.casefold():
            raise RuntimeError('Primary and secondary preimages require separate host volumes')
        for parent in (target.parent, *target.parent.parents):
            self.existing._assert_non_reparse(parent)
        if not target.exists():
            target.mkdir(mode=0o700)
            self.existing._acl_operation(target, 'set')
        self.existing._assert_non_reparse(target)
        self.existing._acl_operation(target, 'verify')
        destination = target / self.root.name
        destination.mkdir(mode=0o700)
        self.existing._assert_non_reparse(destination)
        self.existing._acl_operation(destination, 'set')
        self.existing._acl_operation(destination, 'verify')
        self.existing.sparse._write_verified(destination / 'planned-before.bin', preimage)
        if (destination / 'planned-before.bin').read_bytes() != preimage:
            raise RuntimeError('Secondary preimage readback failed')
        self.save('secondary-backup.json', {'path': str(destination),
                  'sha256': hashlib.sha256(preimage).hexdigest(), 'full_backup': False,
                  'separate_volume': self.root.drive.casefold() != destination.drive.casefold()})
        return True


def main(argv=None):
    import sys
    argv = sys.argv[1:] if argv is None else argv
    if argv == ['--describe']:
        print(json.dumps(describe(), indent=2))
        return 0
    if argv == ['--self-check']:
        for name in LIVE_ACTIONS:
            load_writer(name)
        probe.load_payload()
        general_probe.load_payload()
        print('PINNED_EXTRAS_WRITERS_AND_READER_OK; CAMERA_COMMANDS=0')
        return 0
    if (len(argv) != 5 or argv[0] != '--apply-playback-extras' or
            argv[1] not in planner.CANDIDATE_ACTIONS or argv[2] != '--inspection-record' or
            not argv[3] or argv[3].startswith('--') or
            argv[4] != '--confirm-experimental-playback-extras'):
        raise SystemExit('Explicit --apply-playback-extras <shortcut|label|general_transfer> --inspection-record <folder> --confirm-experimental-playback-extras required')
    if not LIVE_ACTION_ENABLED:
        raise SystemExit('Extras writers remain disabled until native builds and review pass')
    selected = argv[1]
    writer = load_writer(selected)
    (general_probe if selected == 'general_transfer' else probe).load_payload()
    try:
        previous = saved_sectors(selected, argv[3])
    except planner.AlreadyApplied:
        print('RESULT:', json.dumps({'state': 'ALREADY_APPLIED', 'action': selected,
              'session_attempted': False, 'writer_may_have_executed': False,
              'service_exit': 'NOT_SENT', 'camera_state_uncertain': False,
              'automatic_retry': False, 'record_created': False}), flush=True)
        return 0
    except (ValueError, OSError) as error:
        # Selected-folder errors are host input refusals, before any backend,
        # private record creation or service session. Never try a replacement read.
        message = (str(error) if isinstance(error, planner.NeedsReview) or
                   getattr(error, 'code', None) is not None else
                   ('The selected inspection is incomplete or invalid. Use a complete two-window App inspection.'
                    if selected == 'general_transfer' else
                    'The selected inspection is incomplete or invalid. Use a complete seven-window inspection.'))
        print('RESULT:', json.dumps({'state': 'INPUT_REFUSED', 'action': selected,
              'session_attempted': False, 'writer_may_have_executed': False,
              'service_exit': 'NOT_SENT', 'camera_state_uncertain': False,
              'automatic_retry': False, 'record_created': False,
              'input_error_code': getattr(error, 'code', 'INVALID_CAPTURE'),
              'input_error': message}), flush=True)
        print('No camera action started. Correct the inspection selection; no automatic read was attempted.',
              flush=True)
        return 2
    from tools.service_operation_lock import service_operation_lock
    from tools import legacy_sparse_session as existing
    root = existing._create_record_directory()
    print('RECORD_DIR:', root, flush=True)
    io = RuntimeIO(root, existing)
    io.save('intent.json', {'action': 'EXPERIMENTAL_PLAYBACK_EXTRAS', 'selected_action': selected,
            'profile': describe(selected), 'writer_sha256': WRITER_PINS[selected]['sha256'],
            'selected_inspection': str(Path(argv[3])),
            'owner_confirmed_normal_english_same_body_and_other_tools_closed': True})
    action = ExtrasAction(selected, writer, previous, io)
    error, attempted = None, False
    try:
        with service_operation_lock():
            io.phase('preflight')
            existing._preflight()
            existing.guard.install_guards()
            attempted = True
            with existing.guard.research.ServiceSession(progress=lambda _: None) as session:
                action.execute(session)
    except BaseException as exc:
        error = exc
    result = {'state': action.state, 'action': selected, 'session_attempted': attempted,
              'writer_may_have_executed': action.writer_may_have_executed,
              'native_writer_result': action.native_result,
              'camera_state_uncertain': attempted, 'service_exit': existing.guard.state['exit_status'],
              'stage': existing.guard.state['phase'], 'stop_error': existing.guard.state['stop_error'],
              'shortcut_visibility_and_transfer': 'OWNER_CHECK_REQUIRED',
              'corrected_label_rendering': 'OWNER_CHECK_REQUIRED',
              'filter_execution': 'NOT_CHANGED', 'normal_camera_and_english': 'OWNER_CHECK_REQUIRED',
              'automatic_retry': False}
    if error is not None:
        result['error_chain'] = existing.guard.safe_error_chain(error)
        if not attempted and str(error) in ('Expected exactly one healthy Sony storage-mode device',
                                          'Expected pre-existing storage WinUSB binding'):
            result['preflight_error'] = str(error)
    io.save('result.json', result)
    print('RESULT:', json.dumps(result), flush=True)
    if action.state == 'READBACK_VERIFIED':
        print('Selected action readback verified across all seven complete windows. '
              'UI behavior and service exit are separate checks.', flush=True)
    if action.writer_may_have_executed and action.state != 'READBACK_VERIFIED':
        print('The writer may still be running or may have partially changed the camera. '
              'Keep camera power and USB connected. Preserve records; do not retry, '
              'send another service command, roll back, or delete staged files.', flush=True)
    elif attempted:
        print('When the access lamp is off, disconnect USB and verify normal screen, English, '
              'Network FTP and the selected playback change. Do not retry automatically.', flush=True)
    return 0 if error is None and action.state == 'READBACK_VERIFIED' else 2


if __name__ == '__main__':
    raise SystemExit(main())
