"""One explicitly selected experimental read of native playback filter records.

Offline protocol functions do not import a camera backend. The live entry point
reuses the original customizer's guarded service session. WBI coordinates are
read hypotheses; this module has no firmware-writing action.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import secrets
import struct


PROFILE = {"schema_version": 1, "sector_bytes": 512,
           "paths": ["/usr/lib/appFw.so", "/dev/nflasha5"],
           "entries": [[0, 0x04BCA200], [0, 0x04C0B400], [0, 0x04C36A00],
                       [1, 0x02514400], [1, 0x02586600], [1, 0x025C1C00]]}
PROFILE_SHA256 = "f49016db60e3ff2d74d2d36388d55e606074d463208ca3111b325ce114a41ead"
REQUEST = struct.Struct("<4sI16s32s")
RESPONSE = struct.Struct("<4sI16sIIII")
COUNT = 6
PAYLOAD_SHA256 = "18663292cc9648019cc7b2ac03e741a2c62c8c8a574e11ac7786970eaba077f9"
PAYLOAD_BYTES = 17184
PAYLOAD_PATH = (Path(__file__).resolve().parents[1] / ".data" /
                "playback-probe-native-20261104" / "playback_probe.elf")
FIELDS = (("Playback Filter Condition", 0, 0x160, 3, 0x160),
          ("FTP Transfer Status", 1, 0x112, 4, 0x112),
          ("Non-transferred", 2, 0x6A, 5, 0x6A),
          ("Failed Transfer Img.", 2, 0x10A, 5, 0x10A),
          ("Transferred status resource", 2, 0x1AA, 5, 0x1AA))


class ProbeFailure(ValueError):
    def __init__(self, status, count, failed):
        labels = {1: "Target open failed", 2: "Target read was short or failed",
                  3: "Target close failed", 4: "App type or size check failed"}
        self.details = {"status": status, "reason": labels[status],
                        "completed_reads": count, "failed_read_index": failed,
                        "path": PROFILE["paths"][PROFILE["entries"][failed][0]],
                        "offset": PROFILE["entries"][failed][1]}
        super().__init__(labels[status])


def _profile_digest():
    raw = json.dumps(PROFILE, sort_keys=True, separators=(",", ":")).encode()
    if hashlib.sha256(raw).hexdigest() != PROFILE_SHA256:
        raise ValueError("Fixed playback read profile changed")
    return bytes.fromhex(PROFILE_SHA256)


def request(nonce):
    if type(nonce) is not bytes or len(nonce) != 16 or nonce == b"\0" * 16:
        raise ValueError("A fresh 16-byte nonce is required")
    return REQUEST.pack(b"A6PQ", 1, nonce, _profile_digest())


def parse(data, nonce):
    request(nonce)
    if type(data) is bytes and len(data) == RESPONSE.size:
        magic, version, echoed, status, count, failed, flags = RESPONSE.unpack(data)
        if (magic == b"A6PR" and version == 1 and echoed == nonce and flags == 0 and
                status in (1, 2, 3, 4) and 0 <= count <= COUNT and 0 <= failed < COUNT):
            raise ProbeFailure(status, count, failed)
    if type(data) is not bytes or len(data) != RESPONSE.size + COUNT * 512:
        raise ValueError("Incomplete or oversized playback response")
    if RESPONSE.unpack_from(data) != (b"A6PR", 1, nonce, 0, COUNT, 0xFFFFFFFF, 0):
        raise ValueError("Stale, failed or unexpected playback response")
    return tuple(data[RESPONSE.size + i * 512:RESPONSE.size + (i + 1) * 512]
                 for i in range(COUNT))


def analyze(sectors):
    if (type(sectors) is not tuple or len(sectors) != COUNT or
            any(type(b) is not bytes or len(b) != 512 for b in sectors)):
        raise ValueError("Exactly six complete fixed read sectors are required")
    rows = []
    for title, app_index, app_pos, wbi_index, wbi_pos in FIELDS:
        rows.append({"menu": title,
                     "app_permission_halfword": struct.unpack_from("<H", sectors[app_index], app_pos)[0],
                     "wbi_permission_halfword_at_assumed_mapping": struct.unpack_from(
                         "<H", sectors[wbi_index], wbi_pos)[0]})
    return {"evidence": "FIXED_READ_VALUES_REQUIRE_REFERENCE_AND_DEVICE_REVIEW",
            "fields": rows, "sector_sha256": [hashlib.sha256(b).hexdigest() for b in sectors],
            "wbi_device_mapping": "ASSUMED_NOT_PROVEN_BY_NUMERIC_COORDINATES",
            "column_3_on_current_camera": "UNVERIFIED", "firmware_written": False,
            "playback_unmask": "NOT_APPLIED", "filter_framework_completeness": "UNVERIFIED"}


def load_payload():
    _profile_digest()
    data = PAYLOAD_PATH.read_bytes()
    if len(data) != PAYLOAD_BYTES or hashlib.sha256(data).hexdigest() != PAYLOAD_SHA256:
        raise RuntimeError("Playback reader does not match its reviewed build")
    return data


class OneRead:
    """Never resend after staging starts, including after a missing response."""

    def __init__(self, payload, nonce, folder, persist, phase):
        if (type(payload) is not bytes or len(payload) != PAYLOAD_BYTES or
                hashlib.sha256(payload).hexdigest() != PAYLOAD_SHA256):
            raise ValueError("Unpinned playback reader")
        self.payload, self.nonce = payload, nonce
        self.config = request(nonce)
        self.folder, self.persist, self.phase = Path(folder), persist, phase
        self.state = "READY"
        self.analysis = None

    def execute(self, session):
        if self.state != "READY":
            raise RuntimeError("This playback read has already been attempted")
        self.state = "ATTEMPTED"
        self.phase("playback request staging")
        session._file(0x4010, 0, self.config)
        self.phase("playback helper upload; constructor may execute")
        session._file(0x4007, 2, self.payload)
        self.phase("playback result retrieval")
        body = session._command(0x4008, b"\0\0\0")
        if type(body) is not bytes or len(body) > 4 + RESPONSE.size + COUNT * 512:
            raise RuntimeError("Invalid or oversized playback transport response")
        self.persist(self.folder / "transport-UNVERIFIED.bin", body)
        if len(body) < 4 or body[:4] != b"\0" * 4:
            raise RuntimeError("Playback helper transport did not complete")
        sectors = parse(body[4:], self.nonce)
        self.persist(self.folder / "response.bin", body[4:])
        self.analysis = analyze(sectors)
        self.persist(self.folder / "capture.json", (json.dumps({
            "profile_sha256": PROFILE_SHA256, "payload_sha256": PAYLOAD_SHA256,
            "nonce_hex": self.nonce.hex(), "response_sha256": hashlib.sha256(body[4:]).hexdigest(),
            "analysis": self.analysis}, indent=2, sort_keys=True) + "\n").encode())
        self.state = "PERSISTED"
        return self.analysis


def main(argv=None):
    import sys
    argv = sys.argv[1:] if argv is None else argv
    if argv == ["--self-check"]:
        load_payload()
        print(json.dumps({"status": "OFFLINE_SELF_CHECK_PASSED", "profile_sha256": PROFILE_SHA256,
                          "payload_sha256": PAYLOAD_SHA256, "camera_commands": 0}))
        return 0
    if argv == ["--transport-self-check"]:
        load_payload()
        from tools import legacy_sparse_session as existing
        existing.sparse.load_reference()
        existing.guard.guard_test()  # Synthetic only; no USB handles or service session.
        print("PINNED_TRANSPORT_IMPORT_AND_GUARD_CHECK_PASSED; CAMERA_COMMANDS=0")
        return 0
    if argv != ["--inspect-playback"]:
        raise SystemExit("Select --inspect-playback explicitly; no installation action exists")
    payload = load_payload()  # Validate local inputs before importing any device backend.
    from tools.service_operation_lock import service_operation_lock
    from tools import legacy_sparse_session as existing
    guard, sparse = existing.guard, existing.sparse
    folder = existing._create_record_directory()
    print("RECORD_DIR:", folder, flush=True)
    existing._save_json(folder, "intent.json", {
        "action": "ONE_PLAYBACK_FILTER_READ", "profile": PROFILE,
        "profile_sha256": PROFILE_SHA256, "payload_sha256": PAYLOAD_SHA256,
        "bytes": COUNT * 512, "helper_and_temporary_camera_files": True,
        "persistent_firmware_write": False, "automatic_retry_or_driver_change": False,
        "wbi_mapping": "ASSUMED_READ_COORDINATES", "full_backup": False,
        "body_identity": "OWNER_REPORT_NOT_AUTHENTICATED"})
    def phase(value):
        guard.state["phase"] = value
        print("PROGRESS:", value, flush=True)
    action = OneRead(payload, secrets.token_bytes(16), folder, sparse._write_verified, phase)
    error, attempted = None, False
    try:
        with service_operation_lock():
            phase("preflight")
            existing._preflight()
            guard.install_guards()
            attempted = True
            with guard.research.ServiceSession(progress=lambda _: None) as session:
                action.execute(session)
    except BaseException as exc:
        error = exc
    status = "STOPPED" if error is not None and action.state != "PERSISTED" else action.state
    report = {"status": status, "probe_state": action.state, "capture": action.analysis,
              "service_attempted": attempted, "service_exit": guard.state["exit_status"],
              "stage": guard.state["phase"], "stop_error": guard.state["stop_error"],
              "camera_state_uncertain": attempted, "firmware_written": False,
              "normal_camera_and_english": "OWNER_CHECK_REQUIRED_AFTER_SERVICE",
              "automatic_retry": False}
    if error is not None:
        report["error_chain"] = guard.safe_error_chain(error)
        if isinstance(error, ProbeFailure):
            report["native_failure"] = error.details
        if not attempted and str(error) in (
                "Expected exactly one healthy Sony storage-mode device",
                "Expected pre-existing storage WinUSB binding"):
            report["preflight_error"] = str(error)
    existing._save_json(folder, "result.json", report)
    print("RESULT:", json.dumps(report), flush=True)
    if action.state == "PERSISTED":
        print("Read saved. No menu change was installed. Service exit must be checked separately.", flush=True)
    if attempted:
        print("When the access lamp is off, disconnect USB and verify the normal screen and English. "
              "Preserve the report. Do not automatically repeat this read.", flush=True)
    return 0 if error is None and action.state == "PERSISTED" else 2


if __name__ == "__main__":
    raise SystemExit(main())
