"""Generate fixed experimental menu profile and read-only App hash policy."""
from apps.a6700_customizer.targets import ALL_TARGETS, APPFW_SIZE, APPFW_SHA256, TargetWindow
from tools import playback_menu_candidate as candidate
from tools import playback_probe


def profile_header():
    definition = candidate.profile_definition()
    rows, changes = [], []
    for item in definition['entries']:
        rows.append((item['offset'], item['profile_index'], len(changes), len(item['changes'])))
        changes.extend((c['position'], c['before'], c['after']) for c in item['changes'])
    if len(rows) != 6 or len(changes) != 10:
        raise ValueError('Unexpected fixed menu profile')
    return ('/* Generated fixed experimental visibility profile; not geometry proof. */\n'
            '#include "ftp_wbi_experimental_core.h"\n'
            'static const uint8_t PROFILE_DIGEST[32]={' +
            ','.join(str(x) for x in bytes.fromhex(candidate.PROFILE_SHA256)) + '};\n'
            'static const struct ftp_wbi_target TARGETS[]={\n' +
            ''.join(f' {{{off}ULL,{idx}u,{first}u,{count}u}},\n' for off, idx, first, count in rows) +
            '};\nstatic const struct ftp_wbi_change CHANGES[]={\n' +
            ''.join(f' {{{pos}u,{old}u,{new}u}},\n' for pos, old, new in changes) +
            '};\nstatic const struct ftp_wbi_profile FTP_PROFILE={TARGETS,CHANGES,PROFILE_DIGEST,6u,10u};\n')


def compatibility_targets():
    extra = [TargetWindow(playback_probe.PROFILE['entries'][app_index][1] + app_pos,
                          b'\0\0', b'\1\0', 'Experimental playback filter permission', 'ftp')
             for _title, app_index, app_pos, _wbi_index, _wbi_pos in playback_probe.FIELDS]
    fields = tuple(sorted((*ALL_TARGETS, *extra), key=lambda t: t.offset))
    if len(fields) != len(ALL_TARGETS) + 5:
        raise ValueError('Unexpected App compatibility field count')
    previous = 0
    for item in fields:
        if (not 1 <= len(item.preimage) <= 4 or len(item.preimage) != len(item.patched) or
                item.offset < previous or item.offset + len(item.preimage) > APPFW_SIZE):
            raise ValueError('Invalid or overlapping App compatibility fields')
        previous = item.offset + len(item.preimage)
    return fields


def guard_header():
    def values(raw):
        return '{' + ','.join(str(x) for x in raw) + '}'
    fields = compatibility_targets()
    return ('/* Compatibility normalization only; English bytes are never rewritten. */\n'
            '#include "ftp_app_guard.h"\n'
            f'#define FTP_GUARD_APP_SIZE {APPFW_SIZE}ULL\n'
            'static const struct ftp_guard_field ftp_guard_fields[]={\n' +
            ''.join(f' {{{t.offset}ULL,{len(t.preimage)}u,{values(t.preimage)},{values(t.patched)}}},\n'
                    for t in fields) + '};\nstatic const uint8_t ftp_guard_expected[32]=' +
            values(bytes.fromhex(APPFW_SHA256)) + ';\n')
