"""Experimental, single inspection using the previous customizer backend.

Set POWERFUL6700_ROOT to the original onedir customizer and include the workbench
and PyUSB on PYTHONPATH. Supply a new, empty durable records directory. Readback
files contain private firmware data and must never be committed. This program
does not establish firmware identity or failed-start recovery. A new device
attempt requires owner authorization; it stages a helper and temporary files.
"""
import json
import hashlib
import os
import struct
import sys
import time
from pathlib import Path

from apps.a6700_customizer import app_backend as app
from apps.a6700_customizer.ftp_usb_observer import ObservationError, read_usb_observation
from apps.a6700_customizer.ftp_usb_binding import BindingError, correlate
from a6700win import paths, research, flash
from a6700win.usb import driver, setupapi, windows_auth

_root_env = os.environ.get('POWERFUL6700_ROOT')
if not _root_env:
    raise SystemExit('Set POWERFUL6700_ROOT to the existing customizer runtime directory')
resources = Path(_root_env) / '_internal' if (Path(_root_env) / '_internal').is_dir() else Path(_root_env)
app.get_resource_root = lambda: resources
paths.bundled_root = lambda: resources
paths.ensure_vendor_on_path()
from a6700_unlock.usb import legacy

state = {'allow_stop': False, 'initial': None, 'service_correlation': None,
         'exit_status': 'NOT_SENT', 'stop_error': None, 'phase': 'preflight',
         'windows': []}
original_vendor = legacy.vendor_request_out
original_choose = legacy.choose_initial_device
original_wait = legacy.wait_for_service_device
original_read = flash.read_range
original_execute = flash._execute
original_exit = research.ServiceSession.__exit__
SAFE_OBSERVATION_MESSAGES = frozenset((
    'Required USB serial index or bus/port metadata is unavailable',
    'Incomplete or invalid USB string descriptor', 'USB observation cannot be retried',
    'Invalid USB observation inputs', 'Invalid USB observation clock',
    'USB observation deadline expired or clock is invalid', 'Selected USB mode changed before observation',
    'Oversized USB descriptor response', 'Invalid USB descriptor buffer',
    'Fresh USB device descriptor does not match the selected handle', 'USB language descriptor is invalid',
    'USB serial descriptor has an unexpected byte-order mark', 'USB descriptor or topology changed during observation',
    'USB serial is malformed, missing or a placeholder; stop without retry',
    'USB identity observation failed; stop without retry or driver changes', 'USB handle metadata is unavailable',
    'Missing, placeholder or invalid USB identity observation', 'Typed initial and service observations are required',
    'Unexpected initial or service USB mode', 'Initial/service descriptor identifiers do not match',
    'Service serial is unavailable',
))

def vendor(device, request, *, strict=False):
    if request == legacy.STOP_SENSER and not state['allow_stop']:
        raise RuntimeError('Automatic STOP withheld after an uncertain operation')
    if request == legacy.START_SENSER:
        try:
            # Only the exact historically observed PIPE stall is tolerated.
            return original_vendor(device, request, strict=True)
        except legacy.USBError as exc:
            if not strict and getattr(exc, 'errno', None) == 32 and getattr(exc, 'backend_error_code', None) == -9:
                return None
            raise
    try:
        return original_vendor(device, request, strict=strict)
    except Exception as exc:
        if request == legacy.STOP_SENSER:
            state['stop_error'] = {'type': type(exc).__name__, 'strict': strict}
            for field in ('errno', 'backend_error_code'):
                value = getattr(exc, field, None)
                if type(value) is int:
                    state['stop_error'][field] = value
        raise

def no_recovery(legacy_module, initial_pid, service_pid, progress):
    if 0x0336 in setupapi.present_pids():
        raise RuntimeError('Service mode was already present; automatic recovery withheld')
    return False

def no_driver_changes(pid, progress):
    result = setupapi.driver_state(pid)
    if not result.get('present') or not result.get('winusb'):
        raise RuntimeError('Expected pre-existing WinUSB binding is unavailable; no driver changed')
    return {'driver_changed': False}

def choose(*args, **kwargs):
    device = original_choose(*args, **kwargs)
    if device.idProduct != 0x0e76 or state['initial'] is not None:
        raise RuntimeError('Unexpected or repeated initial camera selection')
    state['phase'] = 'normal USB descriptors'
    state['initial'] = read_usb_observation(device, 3000)
    state['phase'] = 'initial authentication'
    return device

def wait_service(*args, **kwargs):
    state['phase'] = 'service device enumeration'
    device = original_wait(*args, **kwargs)
    state['phase'] = 'service USB descriptor observation'
    obs = read_usb_observation(device, 3000)
    state['phase'] = 'service descriptor correlation'
    state['service_correlation'] = correlate(state['initial'], obs, allow_service_without_serial=True)['descriptor_correlation']
    state['phase'] = 'service authentication'
    return device

def safe_error_chain(exc):
    """Retain actionable bounded observer failures without raw USB identifiers."""
    chain, seen = [], set()
    while exc is not None and id(exc) not in seen and len(chain) < 8:
        seen.add(id(exc))
        item = {'type': type(exc).__name__}
        if type(exc) in (ObservationError, BindingError) and str(exc) in SAFE_OBSERVATION_MESSAGES:
            item['detail'] = str(exc)
        if type(exc) is ObservationError and getattr(exc, 'observation_step', None) in (
                'metadata', 'device_descriptor', 'language_descriptor', 'serial_descriptor', 'repeat_device_descriptor'):
            item['observation_step'] = exc.observation_step
        if type(exc) is ObservationError and type(getattr(exc, 'backend_diagnostic', None)) is dict:
            diagnostic = exc.backend_diagnostic
            kind = diagnostic.get('type')
            if type(kind) is str and len(kind) <= 80 and kind.replace('_', '').isalnum():
                item['backend_error'] = {'type': kind}
                for field in ('errno', 'backend_error_code'):
                    if type(diagnostic.get(field)) is int:
                        item['backend_error'][field] = diagnostic[field]
                if diagnostic.get('operation') in ('open_device', 'ctrl_transfer'):
                    item['backend_error']['operation'] = diagnostic['operation']
                native = diagnostic.get('native_error_code')
                if type(native) is int and native in (*range(-12, 0), -99):
                    item['backend_error']['native_error_code'] = native
        for field in ('errno', 'backend_error_code'):
            value = getattr(exc, field, None)
            if type(value) is int:
                item[field] = value
        chain.append(item)
        exc = exc.__cause__
    return chain

def passive_usb_inventory():
    """One Windows inventory snapshot, not a camera command or exit proof."""
    try:
        rows = setupapi.devices()
        if len(rows) > 32:
            return {'status': 'INVENTORY_TOO_LARGE'}
        return {'status': 'OBSERVED', 'devices': [
            {'pid': row.get('pid'), 'os_status': row.get('status')}
            for row in rows
        ]}
    except Exception as error:
        return {'status': 'INVENTORY_UNAVAILABLE', 'error_type': type(error).__name__}

def read_range(backend, path, offset, length, elf=None):
    state['phase'] = 'App window inspection'
    data = original_read(backend, path, offset, length, elf)
    if type(data) is not bytes or len(data) != length:
        raise RuntimeError('Incomplete App window response; no retry')
    capture_window(folder, offset, data)
    return data

def capture_window(record_dir, offset, data):
    """Retain complete private device readback before any service-exit attempt."""
    filename = 'window-%02d-%08x-%d.bin' % (len(state['windows']) + 1, offset, len(data))
    destination = record_dir / filename
    with destination.open('xb') as output:
        output.write(data)
        output.flush()
        os.fsync(output.fileno())
    if destination.read_bytes() != data:
        raise RuntimeError('Local readback of the captured window failed')
    entry = {'file': filename, 'offset': offset, 'length': len(data),
             'sha256': hashlib.sha256(data).hexdigest()}
    manifest = destination.with_suffix('.json')
    metadata = (json.dumps(entry, sort_keys=True) + '\n').encode('utf-8')
    with manifest.open('xb') as output:
        output.write(metadata)
        output.flush()
        os.fsync(output.fileno())
    if manifest.read_bytes() != metadata:
        raise RuntimeError('Local readback of the window manifest failed')
    state['windows'].append(entry)

def read_only_execute(backend, elf, config):
    if len(config) < flash.HEADER:
        raise RuntimeError('Incomplete helper request; no camera command sent')
    magic, version, mode, pathlen, offset, length = struct.unpack_from('<4sIIIQI', config)
    if (magic != flash.MAGIC or version != flash.VERSION or mode not in (flash.MODE_READ, flash.MODE_SIZE)
            or config[flash.HEADER:] != b'/usr/lib/appFw.so' or pathlen != len(config[flash.HEADER:])):
        raise RuntimeError('Non-inspection helper request rejected')
    state['phase'] = 'App file size inspection' if mode == flash.MODE_SIZE else 'App window inspection'
    blob = original_execute(backend, elf, config)
    if len(blob) < flash.HEADER:
        raise RuntimeError('Incomplete helper response header')
    result_magic, result_version, status, result_mode, size, result_length = struct.unpack_from('<4sIIIQI', blob)
    if result_magic != flash.MAGIC or result_version != flash.VERSION or result_mode != mode:
        raise RuntimeError('Helper response header did not match the request')
    if status:
        raise RuntimeError('Helper returned status %d, phase %d' % (status, result_length))
    expected_length = length if mode == flash.MODE_READ else 0
    if result_length != expected_length or len(blob) != flash.HEADER + expected_length:
        raise RuntimeError('Incomplete or unexpected helper response length')
    return blob

def exit_session(self, typ, value, tb):
    if typ is not None:
        state['exit_status'] = 'WITHHELD_AFTER_ERROR'
        if self.target is not None:
            self.legacy.close_target(self.target)
        return False
    state['phase'] = 'service exit'
    state['allow_stop'] = True
    try:
        result = original_exit(self, typ, value, tb)
    finally:
        state['allow_stop'] = False
    state['exit_status'] = self.cleanup_status
    if self.cleanup_status != 'stop-sent':
        raise RuntimeError('Normal service exit was not acknowledged')
    return result

def guard_test():
    global original_execute
    class Fake:
        target = object()
        class Legacy:
            def close_target(self, target): pass
        legacy = Legacy()
    assert exit_session(Fake(), RuntimeError, RuntimeError(), None) is False
    assert state['exit_status'] == 'WITHHELD_AFTER_ERROR'
    try:
        vendor(None, legacy.STOP_SENSER)
    except RuntimeError:
        pass
    else:
        raise AssertionError('Automatic STOP guard failed')
    saved = original_execute
    try:
        original_execute = lambda *_: struct.pack('<4sIIIQI', flash.MAGIC, 1, 0, 0, 0, 3) + b'abc'
        request = flash._request('/usr/lib/appFw.so', 0, 3, flash.MODE_READ)
        assert read_only_execute(None, b'', request).endswith(b'abc')
        original_execute = lambda *_: struct.pack('<4sIIIQI', flash.MAGIC, 1, 0, 0, 0, 3) + b'ab'
        try:
            read_only_execute(None, b'', request)
        except RuntimeError:
            pass
        else:
            raise AssertionError('Incomplete response accepted')
        request = flash._request('/usr/lib/appFw.so', 0, 3, flash.MODE_WRITE)
        try:
            read_only_execute(None, b'', request)
        except RuntimeError:
            pass
        else:
            raise AssertionError('Write mode accepted')
    finally:
        original_execute = saved
    print('GUARD_SELF_TEST_PASS')

def install_guards():
    legacy.vendor_request_out = vendor
    legacy.choose_initial_device = choose
    legacy.wait_for_service_device = wait_service
    windows_auth._recover_service_mode = no_recovery
    driver.ensure_pid = no_driver_changes
    flash.read_range = read_range
    flash._execute = read_only_execute
    research.ServiceSession.__exit__ = exit_session


def main(argv=None):
    global folder
    if argv is None:
        argv = sys.argv[1:]
    if argv == ['--self-test']:
        guard_test()
        return
    if len(argv) != 1:
        raise SystemExit('Provide one empty durable records directory')
    folder = Path(argv[0])
    if not folder.is_dir() or any(folder.iterdir()):
        raise SystemExit('A new empty durable records directory is required')
    rows = setupapi.devices()
    if len(rows) != 1 or rows[0].get('pid') != 0x0e76 or rows[0].get('status') != 'OK':
        raise SystemExit('Expected exactly one Sony storage-mode device')
    binding = setupapi.driver_state(0x0e76)
    if not binding.get('present') or not binding.get('winusb'):
        raise SystemExit('Expected existing storage WinUSB driver is unavailable')

    intent = {'action': 'ONE_READ_ONLY_INSPECTION', 'ftp_write': False,
              'camera_temporary_files_and_helper': True, 'automatic_recovery': False,
              'driver_install': False, 'source': 'original customizer backend and bundled dependencies'}
    def save(name, data):
        path = folder / name
        blob = (json.dumps(data, ensure_ascii=False, indent=2, sort_keys=True) + '\n').encode('utf-8')
        with path.open('xb') as f:
            f.write(blob); f.flush(); os.fsync(f.fileno())
        if path.read_bytes() != blob: raise RuntimeError('Local report readback mismatch')
    save('intent.json', intent)
    install_guards()
    try:
        backend = app.DeviceBackend(state_dir=folder / 'state')
        result = backend.inspect_device(progress=lambda text: print('PROGRESS:', text, flush=True))
        targets = {f'0x{offset:08x}': {'status': item['status'], 'actual': item['actual_bytes']}
                   for offset, item in result['details'].items()}
        if len(targets) != 92: raise RuntimeError('Incomplete target count')
        deadline = time.monotonic() + 20
        normal = False
        while time.monotonic() < deadline:
            devices = setupapi.devices()
            if len(devices) == 1 and devices[0].get('pid') == 0x0e76:
                normal = True; break
            time.sleep(0.25)
        report = {'status': 'READ_COMPLETED' if normal else 'EXIT_UNCONFIRMED',
                  'service_exit': state['exit_status'], 'normal_usb_mode': normal,
                  'descriptor_correlation': state['service_correlation'],
                  'identity': 'TOPOLOGY_AND_DESCRIPTOR_CORRELATION_NOT_ATTESTATION',
                  'app_compatibility': 'SIZE_AND_TARGET_BYTES_ONLY',
                  'english_status': result['english_status'], 'ftp_status': result['ftp_status'],
                  'ftp_transfer': 'UNVERIFIED', 'windows': state['windows'], 'targets': targets}
        save('inspection.json', report)
        print('RESULT:', json.dumps({k:v for k,v in report.items() if k != 'targets'}), flush=True)
    except BaseException as exc:
        report = {'status': 'STOPPED', 'stage': state['phase'], 'camera_state_uncertain': True,
                  'service_exit': state['exit_status'], 'error_type': type(exc).__name__,
                  'stop_error': state['stop_error'], 'windows': state['windows'],
                  'descriptor_correlation': state['service_correlation'],
                  'error_chain': safe_error_chain(exc),
                  'passive_usb_inventory': passive_usb_inventory()}
        save('inspection.json', report)
        print('RESULT:', json.dumps(report), flush=True)
        raise SystemExit(2)


if __name__ == '__main__':
    main()
