"""Audit an explicitly selected saved playback probe capture, entirely offline.

Only ordinary local files are read. No device backend, USB, service, process,
network or write API is imported or invoked. Output omits paths, nonce and raw
firmware. A consistent saved nonce does not prove pre-staging freshness.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from tools import playback_probe as protocol


APP_SIZE = 89027992
APP_SHA256 = "e65fd595052be5d0e98ce8000dfcb94f90a2f8309de70ef140375052009b0ef3"
WBI_SIZE = 248376320
WBI_SHA256 = "bba227d90fb947642618017e109d544069be2687985b6be1f2b84f2766a85885"
PROFILE_SHA256 = "f49016db60e3ff2d74d2d36388d55e606074d463208ca3111b325ce114a41ead"
PAYLOAD_BYTES = 17184
PAYLOAD_SHA256 = "18663292cc9648019cc7b2ac03e741a2c62c8c8a574e11ac7786970eaba077f9"
FILE_LIMITS = {"capture.json": 32768, "intent.json": 32768, "result.json": 32768,
               "response.bin": 3112, "transport-UNVERIFIED.bin": 3116}


def _sha(data):
    return hashlib.sha256(data).hexdigest()


def _object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate metadata key")
        result[key] = value
    return result


def _json(data):
    result = json.loads(data, object_pairs_hook=_object)
    if type(result) is not dict:
        raise ValueError("Metadata must be a JSON object")
    return result


def _protocol_pins():
    profile = json.dumps(protocol.PROFILE, sort_keys=True, separators=(",", ":")).encode()
    if (_sha(profile) != PROFILE_SHA256 or protocol.PROFILE_SHA256 != PROFILE_SHA256 or
            protocol.PAYLOAD_SHA256 != PAYLOAD_SHA256 or protocol.PAYLOAD_BYTES != PAYLOAD_BYTES):
        raise ValueError("Playback protocol or native payload pin changed")


def _validate_records(files):
    _protocol_pins()
    if set(files) != set(FILE_LIMITS):
        raise ValueError("Exactly the five fixed capture files are required")
    if any(type(data) is not bytes or len(data) > FILE_LIMITS[name] for name, data in files.items()):
        raise ValueError("Capture input type or byte limit mismatch")
    capture, intent, result = (_json(files[name]) for name in ("capture.json", "intent.json", "result.json"))
    if (capture.get("profile_sha256") != PROFILE_SHA256 or intent.get("profile_sha256") != PROFILE_SHA256 or
            capture.get("payload_sha256") != PAYLOAD_SHA256 or intent.get("payload_sha256") != PAYLOAD_SHA256 or
            intent.get("profile") != protocol.PROFILE):
        raise ValueError("Saved profile or payload metadata mismatch")
    required_intent = {"action": "ONE_PLAYBACK_FILTER_READ", "bytes": 3072,
                       "helper_and_temporary_camera_files": True, "persistent_firmware_write": False,
                       "automatic_retry_or_driver_change": False, "wbi_mapping": "ASSUMED_READ_COORDINATES",
                       "full_backup": False, "body_identity": "OWNER_REPORT_NOT_AUTHENTICATED"}
    for key, value in required_intent.items():
        if type(intent.get(key)) is not type(value) or intent[key] != value:
            raise ValueError("Saved operation intent does not match the read-only probe")
    nonce_hex = capture.get("nonce_hex")
    if type(nonce_hex) is not str or re.fullmatch(r"[0-9a-f]{32}", nonce_hex) is None:
        raise ValueError("Malformed saved nonce")
    nonce = bytes.fromhex(nonce_hex)
    data = files["response.bin"]
    if _sha(data) != capture.get("response_sha256"):
        raise ValueError("Saved response digest mismatch")
    if files["transport-UNVERIFIED.bin"] != bytes(4) + data:
        raise ValueError("Saved transport and response disagree")
    sectors = protocol.parse(data, nonce)
    analysis = protocol.analyze(sectors)
    if capture.get("analysis") != analysis or result.get("capture") != analysis:
        raise ValueError("Saved analysis does not match recomputed response values")
    if (result.get("status") != "PERSISTED" or result.get("service_attempted") is not True or
            result.get("firmware_written") is not False or result.get("automatic_retry") is not False or
            type(result.get("camera_state_uncertain")) is not bool):
        raise ValueError("Saved result does not match a persisted read-only attempt")
    exit_status = result.get("service_exit")
    if exit_status not in ("unconfirmed", "stop-sent", "NOT_SENT", "WITHHELD_AFTER_ERROR"):
        raise ValueError("Unrecognized saved service exit status")
    stop = result.get("stop_error")
    safe_stop = None
    if stop is not None:
        if type(stop) is not dict:
            raise ValueError("Malformed saved stop error")
        safe_stop = {key: stop[key] for key in ("errno", "backend_error_code") if type(stop.get(key)) is int}
    return {"evidence_class": "device-readback-saved-record-audit",
            "profile_sha256": PROFILE_SHA256, "recorded_payload_sha256": PAYLOAD_SHA256,
            "response_sha256": _sha(data), "protocol_checks": "PASSED",
            "saved_nonce_valid_and_echoed": True, "response_sectors": len(sectors),
            "response_sector_bytes": 512, "permissions": analysis["fields"],
            "record_status": {"capture": "PERSISTED", "service_exit": exit_status,
                              "camera_state_uncertain": result["camera_state_uncertain"],
                              "firmware_written": False, "automatic_retry": False,
                              "stop_error": safe_stop},
            "limitations": [
                "Matching saved nonce metadata and response do not prove request freshness or pre-staging persistence.",
                "Saved hashes are not authenticated camera identity or a tamper-proof acquisition record.",
                "WBI device coordinates remain assumed; matching sectors do not establish physical write geometry, integrity handling or recovery.",
                "This audit does not establish normal camera operation, English operation, a visible playback menu or successful FTP transfer."],
            "camera_operations_by_this_audit": 0}, sectors


def validate_records(files):
    """Validate in-memory capture files and return sanitized metadata only."""
    return _validate_records(files)[0]


def _identity(info):
    return info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns


def _ordinary_file(path):
    path = Path(path)
    if str(path).startswith(("\\\\", "//")):
        raise ValueError("An ordinary local file is required")
    info = path.lstat()
    if (not stat.S_ISREG(info.st_mode) or stat.S_ISLNK(info.st_mode) or
            getattr(info, "st_file_attributes", 0) & 0x400):
        raise ValueError("An ordinary local non-reparse file is required")
    return path, info


def _read_metadata(path, limit):
    path, prior = _ordinary_file(path)
    if prior.st_size > limit:
        raise ValueError("Capture file exceeds its fixed byte limit")
    with path.open("rb") as stream:
        if _identity(os.fstat(stream.fileno())) != _identity(prior):
            raise ValueError("Capture file changed before reading")
        data = stream.read(limit + 1)
        after = os.fstat(stream.fileno())
    if len(data) != prior.st_size or len(data) > limit or _identity(after) != _identity(prior):
        raise ValueError("Capture file changed while reading")
    return data


def _reference_content(stream, expected_size, expected_digest, offsets):
    """Hash the entire stream before returning any requested reference sectors."""
    digest, count = hashlib.sha256(), 0
    stream.seek(0)
    while True:
        chunk = stream.read(1048576)
        if not chunk:
            break
        count += len(chunk)
        if count > expected_size:
            raise ValueError("Reference exceeds its pinned complete size")
        digest.update(chunk)
    if count != expected_size or digest.hexdigest() != expected_digest:
        raise ValueError("Complete reference size or digest mismatch")
    sectors = []
    for offset in offsets:
        if type(offset) is not int or offset < 0 or offset + 512 > expected_size:
            raise ValueError("Reference sector is outside the complete image")
        stream.seek(offset)
        data = stream.read(512)
        if len(data) != 512:
            raise ValueError("Incomplete reference sector")
        sectors.append(data)
    return tuple(sectors)


def _read_reference(path, size, digest, offsets):
    path, prior = _ordinary_file(path)
    if prior.st_size != size:
        raise ValueError("Reference file has the wrong complete size")
    with path.open("rb") as stream:
        if _identity(os.fstat(stream.fileno())) != _identity(prior):
            raise ValueError("Reference changed before reading")
        result = _reference_content(stream, size, digest, offsets)
        after = os.fstat(stream.fileno())
    if _identity(after) != _identity(prior):
        raise ValueError("Reference changed while reading")
    return result


def _compare(sectors, reference):
    if len(sectors) != 6 or len(reference) != 6 or any(len(b) != 512 for b in (*sectors, *reference)):
        raise ValueError("Exactly six complete sectors are required for comparison")
    rows = []
    for i, (actual, expected) in enumerate(zip(sectors, reference)):
        differences = sum(a != b for a, b in zip(actual, expected))
        rows.append({"index": i, "domain": "APP_FILE" if i < 3 else "WBI_ASSUMED_DEVICE_COORDINATES",
                     "sector_sha256": _sha(actual), "reference_exact": differences == 0,
                     "different_bytes": differences})
    return {"sectors_compared": 6, "bytes_compared": 3072,
            "matching_sectors": sum(row["reference_exact"] for row in rows),
            "different_bytes": sum(row["different_bytes"] for row in rows), "sectors": rows}


def analyze(capture_directory, app_reference, wbi_reference, native_payload=None):
    """Read explicitly supplied files and return only sanitized audit results."""
    directory = Path(capture_directory)
    files = {name: _read_metadata(directory / name, limit) for name, limit in FILE_LIMITS.items()}
    report, sectors = _validate_records(files)
    app = _read_reference(app_reference, APP_SIZE, APP_SHA256,
                          [offset for which, offset in protocol.PROFILE["entries"] if which == 0])
    wbi = _read_reference(wbi_reference, WBI_SIZE, WBI_SHA256,
                          [offset for which, offset in protocol.PROFILE["entries"] if which == 1])
    report["complete_reference_sha256"] = {"app": APP_SHA256, "decoded_wbi": WBI_SHA256}
    report["reference_comparison"] = _compare(sectors, app + wbi)
    report["independently_supplied_native_payload_verified"] = False
    if native_payload is not None:
        payload = _read_metadata(native_payload, PAYLOAD_BYTES)
        if len(payload) != PAYLOAD_BYTES or _sha(payload) != PAYLOAD_SHA256:
            raise ValueError("Explicit native payload does not match its pin")
        report["independently_supplied_native_payload_verified"] = True
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--capture-directory", type=Path, required=True)
    parser.add_argument("--app-reference", type=Path, required=True)
    parser.add_argument("--wbi-reference", type=Path, required=True)
    parser.add_argument("--native-payload", type=Path)
    args = parser.parse_args()
    try:
        result = analyze(args.capture_directory, args.app_reference, args.wbi_reference, args.native_payload)
    except (OSError, ValueError, KeyError, TypeError) as exc:
        print(json.dumps({"status": "STOPPED", "error_type": type(exc).__name__}))
        return 2
    print(json.dumps({"status": "AUDITED_SAVED_CAPTURE", **result}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
