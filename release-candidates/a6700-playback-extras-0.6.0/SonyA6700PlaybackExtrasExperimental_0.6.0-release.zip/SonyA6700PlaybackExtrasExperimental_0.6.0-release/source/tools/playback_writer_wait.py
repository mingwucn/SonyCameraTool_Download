"""Scoped response wait for the one experimental writer helper; no USB imports.

The existing Senser send/frame/parser code is retained. Only its explicit
10,000 ms device read/write timeouts become 180,000 ms during this scope.
This does not cancel a camera helper or interrupt a blocked kernel operation.
"""
from contextlib import contextmanager


HELPER_RESPONSE_WAIT_MS = 180000
INHERITED_TRANSFER_WAIT_MS = 10000


class _DeviceWait:
    def __init__(self, device):
        self._device = device

    def __getattr__(self, name):
        return getattr(self._device, name)

    @staticmethod
    def _arguments(args, kwargs):
        if type(kwargs.get('timeout')) is int and kwargs['timeout'] == INHERITED_TRANSFER_WAIT_MS:
            kwargs = dict(kwargs, timeout=HELPER_RESPONSE_WAIT_MS)
        elif (len(args) >= 3 and type(args[2]) is int and
              args[2] == INHERITED_TRANSFER_WAIT_MS and 'timeout' not in kwargs):
            args = (*args[:2], HELPER_RESPONSE_WAIT_MS, *args[3:])
        return args, kwargs

    def read(self, *args, **kwargs):
        args, kwargs = self._arguments(args, kwargs)
        return self._device.read(*args, **kwargs)

    def write(self, *args, **kwargs):
        args, kwargs = self._arguments(args, kwargs)
        return self._device.write(*args, **kwargs)


class _TargetWait:
    def __init__(self, target):
        self._target = target
        self.device = _DeviceWait(target.device)

    def __getattr__(self, name):
        return getattr(self._target, name)


@contextmanager
def helper_response_wait(session):
    """Proxy only the established channel target; restore it even on failure.

    Authentication, STOP, staging and independent readback remain outside this
    scope. Refuse an unrecognized session before uploading the writer helper.
    The shared operation lock must already be held by the caller.
    """
    channel = getattr(session, 'channel', None)
    target = getattr(channel, 'target', None)
    device = getattr(target, 'device', None)
    if (target is None or target is not getattr(session, 'target', None) or
            isinstance(target, _TargetWait) or not callable(getattr(channel, 'send', None)) or
            not callable(getattr(device, 'read', None)) or not callable(getattr(device, 'write', None))):
        raise RuntimeError('Unrecognized writer service channel; helper upload withheld')
    channel.target = _TargetWait(target)
    try:
        yield
    finally:
        channel.target = target
