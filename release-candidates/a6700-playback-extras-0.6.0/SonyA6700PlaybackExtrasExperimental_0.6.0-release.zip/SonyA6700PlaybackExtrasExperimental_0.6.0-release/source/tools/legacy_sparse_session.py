"""Experimental single sparse read through the original customizer session.

The bundled fixed-profile reader opens three devices read-only and reads 260
sectors (158 App, 99 WBI-candidate, 3 CP). It stages helper/request/result files
on the camera. This is not a full backup. WBI offset equivalence is unverified.
Raw output is private. Invoke only for a separately selected device operation.
"""
import json
import ctypes
from ctypes import wintypes
import base64
import os
import secrets
import subprocess
import sys
import time
from pathlib import Path

from tools import inspect_legacy_customizer as guard
from tools import legacy_sparse_wbi as sparse


# Four transport-status bytes plus the fixed native response.
MAX_TRANSPORT_BYTES = 4 + 44 + sparse.SECTOR_COUNT * sparse.SECTOR_BYTES


def _localappdata_directory():
    if sys.platform != 'win32':
        raise RuntimeError('Sparse session is supported only on Windows')
    buffer = ctypes.create_unicode_buffer(32768)
    shell = ctypes.WinDLL('shell32', use_last_error=True)
    shell.SHGetFolderPathW.argtypes = [wintypes.HWND, ctypes.c_int, wintypes.HANDLE,
                                      wintypes.DWORD, wintypes.LPWSTR]
    shell.SHGetFolderPathW.restype = ctypes.c_long
    if shell.SHGetFolderPathW(None, 28, None, 0, buffer) != 0:
        raise RuntimeError('Cannot resolve the current user LocalAppData directory')
    return Path(buffer.value)


def _validate_record_root(root, localappdata):
    """Reject network/removable/reparse targets before inspecting access rules."""
    root, localappdata = Path(root), Path(localappdata)
    if sys.platform != 'win32' or not root.is_absolute() or not localappdata.is_absolute():
        raise RuntimeError('A local Windows LocalAppData path is required')
    if root != localappdata / 'SonyA6700PrivateSparse' or not localappdata.is_dir():
        raise RuntimeError('Expected the current user LocalAppData directory')
    if not root.drive or root.drive.startswith('\\\\'):
        raise RuntimeError('Network or unanchored evidence paths are not accepted')
    kernel = ctypes.WinDLL('kernel32', use_last_error=True)
    kernel.GetDriveTypeW.argtypes = [wintypes.LPCWSTR]
    kernel.GetDriveTypeW.restype = wintypes.UINT
    kernel.GetFileAttributesW.argtypes = [wintypes.LPCWSTR]
    kernel.GetFileAttributesW.restype = wintypes.DWORD
    if kernel.GetDriveTypeW(root.anchor) != 3:  # DRIVE_FIXED
        raise RuntimeError('Evidence volume is not a local fixed drive')
    for current in (localappdata, *localappdata.parents):
        attributes = kernel.GetFileAttributesW(str(current))
        if attributes == 0xffffffff or attributes & 0x400:  # INVALID / REPARSE_POINT
            raise RuntimeError('Evidence path is missing or contains a reparse point')
    if os.path.normcase(os.path.abspath(localappdata)) != os.path.normcase(str(localappdata.resolve(strict=True))):
        raise RuntimeError('Evidence path resolves to an unexpected location')
    return root


_ACL_SCRIPT = r'''
$ErrorActionPreference = 'Stop'
$path = $env:SONY_SPARSE_ACL_PATH
$operation = $env:SONY_SPARSE_ACL_OPERATION
$userSid = [System.Security.Principal.WindowsIdentity]::GetCurrent().User
$systemSid = New-Object System.Security.Principal.SecurityIdentifier('S-1-5-18')
$adminSid = New-Object System.Security.Principal.SecurityIdentifier('S-1-5-32-544')
$allowed = @($userSid.Value, $systemSid.Value, $adminSid.Value)
if ($operation -eq 'set') {
  $acl = New-Object System.Security.AccessControl.DirectorySecurity
  $acl.SetOwner($userSid)
  $acl.SetAccessRuleProtection($true, $false)
  $inheritance = [System.Security.AccessControl.InheritanceFlags]'ContainerInherit, ObjectInherit'
  foreach ($sid in @($userSid, $systemSid, $adminSid)) {
    $rule = New-Object System.Security.AccessControl.FileSystemAccessRule($sid,
      [System.Security.AccessControl.FileSystemRights]::FullControl, $inheritance,
      [System.Security.AccessControl.PropagationFlags]::None,
      [System.Security.AccessControl.AccessControlType]::Allow)
    $acl.AddAccessRule($rule)
  }
  [System.IO.Directory]::SetAccessControl($path, $acl)
} elseif ($operation -ne 'verify' -and $operation -ne 'parent') { throw 'Invalid operation' }
$check = [System.IO.Directory]::GetAccessControl($path)
if ($check.GetOwner([System.Security.Principal.SecurityIdentifier]).Value -ne $userSid.Value) {
  throw 'Unexpected owner'
}
$rules = @($check.GetAccessRules($true, $true, [System.Security.Principal.SecurityIdentifier]))
if ($operation -eq 'parent') {
  $danger = [int64](2 + 4 + 16 + 64 + 256 + 65536 + 262144 + 524288)
  foreach ($rule in $rules) {
    if ($rule.AccessControlType -eq 'Allow' -and $rule.IdentityReference.Value -notin $allowed -and
        (([int64]$rule.FileSystemRights -band $danger) -ne 0)) { throw 'Untrusted parent write access' }
  }
} else {
  if (-not $check.AreAccessRulesProtected -or $rules.Count -ne 3) { throw 'Unexpected ACL' }
  foreach ($sid in $allowed) {
    $matched = @($rules | Where-Object { $_.IdentityReference.Value -eq $sid })
    if ($matched.Count -ne 1 -or $matched[0].IsInherited -or
        $matched[0].AccessControlType -ne 'Allow' -or
        (([int64]$matched[0].FileSystemRights -band 2032127) -ne 2032127) -or
        ([int]$matched[0].InheritanceFlags -ne 3)) { throw 'Unexpected ACL rule' }
  }
}
'''


def _acl_operation(path, operation):
    if operation not in ('parent', 'set', 'verify'):
        raise ValueError('Invalid evidence ACL operation')
    system_root = os.environ.get('SystemRoot')
    if not system_root:
        raise RuntimeError('Cannot locate Windows PowerShell for ACL validation')
    executable = Path(system_root) / 'System32' / 'WindowsPowerShell' / 'v1.0' / 'powershell.exe'
    env = os.environ.copy()
    env['SONY_SPARSE_ACL_PATH'] = str(path)
    env['SONY_SPARSE_ACL_OPERATION'] = operation
    encoded = base64.b64encode(_ACL_SCRIPT.encode('utf-16-le')).decode('ascii')
    try:
        completed = subprocess.run([str(executable), '-NoProfile', '-NonInteractive', '-EncodedCommand', encoded],
                                   env=env, stdin=subprocess.DEVNULL, capture_output=True, timeout=20, check=False)
    except (OSError, subprocess.TimeoutExpired) as exc:
        raise RuntimeError('Evidence access-control validation failed') from exc
    if completed.returncode:
        raise RuntimeError('Evidence access-control validation failed')


def _assert_non_reparse(path):
    kernel = ctypes.WinDLL('kernel32', use_last_error=True)
    kernel.GetFileAttributesW.argtypes = [wintypes.LPCWSTR]
    kernel.GetFileAttributesW.restype = wintypes.DWORD
    attributes = kernel.GetFileAttributesW(str(path))
    if attributes == 0xffffffff or attributes & 0x400 or not path.is_dir():
        raise RuntimeError('Evidence path is missing or contains a reparse point')


def _create_record_directory():
    localappdata = _localappdata_directory()
    root = _validate_record_root(localappdata / 'SonyA6700PrivateSparse', localappdata)
    _acl_operation(localappdata, 'parent')
    if root.exists():
        _assert_non_reparse(root)
        _acl_operation(root, 'verify')
    else:
        root.mkdir(mode=0o700)
        _assert_non_reparse(root)
        _acl_operation(root, 'set')
    _assert_non_reparse(root)
    _acl_operation(root, 'verify')
    name = time.strftime('%Y%m%d-%H%M%S') + '-legacy-wbi-' + secrets.token_hex(8)
    destination = root / name
    destination.mkdir(mode=0o700)  # Exclusive directory creation; no retry.
    _assert_non_reparse(destination)
    _acl_operation(destination, 'set')
    _assert_non_reparse(destination)
    _acl_operation(destination, 'verify')
    if destination.resolve(strict=True).parent != root.resolve(strict=True) or any(destination.iterdir()):
        raise RuntimeError('New evidence directory is not empty and local')
    return destination


class OneSparseRead:
    """One fixed read; stages camera files but has no firmware/settings write action."""

    def __init__(self, intent, record_dir):
        expected = sparse.prepare(intent.profile, intent.reader, nonce=intent.nonce)
        if (type(intent) is not sparse.SparseReadIntent or intent.request != expected.request
                or intent.reader != expected.reader or intent.nonce != expected.nonce):
            raise ValueError('Invalid fixed-profile read intent')
        self.intent = intent
        self.record_dir = Path(record_dir)
        self.state = 'READY'
        self.response = None
        self.metadata = None

    def execute(self, session):
        if self.state != 'READY':
            raise RuntimeError('Sparse reader cannot be attempted twice')
        self.state = 'LOCKED'
        guard.state['phase'] = 'sparse request staging'
        session._file(0x4010, 0, self.intent.request)
        guard.state['phase'] = 'sparse helper upload; constructor may execute'
        session._file(0x4007, 2, self.intent.reader)
        guard.state['phase'] = 'sparse 0x4008 result retrieval; execution timing unverified'
        body = session._command(0x4008, bytes([0, 0, 0]))
        if type(body) is not bytes or len(body) > MAX_TRANSPORT_BYTES:
            raise RuntimeError('Invalid or oversized sparse transport response')
        # Even a malformed response can be useful evidence. It stays private
        # and is explicitly unverified; never delete or overwrite it.
        sparse._write_verified(self.record_dir / 'sparse-transport-UNVERIFIED.bin', body)
        if len(body) < 4 or body[:4] != b'\0' * 4:
            raise RuntimeError('Sparse helper returned incomplete or failed transport status')
        guard.state['phase'] = 'sparse response validation and host persistence'
        data = body[4:]
        metadata = sparse.persist(self.record_dir, self.intent, data)
        self.response, self.metadata = data, metadata
        self.state = 'PERSISTED'
        return metadata


def _save_json(record_dir, name, obj):
    data = (json.dumps(obj, sort_keys=True, indent=2) + '\n').encode('utf-8')
    sparse._write_verified(record_dir / name, data)


def _preflight():
    rows = guard.setupapi.devices()
    if len(rows) != 1 or rows[0].get('pid') != 0x0e76 or rows[0].get('status') != 'OK':
        raise RuntimeError('Expected exactly one healthy Sony storage-mode device')
    driver_state = guard.setupapi.driver_state(0x0e76)
    if not driver_state.get('present') or not driver_state.get('winusb'):
        raise RuntimeError('Expected pre-existing storage WinUSB binding')


def _connection_outcome(error, session_attempted, inventory):
    observed = (inventory.get('status') == 'OBSERVED' and inventory.get('devices') == [
        {'pid': 0x0e76, 'os_status': 'OK'}])
    status = 'STOPPED' if error else ('READ_COMPLETED' if observed else 'EXIT_UNCONFIRMED')
    return status, session_attempted, observed


def main(argv=None):
    if argv is None:
        argv = sys.argv[1:]
    if argv != ['--sparse-wbi']:
        raise SystemExit('Explicit --sparse-wbi selection is required')
    # Pin and generate the nonce-bound read before any camera access.
    profile, reader = sparse.load_reference()
    intent = sparse.prepare(profile, reader)
    folder = _create_record_directory()
    print('RECORD_DIR:', folder, flush=True)
    action = OneSparseRead(intent, folder)
    _save_json(folder, 'intent.json', {
        'action': 'ONE_SPARSE_READ', 'camera_helper_and_temporary_files': True,
        'firmware_write': False, 'automatic_retry_or_recovery': False,
        'driver_install': False, 'sectors': 260, 'bytes': 133120,
        'device_sector_counts': {'app': 158, 'wbi_candidate': 99, 'cp': 3},
        'wbi_mapping': 'UNVERIFIED_UPSTREAM_ASSUMPTION',
        'full_backup': False, 'failed_start_recovery': 'UNVERIFIED',
        'record_storage': 'LOCALAPPDATA_FIXED_NO_REPARSE_PROTECTED_DACL_PHYSICAL_DEVICE_UNATTESTED',
    })
    error = None
    session_attempted = False
    try:
        guard.state['phase'] = 'preflight'
        _preflight()
        guard.install_guards()
        session_attempted = True
        with guard.research.ServiceSession(progress=lambda _: print('PROGRESS: original service session', flush=True)) as session:
            action.execute(session)
    except BaseException as exc:
        error = exc

    analysis = None
    analysis_failed = False
    if action.state == 'PERSISTED':
        try:
            analysis = sparse.classify(intent, action.response)
            _save_json(folder, 'sparse-analysis.json', analysis)
        except Exception as exc:
            analysis_failed = True
            analysis = {'status': 'CLASSIFICATION_FAILED', 'error_type': type(exc).__name__}
    inventory = guard.passive_usb_inventory()
    status, uncertain, observed_normal = _connection_outcome(error, session_attempted, inventory)
    if analysis_failed and status == 'READ_COMPLETED':
        status = 'ANALYSIS_FAILED'
    report = {
        'status': status,
        'camera_state_uncertain': uncertain,
        'stage': guard.state['phase'], 'service_exit': guard.state['exit_status'],
        'stop_error': guard.state['stop_error'],
        'descriptor_correlation': guard.state['service_correlation'],
        'capture_state': action.state, 'analysis': analysis,
        'passive_usb_inventory': inventory,
        'normal_storage_interface_observed': observed_normal,
        'normal_camera_operation': 'UNVERIFIED',
        'model_firmware_and_body_identity': 'UNVERIFIED',
        'ftp_transfer': 'UNVERIFIED',
    }
    if error is not None:
        report['error_chain'] = guard.safe_error_chain(error)
        if not session_attempted and str(error) in (
                'Expected exactly one healthy Sony storage-mode device',
                'Expected pre-existing storage WinUSB binding'):
            report['preflight_error'] = str(error)
    _save_json(folder, 'inspection.json', report)
    print('RESULT:', json.dumps(report), flush=True)
    if error is not None or not observed_normal or analysis_failed:
        raise SystemExit(2)


if __name__ == '__main__':
    main()
