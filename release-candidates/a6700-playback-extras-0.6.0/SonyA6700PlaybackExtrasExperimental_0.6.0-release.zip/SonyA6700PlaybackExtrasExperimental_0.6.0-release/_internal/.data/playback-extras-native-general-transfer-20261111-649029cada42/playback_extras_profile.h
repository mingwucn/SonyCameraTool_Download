/* Fixed independent playback extras profile; not physical geometry proof. */
#include "ftp_wbi_experimental_core.h"
#define EXTRAS_ACTION 3u
#define EXTRAS_TARGET_COUNT 1u
#define EXTRAS_CHANGE_COUNT 1u
#define EXTRAS_REQUEST_BYTES (56u+1u*1024u)
static const uint8_t PROFILE_DIGEST[32]={28,30,85,223,222,220,209,156,57,224,29,137,208,139,249,86,26,173,177,46,112,240,9,225,228,74,79,219,229,197,56,26};
static const struct ftp_wbi_target TARGETS[]={
 {58231808ULL,0u,0u,1u},
};
static const struct ftp_wbi_change CHANGES[]={
 {451u,0u,1u},
};
static const struct ftp_wbi_profile FTP_PROFILE={TARGETS,CHANGES,PROFILE_DIGEST,1u,1u};
