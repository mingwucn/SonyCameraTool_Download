/* Fixed independent playback extras profile; not physical geometry proof. */
#include "ftp_wbi_experimental_core.h"
#define EXTRAS_ACTION 1u
#define EXTRAS_TARGET_COUNT 1u
#define EXTRAS_CHANGE_COUNT 2u
#define EXTRAS_REQUEST_BYTES (56u+1u*1024u)
static const uint8_t PROFILE_DIGEST[32]={192,83,227,26,58,248,116,177,126,127,159,58,57,141,56,233,137,44,240,246,131,78,145,0,15,175,120,41,48,192,186,252};
static const struct ftp_wbi_target TARGETS[]={
 {58232320ULL,0u,0u,2u},
};
static const struct ftp_wbi_change CHANGES[]={
 {82u,0u,1u},
 {83u,0u,1u},
};
static const struct ftp_wbi_profile FTP_PROFILE={TARGETS,CHANGES,PROFILE_DIGEST,1u,2u};
