/* Fixed independent playback extras profile; not physical geometry proof. */
#include "ftp_wbi_experimental_core.h"
#define EXTRAS_ACTION 2u
#define EXTRAS_TARGET_COUNT 2u
#define EXTRAS_CHANGE_COUNT 4u
#define EXTRAS_REQUEST_BYTES (56u+2u*1024u)
static const uint8_t PROFILE_DIGEST[32]={209,176,75,24,95,149,8,189,109,39,139,206,104,140,250,237,36,65,253,142,69,164,112,74,158,102,88,65,95,62,115,88};
static const struct ftp_wbi_target TARGETS[]={
 {39590912ULL,0u,0u,2u},
 {79915520ULL,1u,2u,2u},
};
static const struct ftp_wbi_change CHANGES[]={
 {396u,206u,119u},
 {397u,128u,96u},
 {396u,206u,119u},
 {397u,128u,96u},
};
static const struct ftp_wbi_profile FTP_PROFILE={TARGETS,CHANGES,PROFILE_DIGEST,2u,4u};
